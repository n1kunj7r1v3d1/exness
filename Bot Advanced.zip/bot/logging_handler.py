"""Logging functionality for Trading Bot"""
import csv
from datetime import date, datetime
from pathlib import Path
from config import (
    LOG_DIR, LOG_HEADER, HEARTBEAT_LOG_DIR, HEARTBEAT_LOG_FILE,
    HEARTBEAT_LOG_LOCK, HEARTBEAT_LOG_EMAIL_TIME
)
from utils import fmt_date, parse_ist_hhmm, now_ist
from email_handler import send_email

def csv_path(d: date) -> Path:
    return LOG_DIR / f"trades_{fmt_date(d)}.csv"

def init_csv(d: date):
    p = csv_path(d)
    if not p.exists():
        with open(p, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(LOG_HEADER)

def append_csv(d: date, row: list):
    p = csv_path(d)
    try:
        with open(p, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(row)
    except Exception as e:
        print(f"[CSV] Failed to append: {e}")

def init_heartbeat_log(d: date):
    global HEARTBEAT_LOG_FILE
    from config import HEARTBEAT_LOG_FILE, HEARTBEAT_LOG_LOCK
    
    with HEARTBEAT_LOG_LOCK:
        if HEARTBEAT_LOG_FILE and not HEARTBEAT_LOG_FILE.closed:
            HEARTBEAT_LOG_FILE.close()
        
        log_path = HEARTBEAT_LOG_DIR / f"heartbeat_{fmt_date(d)}.log"
        HEARTBEAT_LOG_FILE = open(log_path, "a", encoding="utf-8")
        # Write directly to avoid nested lock acquisition
        timestamp = now_ist().strftime("%Y-%m-%d %H:%M:%S")
        HEARTBEAT_LOG_FILE.write(f"{timestamp} | [START] Heartbeat log started for {fmt_date(d)}\n")
        HEARTBEAT_LOG_FILE.flush()

def write_heartbeat(message: str):
    from config import HEARTBEAT_LOG_FILE, HEARTBEAT_LOG_LOCK
    
    with HEARTBEAT_LOG_LOCK:
        if HEARTBEAT_LOG_FILE and not HEARTBEAT_LOG_FILE.closed:
            timestamp = now_ist().strftime("%Y-%m-%d %H:%M:%S")
            HEARTBEAT_LOG_FILE.write(f"{timestamp} | {message}\n")
            HEARTBEAT_LOG_FILE.flush()
        else:
            # If log file isn't ready yet, just print to console
            timestamp = now_ist().strftime("%Y-%m-%d %H:%M:%S")
            print(f"[HEARTBEAT] {timestamp} | {message}")

def close_heartbeat_log():
    from config import HEARTBEAT_LOG_FILE, HEARTBEAT_LOG_LOCK
    
    with HEARTBEAT_LOG_LOCK:
        if HEARTBEAT_LOG_FILE and not HEARTBEAT_LOG_FILE.closed:
            # Write directly to avoid nested lock acquisition
            timestamp = now_ist().strftime("%Y-%m-%d %H:%M:%S")
            HEARTBEAT_LOG_FILE.write(f"{timestamp} | [END] Heartbeat log closed\n")
            HEARTBEAT_LOG_FILE.flush()
            HEARTBEAT_LOG_FILE.close()

def email_heartbeat_log_if_needed(ist_day: date):
    """Email previous day's heartbeat log at configured time"""
    from config import (
        HEARTBEAT_LOG_EMAILED_TODAY, HEARTBEAT_LOG_EMAIL_TIME
    )
    
    global HEARTBEAT_LOG_EMAILED_TODAY
    
    ist_now = now_ist()
    email_hh, email_mm = parse_ist_hhmm(HEARTBEAT_LOG_EMAIL_TIME)
    
    if ist_now.hour == email_hh and ist_now.minute == email_mm and not HEARTBEAT_LOG_EMAILED_TODAY:
        prev_day = ist_day - datetime.timedelta(days=1)
        log_path = HEARTBEAT_LOG_DIR / f"heartbeat_{fmt_date(prev_day)}.log"
        
        if log_path.exists():
            send_email(
                f"Heartbeat Log - {fmt_date(prev_day)}",
                f"Attached is the heartbeat log for {fmt_date(prev_day)}",
                log_path
            )
            HEARTBEAT_LOG_EMAILED_TODAY = True
            print(f"[HEARTBEAT_LOG] Emailed log for {fmt_date(prev_day)}")