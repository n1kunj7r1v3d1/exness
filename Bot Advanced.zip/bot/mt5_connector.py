"""MT5 helper functions for Trading Bot"""
import MetaTrader5 as mt5
from typing import Optional, Tuple
from config import ACCOUNT, PASSWORD, SERVER, SYMBOL, SL_PIPS, TP_PIPS, PIP_SIZE, MAGIC, DEVIATION
import time as _time

def init_mt5():
    if not mt5.initialize():
        raise RuntimeError(f"MT5 init error: {mt5.last_error()}")
    if not mt5.login(ACCOUNT, password=PASSWORD, server=SERVER):
        raise RuntimeError(f"MT5 login error: {mt5.last_error()}")
    info = mt5.symbol_info(SYMBOL)
    if info is None:
        raise RuntimeError(f"{SYMBOL} not found")
    if not info.visible:
        if not mt5.symbol_select(SYMBOL, True):
            raise RuntimeError(f"Cannot enable {SYMBOL}")

def shutdown_mt5():
    mt5.shutdown()

def compute_sl_tp(entry: float, signal: str) -> Tuple[float, float]:
    if signal == "BUY":
        sl = entry - SL_PIPS * PIP_SIZE
        tp = entry + TP_PIPS * PIP_SIZE
    else:
        sl = entry + SL_PIPS * PIP_SIZE
        tp = entry - TP_PIPS * PIP_SIZE
    return sl, tp

def place_trade(signal: str, volume: float, tag: str):
    price_type = mt5.ORDER_TYPE_BUY if signal == "BUY" else mt5.ORDER_TYPE_SELL
    tick = mt5.symbol_info_tick(SYMBOL)
    if tick is None:
        print(f"[ERROR] No tick data for {SYMBOL}")
        return None
    
    price = tick.ask if signal == "BUY" else tick.bid
    sl, tp = compute_sl_tp(price, signal)
    
    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": SYMBOL,
        "volume": volume,
        "type": price_type,
        "price": price,
        "sl": sl,
        "tp": tp,
        "deviation": DEVIATION,
        "magic": MAGIC,
        "comment": f"60pip_bot|{tag}",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }
    
    result = mt5.order_send(request)
    
    if result is None:
        print(f"[ERROR] order_send returned None")
        return None
    
    if result.retcode != mt5.TRADE_RETCODE_DONE:
        print(f"[ERROR] Trade failed: {result.retcode} - {result.comment}")
    
    return result

def verify_position_exists(result, expected_comment: str) -> Optional[int]:
    if not result or result.retcode != mt5.TRADE_RETCODE_DONE:
        return None
    
    _time.sleep(0.5)
    
    positions = mt5.positions_get(symbol=SYMBOL)
    if not positions:
        return None
    
    for pos in positions:
        if getattr(pos, "magic", 0) == MAGIC and getattr(pos, "comment", "").startswith("60pip_bot"):
            return pos.ticket
    
    return None

def get_open_positions():
    """Get all open positions for the symbol with our MAGIC"""
    try:
        positions = mt5.positions_get(symbol=SYMBOL)
        if not positions:
            return []
        return [p for p in positions if getattr(p, "magic", 0) == MAGIC]
    except Exception as e:
        print(f"[ERROR] Failed to get positions: {e}")
        return []

def close_position_partial(ticket: int, volume: float, signal: str):
    """Close a partial position"""
    try:
        pos = mt5.positions_get(ticket=ticket)
        if not pos:
            return None
        
        pos = pos[0]
        if volume <= 0 or volume > pos.volume:
            return None
        
        tick = mt5.symbol_info_tick(SYMBOL)
        if not tick:
            return None
        
        close_price = tick.bid if signal == "BUY" else tick.ask
        close_type = mt5.ORDER_TYPE_SELL if signal == "BUY" else mt5.ORDER_TYPE_BUY
        
        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": SYMBOL,
            "volume": volume,
            "type": close_type,
            "position": ticket,
            "price": close_price,
            "deviation": DEVIATION,
            "magic": MAGIC,
            "comment": f"PARTIAL_CLOSE|{ticket}",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        
        result = mt5.order_send(request)
        return result
    except Exception as e:
        print(f"[ERROR] Partial close failed: {e}")
        return None