"""Tick price ledger management for Trading Bot"""
import json
import MetaTrader5 as mt5
from datetime import date, datetime, timedelta, time as dt_time
from pathlib import Path
from config import (
    TICK_LEDGER_DIR, TICK_LEDGER_RETENTION_DAYS, SYMBOL,
    CANDLE_OPENS, CANDLE_OPENS_LOCK
)
from utils import fmt_date, parse_ist_hhmm, now_ist, REQUIRED_OPENING_TIMES

def tick_ledger_path(d: date) -> Path:
    return TICK_LEDGER_DIR / f"tick_ledger_{fmt_date(d)}.json"

def load_tick_ledger(d: date) -> dict:
    p = tick_ledger_path(d)
    if p.exists():
        try:
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return {}

def save_tick_ledger(d: date, ledger: dict):
    p = tick_ledger_path(d)
    try:
        with open(p, "w", encoding="utf-8") as f:
            json.dump(ledger, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"[TICK_LEDGER] Failed to save: {e}")

def capture_tick_price(ist_hhmm: str, d: date):
    """Capture current tick price and save to ledger"""
    try:
        tick = mt5.symbol_info_tick(SYMBOL)
        if tick is None:
            return
        
        ledger = load_tick_ledger(d)
        ledger[ist_hhmm] = {
            "ask": tick.ask,
            "bid": tick.bid,
            "timestamp": datetime.now().isoformat()
        }
        save_tick_ledger(d, ledger)
        
        with CANDLE_OPENS_LOCK:
            CANDLE_OPENS[ist_hhmm] = tick.ask
        
    except Exception as e:
        print(f"[TICK_LEDGER] Failed to capture {ist_hhmm}: {e}")

def backfill_todays_opens(d: date):
    """Backfill missing opening prices using tick ledger and MT5 history"""
    from config import IST_TZ
    
    ledger = load_tick_ledger(d)
    
    ist_now = now_ist()
    
    with CANDLE_OPENS_LOCK:
        for time_key in REQUIRED_OPENING_TIMES:
            if time_key in CANDLE_OPENS:
                continue
            
            hh, mm = parse_ist_hhmm(time_key)
            # Make time_dt timezone-aware to match ist_now
            time_dt = datetime.combine(d, dt_time(hh, mm)).replace(tzinfo=IST_TZ)
            
            if time_dt > ist_now:
                continue
            
            if time_key in ledger:
                CANDLE_OPENS[time_key] = ledger[time_key]["ask"]
                continue
            
            try:
                # MT5 expects timezone-naive datetime
                time_dt_naive = time_dt.replace(tzinfo=None)
                rates = mt5.copy_rates_range(SYMBOL, mt5.TIMEFRAME_M1, time_dt_naive, time_dt_naive + timedelta(minutes=1))
                if rates is not None and len(rates) > 0:
                    open_price = rates[0]["open"]
                    CANDLE_OPENS[time_key] = open_price
                    
                    ledger[time_key] = {
                        "ask": open_price,
                        "bid": open_price,
                        "timestamp": datetime.now().isoformat(),
                        "source": "mt5_backfill"
                    }
            except:
                pass
        
        save_tick_ledger(d, ledger)

def cleanup_old_tick_ledgers():
    """Remove tick ledgers older than retention period"""
    try:
        cutoff = date.today() - timedelta(days=TICK_LEDGER_RETENTION_DAYS)
        for ledger_file in TICK_LEDGER_DIR.glob("tick_ledger_*.json"):
            try:
                file_date_str = ledger_file.stem.replace("tick_ledger_", "")
                file_date = datetime.strptime(file_date_str, "%d-%m-%Y").date()
                if file_date < cutoff:
                    ledger_file.unlink()
                    print(f"[TICK_LEDGER] Deleted old ledger: {ledger_file.name}")
            except:
                pass
    except Exception as e:
        print(f"[TICK_LEDGER] Cleanup failed: {e}")