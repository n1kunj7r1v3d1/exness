"""
WordPress Integration Module
Handles all WordPress database connections and data synchronization
"""
import mysql.connector
from mysql.connector import Error as MySQLError
from datetime import datetime
from config import IST_TZ

# ========= WORDPRESS DATABASE CONFIGURATION =========
# UPDATE THESE VALUES WITH YOUR WORDPRESS DATABASE CREDENTIALS
WP_DB_CONFIG = {
    'host': 'localhost',              # Usually 'localhost' (or your domain/IP if remote)
    'database': 'cmkbyysn_wp721',        # ← CHANGE THIS to your WordPress database name
    'user': 'cmkbyysn_wp721',            # ← CHANGE THIS to your WordPress database user
    'password': '4S)2pow(2K',    # ← CHANGE THIS to your WordPress database password
    'port': 3306
}

WP_TABLE_PREFIX = 'wpbs_'  # Usually 'wp_' - check your wp-config.php
WP_ENABLED = True  # Set to False to disable WordPress integration

# ========= UPDATE TIMING CONFIGURATION =========
# Bot status updates: Every 2 seconds (customized per user request)
BOT_STATUS_UPDATE_INTERVAL = 2  # seconds

# Position updates while trade is open: Every 1 second (customized per user request)
POSITION_UPDATE_INTERVAL = 1  # seconds


def get_wp_connection():
    """
    Create and return a MySQL connection to WordPress database
    Returns None if connection fails or WP_ENABLED is False
    """
    if not WP_ENABLED:
        return None
    
    try:
        conn = mysql.connector.connect(**WP_DB_CONFIG)
        if conn.is_connected():
            return conn
    except MySQLError as e:
        print(f"[WP-ERROR] Database connection failed: {e}")
    return None


def wp_save_trade(ticket, date_str, trade_number, time_str, entry_price, sl_price, tp_price,
                  lot_size, signal, partial_close_price=None, partial_close_lot=None,
                  outcome=None, pnl=None, account_balance=None, notes=None):
    """
    Save or update a trade in WordPress database
    
    Args:
        ticket: MT5 position ticket number
        date_str: Trade date (format: DD-MM-YYYY)
        trade_number: Sequential trade number for the day
        time_str: Entry time (format: HH:MM)
        entry_price: Entry price
        sl_price: Stop loss price
        tp_price: Take profit price
        lot_size: Lot size
        signal: Trade direction (BUY/SELL)
        partial_close_price: Partial close price (optional)
        partial_close_lot: Partial close lot size (optional)
        outcome: Trade outcome (TP/SL/PARTIAL) (optional)
        pnl: Profit/Loss in USD (optional)
        account_balance: Account balance after trade (optional)
        notes: Additional notes (optional)
    """
    if not WP_ENABLED:
        return
    
    conn = get_wp_connection()
    if not conn:
        return
    
    try:
        cursor = conn.cursor()
        table = f"{WP_TABLE_PREFIX}tbd_trades"
        
        # Check if trade already exists
        cursor.execute(f"SELECT id FROM {table} WHERE ticket = %s", (ticket,))
        existing = cursor.fetchone()
        
        if existing:
            # Update existing trade
            update_query = f"""
            UPDATE {table}
            SET outcome = %s, pnl = %s, account_balance = %s,
                partial_close_price = %s, partial_close_lot = %s,
                notes = %s, updated_at = NOW()
            WHERE ticket = %s
            """
            cursor.execute(update_query, (
                outcome, pnl, account_balance,
                partial_close_price, partial_close_lot,
                notes, ticket
            ))
        else:
            # Insert new trade
            insert_query = f"""
            INSERT INTO {table}
            (ticket, date, trade_number, time, entry_price, sl_price, tp_price,
             lot_size, signal, partial_close_price, partial_close_lot,
             outcome, pnl, account_balance, notes, created_at, updated_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW(), NOW())
            """
            cursor.execute(insert_query, (
                ticket, date_str, trade_number, time_str, entry_price, sl_price, tp_price,
                lot_size, signal, partial_close_price, partial_close_lot,
                outcome, pnl, account_balance, notes
            ))
        
        conn.commit()
        print(f"[WP-SUCCESS] Trade {ticket} saved to WordPress")
    
    except MySQLError as e:
        print(f"[WP-ERROR] Failed to save trade {ticket}: {e}")
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()


def wp_update_position(ticket, signal, entry_price, current_price, sl_price, tp_price,
                      lot_size, pnl, open_time, close=False):
    """
    Update or close a position in WordPress database
    
    Args:
        ticket: MT5 position ticket number
        signal: Trade direction (BUY/SELL)
        entry_price: Entry price
        current_price: Current price
        sl_price: Stop loss price
        tp_price: Take profit price
        lot_size: Current lot size
        pnl: Current profit/loss
        open_time: Position open time (datetime string)
        close: If True, remove from open positions (default False)
    """
    if not WP_ENABLED:
        return
    
    conn = get_wp_connection()
    if not conn:
        return
    
    try:
        cursor = conn.cursor()
        table = f"{WP_TABLE_PREFIX}tbd_positions"
        
        if close:
            # Remove from open positions
            cursor.execute(f"DELETE FROM {table} WHERE ticket = %s", (ticket,))
            print(f"[WP-SUCCESS] Position {ticket} removed from open positions")
        else:
            # Check if position exists
            cursor.execute(f"SELECT id FROM {table} WHERE ticket = %s", (ticket,))
            existing = cursor.fetchone()
            
            if existing:
                # Update existing position
                update_query = f"""
                UPDATE {table}
                SET current_price = %s, pnl = %s, lot_size = %s, updated_at = NOW()
                WHERE ticket = %s
                """
                cursor.execute(update_query, (current_price, pnl, lot_size, ticket))
            else:
                # Insert new position
                insert_query = f"""
                INSERT INTO {table}
                (ticket, signal, entry_price, current_price, sl_price, tp_price,
                 lot_size, pnl, open_time, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, NOW(), NOW())
                """
                cursor.execute(insert_query, (
                    ticket, signal, entry_price, current_price, sl_price, tp_price,
                    lot_size, pnl, open_time
                ))
            
            print(f"[WP-SUCCESS] Position {ticket} updated")
        
        conn.commit()
    
    except MySQLError as e:
        print(f"[WP-ERROR] Failed to update position {ticket}: {e}")
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()


def wp_update_bot_status(status, balance, equity, open_positions, daily_pnl, 
                         total_trades_today, win_rate=None, profit_factor=None):
    """
    Update bot status in WordPress (should be called every 30-60 seconds)
    
    Args:
        status: Bot status (running/stopped/error)
        balance: Current account balance
        equity: Current account equity
        open_positions: Number of open positions
        daily_pnl: Today's profit/loss
        total_trades_today: Total trades executed today
        win_rate: Win rate percentage (optional)
        profit_factor: Profit factor (optional)
    """
    if not WP_ENABLED:
        return
    
    conn = get_wp_connection()
    if not conn:
        return
    
    try:
        cursor = conn.cursor()
        table = f"{WP_TABLE_PREFIX}tbd_bot_status"
        
        # Delete old status and insert new
        cursor.execute(f"DELETE FROM {table}")
        
        insert_query = f"""
        INSERT INTO {table}
        (status, balance, equity, open_positions, daily_pnl, total_trades_today,
         win_rate, profit_factor, last_update)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, NOW())
        """
        cursor.execute(insert_query, (
            status, balance, equity, open_positions, daily_pnl,
            total_trades_today, win_rate, profit_factor
        ))
        
        conn.commit()
        print(f"[WP-SUCCESS] Bot status updated - Balance: ${balance:.2f}, Equity: ${equity:.2f}")
    
    except MySQLError as e:
        print(f"[WP-ERROR] Failed to update bot status: {e}")
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()


def wp_log(level, message, context=None):
    """
    Log an event to WordPress database
    
    Args:
        level: Log level (info/warning/error/success)
        message: Log message
        context: Additional context (optional)
    """
    if not WP_ENABLED:
        return
    
    conn = get_wp_connection()
    if not conn:
        return
    
    try:
        cursor = conn.cursor()
        table = f"{WP_TABLE_PREFIX}tbd_logs"
        
        insert_query = f"""
        INSERT INTO {table}
        (level, message, context, created_at)
        VALUES (%s, %s, %s, NOW())
        """
        cursor.execute(insert_query, (level, message, context))
        conn.commit()
    
    except MySQLError as e:
        print(f"[WP-ERROR] Failed to log message: {e}")
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()


def wp_save_daily_stats(date_str, opening_balance, closing_balance, total_trades,
                       winning_trades, losing_trades, total_pnl, win_rate,
                       profit_factor, max_drawdown, largest_win, largest_loss):
    """
    Save daily statistics to WordPress
    
    Args:
        date_str: Date (format: DD-MM-YYYY)
        opening_balance: Opening balance for the day
        closing_balance: Closing balance for the day
        total_trades: Total number of trades
        winning_trades: Number of winning trades
        losing_trades: Number of losing trades
        total_pnl: Total profit/loss
        win_rate: Win rate percentage
        profit_factor: Profit factor
        max_drawdown: Maximum drawdown
        largest_win: Largest winning trade
        largest_loss: Largest losing trade
    """
    if not WP_ENABLED:
        return
    
    conn = get_wp_connection()
    if not conn:
        return
    
    try:
        cursor = conn.cursor()
        table = f"{WP_TABLE_PREFIX}tbd_daily_stats"
        
        # Check if stats for this date already exist
        cursor.execute(f"SELECT id FROM {table} WHERE date = %s", (date_str,))
        existing = cursor.fetchone()
        
        if existing:
            # Update existing stats
            update_query = f"""
            UPDATE {table}
            SET closing_balance = %s, total_trades = %s, winning_trades = %s,
                losing_trades = %s, total_pnl = %s, win_rate = %s, profit_factor = %s,
                max_drawdown = %s, largest_win = %s, largest_loss = %s, updated_at = NOW()
            WHERE date = %s
            """
            cursor.execute(update_query, (
                closing_balance, total_trades, winning_trades, losing_trades,
                total_pnl, win_rate, profit_factor, max_drawdown,
                largest_win, largest_loss, date_str
            ))
        else:
            # Insert new stats
            insert_query = f"""
            INSERT INTO {table}
            (date, opening_balance, closing_balance, total_trades, winning_trades,
             losing_trades, total_pnl, win_rate, profit_factor, max_drawdown,
             largest_win, largest_loss, created_at, updated_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW(), NOW())
            """
            cursor.execute(insert_query, (
                date_str, opening_balance, closing_balance, total_trades,
                winning_trades, losing_trades, total_pnl, win_rate,
                profit_factor, max_drawdown, largest_win, largest_loss
            ))
        
        conn.commit()
        print(f"[WP-SUCCESS] Daily stats saved for {date_str}")
    
    except MySQLError as e:
        print(f"[WP-ERROR] Failed to save daily stats: {e}")
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()


def wp_get_config():
    """
    Retrieve bot configuration from WordPress database
    Returns dict of config values or None if failed
    """
    if not WP_ENABLED:
        return None
    
    conn = get_wp_connection()
    if not conn:
        return None
    
    try:
        cursor = conn.cursor(dictionary=True)
        table = f"{WP_TABLE_PREFIX}tbd_config"
        
        cursor.execute(f"SELECT config_key, config_value FROM {table}")
        results = cursor.fetchall()
        
        config = {}
        for row in results:
            config[row['config_key']] = row['config_value']
        
        return config
    
    except MySQLError as e:
        print(f"[WP-ERROR] Failed to get config: {e}")
        return None
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()


def test_wordpress_connection():
    """
    Test WordPress database connection
    Prints success/failure message and returns True/False
    """
    if not WP_ENABLED:
        print("\n" + "="*70)
        print("[WP-INFO] WordPress integration is DISABLED (WP_ENABLED = False)")
        print("="*70 + "\n")
        return False
    
    print("\n" + "="*70)
    print("TESTING WORDPRESS DATABASE CONNECTION")
    print("="*70)
    
    conn = get_wp_connection()
    if not conn:
        print("❌ WordPress database connection FAILED!")
        print("   → Check your WP_DB_CONFIG values")
        print("   → Verify Remote MySQL is enabled in cPanel")
        print("   → Confirm database credentials are correct")
        print("="*70 + "\n")
        return False
    
    try:
        cursor = conn.cursor()
        
        # Test if tables exist
        tables_to_check = [
            f"{WP_TABLE_PREFIX}tbd_config",
            f"{WP_TABLE_PREFIX}tbd_trades",
            f"{WP_TABLE_PREFIX}tbd_positions",
            f"{WP_TABLE_PREFIX}tbd_bot_status",
            f"{WP_TABLE_PREFIX}tbd_logs",
            f"{WP_TABLE_PREFIX}tbd_daily_stats"
        ]
        
        tables_exist = True
        for table in tables_to_check:
            cursor.execute(f"SHOW TABLES LIKE '{table}'")
            if not cursor.fetchone():
                print(f"❌ Table {table} does not exist!")
                tables_exist = False
        
        if not tables_exist:
            print("   → Make sure WordPress plugin is installed and activated")
            print("="*70 + "\n")
            return False
        
        # Test retrieving config
        config_table = f"{WP_TABLE_PREFIX}tbd_config"
        cursor.execute(f"SELECT COUNT(*) as count FROM {config_table}")
        count = cursor.fetchone()[0]
        
        print(f"✅ WordPress database connection successful!")
        print(f"✅ Found {count} configuration entries in database")
        
        # Get sample config
        cursor.execute(f"SELECT config_key, config_value FROM {config_table} LIMIT 3")
        sample_config = cursor.fetchall()
        if sample_config:
            print(f"✅ Sample config values:")
            for key, value in sample_config:
                print(f"   • {key} = {value}")
        
        print("="*70)
        print("✅ WordPress integration is ready!")
        print("="*70 + "\n")
        
        return True
    
    except MySQLError as e:
        print(f"❌ Database error: {e}")
        print("="*70 + "\n")
        return False
    finally:
        if conn and conn.is_connected():
            cursor.close()
            conn.close()


if __name__ == "__main__":
    # Test connection when run directly
    test_wordpress_connection()
