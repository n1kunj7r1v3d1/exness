"""
Utility functions for the trading bot
"""
import re
from datetime import date, datetime, timedelta, time as dt_time
from typing import Tuple
from config import DATE_FMT, IST_TRADE_TIMES

def fmt_date(d: date) -> str:
    """Format date to string"""
    return d.strftime(DATE_FMT)

def parse_ist_hhmm(hhmm: str) -> Tuple[int, int]:
    """Parse IST time string to hour and minute"""
    m = re.match(r'^(\d{1,2}):(\d{1,2})(?::\d{1,2})?$', str(hhmm).strip())
    if not m:
        raise ValueError(f"Bad time format: {hhmm}")
    h, mn = int(m.group(1)), int(m.group(2))
    if not (0 <= h < 24 and 0 <= mn < 60):
        raise ValueError(f"Out-of-range time: {hhmm}")
    return h, mn

def calculate_required_opening_times():
    """Calculate required opening times (5 minutes before each trade time)"""
    opening_times = []
    for trade_time in IST_TRADE_TIMES:
        hh, mm = parse_ist_hhmm(trade_time)
        opening_dt = datetime.combine(date.today(), dt_time(hh, mm)) - timedelta(minutes=5)
        opening_key = opening_dt.strftime("%H:%M")
        if opening_key not in opening_times:
            opening_times.append(opening_key)
    return opening_times

# Calculate required opening times
REQUIRED_OPENING_TIMES = calculate_required_opening_times()
