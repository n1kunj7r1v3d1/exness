"""Baseline and balance management for Trading Bot - WITHDRAWAL DETECTION DISABLED FOR DEMO"""
import json
import csv
import MetaTrader5 as mt5
from datetime import datetime, timedelta
import config  # Import module for mutable globals
from config import (
    BASELINE_STATE_FILE, WITHDRAWAL_LOG, DEFAULT_BASELINE,
    LAST_KNOWN_BALANCE, BALANCE_LOCK, BALANCE_MONITOR_INTERVAL_SECONDS
)
from utils import fmt_date, now_ist
from email_handler import send_email
from logging_handler import write_heartbeat
import time as _time

# ============================================
# WITHDRAWAL DETECTION CONTROL
# ============================================
# Set to False to disable withdrawal detection (for demo accounts)
ENABLE_WITHDRAWAL_DETECTION = False  # CHANGED: Was True, now False for demo account
# ============================================

def load_baseline() -> float:
    if BASELINE_STATE_FILE.exists():
        try:
            with open(BASELINE_STATE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            return float(data.get("baseline", DEFAULT_BASELINE))
        except:
            pass
    return DEFAULT_BASELINE

def save_baseline(value: float):
    try:
        with open(BASELINE_STATE_FILE, "w", encoding="utf-8") as f:
            json.dump({"baseline": value, "updated": datetime.now().isoformat()}, f, indent=2)
    except Exception as e:
        print(f"[BASELINE] Failed to save: {e}")

def log_withdrawal(amount: float, timestamp: datetime):
    """Log withdrawal to CSV"""
    try:
        file_exists = WITHDRAWAL_LOG.exists()
        with open(WITHDRAWAL_LOG, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            if not file_exists:
                writer.writerow(["Date", "Time", "Amount", "New Baseline"])
            
            new_baseline = load_baseline()
            writer.writerow([
                fmt_date(timestamp.date()),
                timestamp.strftime("%H:%M:%S"),
                f"{amount:.2f}",
                f"{new_baseline:.2f}"
            ])
    except Exception as e:
        print(f"[WITHDRAWAL] Failed to log: {e}")

def detect_withdrawal(current_balance: float) -> bool:
    """
    Detect if a withdrawal occurred
    FIXED: Now requires MUCH larger drop to avoid false positives from trading losses
    """
    if not ENABLE_WITHDRAWAL_DETECTION:
        return False  # Withdrawal detection disabled
    
    with BALANCE_LOCK:
        if config.LAST_KNOWN_BALANCE == 0.0:
            config.LAST_KNOWN_BALANCE = current_balance
            return False
        
        diff = config.LAST_KNOWN_BALANCE - current_balance
        
        # FIXED: Require balance to drop by at least $100 to consider it a withdrawal
        # This prevents false alarms from normal trading losses
        if diff > 100.0:  # Changed from 1.0 to 100.0
            return True
        
        config.LAST_KNOWN_BALANCE = current_balance
        return False

def check_mt5_withdrawal_history():
    """
    Check MT5 history for withdrawals (deal_type=2)
    This is more reliable than balance monitoring
    """
    if not ENABLE_WITHDRAWAL_DETECTION:
        return False, 0.0  # Withdrawal detection disabled
    
    try:
        ist_now = now_ist()
        today_start = datetime.combine(ist_now.date(), datetime.min.time())
        
        deals = mt5.history_deals_get(today_start, ist_now)
        
        if deals:
            for deal in deals:
                # Deal type 2 = DEAL_TYPE_BALANCE (deposit/withdrawal)
                if getattr(deal, "type", -1) == 2:
                    profit = getattr(deal, "profit", 0.0)
                    # Negative profit = withdrawal
                    if profit < -1.0:
                        amount = abs(profit)
                        return True, amount
        
        return False, 0.0
    except Exception as e:
        print(f"[WITHDRAWAL] History check failed: {e}")
        return False, 0.0

def balance_monitor_thread():
    """
    Background thread to monitor balance for withdrawals
    MODIFIED: Now respects ENABLE_WITHDRAWAL_DETECTION flag
    """
    print(f"[BALANCE_MONITOR] Started (Withdrawal Detection: {'ENABLED' if ENABLE_WITHDRAWAL_DETECTION else 'DISABLED'})")
    write_heartbeat(f"[BALANCE_MONITOR] Started (Detection: {'ON' if ENABLE_WITHDRAWAL_DETECTION else 'OFF'})")
    
    if not ENABLE_WITHDRAWAL_DETECTION:
        print("[BALANCE_MONITOR] Withdrawal detection disabled for demo account")
        write_heartbeat("[BALANCE_MONITOR] Withdrawal detection disabled - demo mode")
    
    while config.RUN_HEARTBEAT.is_set():
        try:
            # Skip withdrawal check if disabled or already detected today
            if not ENABLE_WITHDRAWAL_DETECTION or config.WITHDRAWAL_DETECTED_TODAY:
                _time.sleep(BALANCE_MONITOR_INTERVAL_SECONDS)
                continue
            
            account_info = mt5.account_info()
            if account_info:
                current_balance = account_info.balance
                
                # PRIORITY 1: Check MT5 history for actual withdrawal transactions
                withdrawal_detected, withdrawal_amount = check_mt5_withdrawal_history()
                
                # PRIORITY 2: Only if history check fails, check balance drop
                if not withdrawal_detected:
                    withdrawal_detected = detect_withdrawal(current_balance)
                    if withdrawal_detected:
                        withdrawal_amount = abs(config.LAST_KNOWN_BALANCE - current_balance)
                
                if withdrawal_detected:
                    config.WITHDRAWAL_DETECTED_TODAY = True
                    
                    old_baseline = load_baseline()
                    new_baseline = current_balance
                    save_baseline(new_baseline)
                    
                    timestamp = now_ist()
                    log_withdrawal(withdrawal_amount, timestamp)
                    
                    msg = (
                        f"Withdrawal Detected!\n\n"
                        f"Amount: ${withdrawal_amount:.2f}\n"
                        f"Old Baseline: ${old_baseline:.2f}\n"
                        f"New Baseline: ${new_baseline:.2f}\n"
                        f"Time: {timestamp.strftime('%H:%M:%S IST')}"
                    )
                    
                    send_email("WITHDRAWAL DETECTED - Baseline Updated", msg)
                    print(f"[WITHDRAWAL] Detected ${withdrawal_amount:.2f}, baseline updated to ${new_baseline:.2f}")
                    write_heartbeat(f"[WITHDRAWAL] ${withdrawal_amount:.2f} detected, baseline: ${new_baseline:.2f}")
            
            _time.sleep(BALANCE_MONITOR_INTERVAL_SECONDS)
        
        except Exception as e:
            print(f"[BALANCE_MONITOR] Error: {e}")
            write_heartbeat(f"[BALANCE_MONITOR] Error: {e}")
            _time.sleep(BALANCE_MONITOR_INTERVAL_SECONDS)
    
    print("[BALANCE_MONITOR] Stopped")
    write_heartbeat("[BALANCE_MONITOR] Stopped")

def query_balance_at_scheduled_time(ist_day, ist_hhmm: str):
    """Query balance at scheduled time and update baseline if needed"""
    
    if config.BALANCE_QUERIED_TODAY:
        return
    
    try:
        account_info = mt5.account_info()
        if account_info:
            current_balance = account_info.balance
            stored_baseline = load_baseline()
            
            if abs(current_balance - stored_baseline) > 0.01:
                save_baseline(current_balance)
                print(f"[BALANCE_QUERY] Updated baseline: ${stored_baseline:.2f} -> ${current_balance:.2f}")
                write_heartbeat(f"[BALANCE_QUERY] Baseline updated: ${current_balance:.2f}")
            else:
                print(f"[BALANCE_QUERY] Baseline confirmed: ${current_balance:.2f}")
                write_heartbeat(f"[BALANCE_QUERY] Baseline confirmed: ${current_balance:.2f}")
            
            config.BALANCE_QUERIED_TODAY = True
    except Exception as e:
        print(f"[BALANCE_QUERY] Failed: {e}")
        write_heartbeat(f"[BALANCE_QUERY] Failed: {e}")