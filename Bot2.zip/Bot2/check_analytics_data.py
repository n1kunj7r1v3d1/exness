"""Quick script to check if trades exist in database"""
import mysql.connector

DB_CONFIG = {
    'host': '103.191.209.38',
    'user': 'cmkbyysn_wp423',
    'password': '25-m1!rSLp',
    'database': 'cmkbyysn_wp423'
}

def check_trades():
    """Check if trades exist in database"""
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor(dictionary=True)
        
        # Count total trades
        cursor.execute("SELECT COUNT(*) as count FROM wp9y_tbd_trades")
        total = cursor.fetchone()['count']
        
        print(f"📊 Total trades in database: {total}")
        
        if total == 0:
            print("\n❌ NO TRADES FOUND!")
            print("This is why Analytics shows $0.00 and 0 trades.")
            print("\nPossible reasons:")
            print("1. Bot hasn't executed any trades yet")
            print("2. Bot is not saving trades to WordPress database")
            print("3. Wrong database/table being checked")
            return
        
        # Get sample trades
        cursor.execute("""
            SELECT trade_date, entry_time, signal, pnl, balance 
            FROM wp9y_tbd_trades 
            ORDER BY trade_date DESC 
            LIMIT 5
        """)
        trades = cursor.fetchall()
        
        print(f"\n✅ Found {total} trades! Here are the latest 5:\n")
        for t in trades:
            pnl = float(t['pnl']) if t['pnl'] else 0
            print(f"📅 {t['trade_date']} {t['entry_time']} | {t['signal']} | P&L: ${pnl:.2f}")
        
        # Calculate totals
        cursor.execute("SELECT SUM(pnl) as total_pnl FROM wp9y_tbd_trades")
        result = cursor.fetchone()
        total_pnl = float(result['total_pnl']) if result['total_pnl'] else 0
        
        print(f"\n💰 Total P&L: ${total_pnl:.2f}")
        print(f"📈 Total Trades: {total}")
        
        print("\n" + "="*60)
        print("✅ TRADES EXIST IN DATABASE!")
        print("If Analytics still shows $0.00, the issue is:")
        print("1. analytics.php file not uploaded correctly")
        print("2. Browser cache (press Ctrl+Shift+R)")
        print("3. Wrong file path")
        print("="*60)
        
        cursor.close()
        conn.close()
        
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == '__main__':
    print("="*60)
    print("NEXUS PRO - ANALYTICS DATA CHECKER")
    print("="*60)
    print()
    check_trades()