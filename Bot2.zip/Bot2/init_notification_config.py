"""Initialize notification configs in WordPress database - RUN ONCE"""
import mysql.connector

# IMPORTANT: Add your MySQL password below
DB_CONFIG = {
    'host': '103.191.209.38',
    'user': 'cmkbyysn_wp423',
    'password': '25-m1!rSLp',  
    'database': 'cmkbyysn_wp423'
}

NOTIFICATION_TYPES = [
    'trade_executed',
    'partial_close',
    'sl_hit',
    'tp_hit'
]

def init_configs():
    """Initialize all notification configs as enabled"""
    if not DB_CONFIG['password']:
        print("❌ ERROR: Please add your MySQL password in DB_CONFIG")
        return
    
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor()
        
        print("✅ Connected to MySQL database")
        print(f"📊 Initializing {len(NOTIFICATION_TYPES)} notification types...\n")
        
        for ntype in NOTIFICATION_TYPES:
            config_key = f'{ntype}_enabled'
            
            # Check if exists
            cursor.execute(
                "SELECT config_value FROM wp9y_tbd_config WHERE config_key = %s",
                (config_key,)
            )
            result = cursor.fetchone()
            
            if result:
                print(f"✅ {config_key}: Already exists with value '{result[0]}'")
            else:
                # Insert as enabled
                cursor.execute(
                    "INSERT INTO wp9y_tbd_config (config_key, config_value) VALUES (%s, %s)",
                    (config_key, '1')
                )
                conn.commit()
                print(f"✅ {config_key}: Initialized to ENABLED")
        
        cursor.close()
        conn.close()
        
        print("\n" + "="*50)
        print("✅ ALL NOTIFICATION CONFIGS INITIALIZED!")
        print("="*50)
        print("\nYou can now delete this script or keep it for future use.")
        
    except mysql.connector.Error as e:
        print(f"❌ MySQL Error: {e}")
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == '__main__':
    print("="*50)
    print("NEXUS PRO - NOTIFICATION CONFIG INITIALIZER")
    print("="*50)
    print("\nThis script will initialize notification settings in your database.")
    print("Run this ONCE, then you can delete it.\n")
    
    init_configs()