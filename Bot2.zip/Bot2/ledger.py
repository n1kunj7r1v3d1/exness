"""
Trade Ledger System - Stores daily trade information
"""
import json
import threading
from pathlib import Path
from datetime import datetime, date


# Ledger storage directory
LEDGER_DIR = Path("trade_ledgers")
LEDGER_DIR.mkdir(exist_ok=True)

# Thread lock for ledger operations
LEDGER_LOCK = threading.Lock()


def _ensure_date_string(date_input):
    """
    Convert date input to string format YYYY-MM-DD
    
    Args:
        date_input: Can be string, date, or datetime object
    
    Returns:
        str: Date in YYYY-MM-DD format
    """
    if isinstance(date_input, str):
        return date_input
    elif isinstance(date_input, datetime):
        return date_input.strftime("%Y-%m-%d")
    elif isinstance(date_input, date):
        return date_input.strftime("%Y-%m-%d")
    else:
        return str(date_input)


def get_ledger_filename(date_input):
    """
    Get ledger filename for a specific date
    
    Args:
        date_input: Date (string, date, or datetime object)
    
    Returns:
        Path object for ledger file
    """
    date_str = _ensure_date_string(date_input)
    return LEDGER_DIR / f"trade_ledger_{date_str}.json"


def load_ledger(date_input):
    """
    Load trade ledger for a specific date
    
    Args:
        date_input: Date (string, date, or datetime object)
    
    Returns:
        dict: Ledger data
    """
    date_str = _ensure_date_string(date_input)
    
    try:
        ledger_file = get_ledger_filename(date_str)
        
        if ledger_file.exists():
            with open(ledger_file, 'r') as f:
                ledger = json.load(f)
            print(f"[LEDGER] Loaded ledger for {date_str}")
            return ledger
        else:
            # Create new ledger
            ledger = {
                "date": date_str,
                "opening_balance": 0,
                "trades": {},
                "summary": {
                    "total_trades": 0,
                    "wins": 0,
                    "losses": 0,
                    "total_pnl": 0
                }
            }
            print(f"[LEDGER] Created new ledger for {date_str}")
            return ledger
            
    except Exception as e:
        print(f"[LEDGER] Error loading ledger: {e}")
        return {
            "date": date_str,
            "opening_balance": 0,
            "trades": {},
            "summary": {"total_trades": 0, "wins": 0, "losses": 0, "total_pnl": 0}
        }


def save_ledger(date_input, ledger_data):
    """
    Save trade ledger
    
    Args:
        date_input: Date (string, date, or datetime object)
        ledger_data: Ledger data dictionary
    """
    date_str = _ensure_date_string(date_input)
    
    try:
        ledger_file = get_ledger_filename(date_str)
        
        # Ensure date in ledger_data is string
        ledger_data["date"] = date_str
        
        with open(ledger_file, 'w') as f:
            json.dump(ledger_data, f, indent=2, default=str)  # default=str handles any remaining date objects
        
        print(f"[LEDGER] Saved ledger for {date_str}")
        return True
        
    except Exception as e:
        print(f"[LEDGER] Error saving ledger: {e}")
        return False


def create_ledger_entry(ticket, trade_data):
    """
    Create a ledger entry for a trade
    
    Args:
        ticket: Trade ticket number
        trade_data: Trade data dictionary
    
    Returns:
        dict: Ledger entry
    """
    return {
        "ticket": ticket,
        "date": _ensure_date_string(trade_data.get("date", datetime.now().strftime("%Y-%m-%d"))),
        "entry_time": trade_data.get("entry_time"),
        "entry_price": trade_data.get("entry_price"),
        "signal": trade_data.get("signal"),
        "lot_size": trade_data.get("lot_size"),
        "sl_price": trade_data.get("sl_price"),
        "tp_price": trade_data.get("tp_price"),
        "outcome": trade_data.get("outcome"),
        "close_time": trade_data.get("close_time"),
        "pnl": trade_data.get("pnl", 0),
        "balance": trade_data.get("balance", 0),
        "partial_close": trade_data.get("partial_close", False),
        "timestamp": datetime.now().isoformat()
    }


def add_trade_to_ledger(date_input, ticket, trade_data):
    """
    Add a trade to the ledger
    
    Args:
        date_input: Date (string, date, or datetime object)
        ticket: Trade ticket number
        trade_data: Trade data dictionary
    """
    date_str = _ensure_date_string(date_input)
    
    try:
        with LEDGER_LOCK:
            ledger = load_ledger(date_str)
            
            # Add trade entry
            ledger["trades"][str(ticket)] = create_ledger_entry(ticket, trade_data)
            
            # Update summary
            ledger["summary"]["total_trades"] = len(ledger["trades"])
            
            if trade_data.get("outcome") == "WIN":
                ledger["summary"]["wins"] = ledger["summary"].get("wins", 0) + 1
            elif trade_data.get("outcome") == "LOSS":
                ledger["summary"]["losses"] = ledger["summary"].get("losses", 0) + 1
            
            ledger["summary"]["total_pnl"] = sum(
                t.get("pnl", 0) for t in ledger["trades"].values()
            )
            
            # Save ledger
            save_ledger(date_str, ledger)
            
            print(f"[LEDGER] Added trade {ticket} to ledger")
            return True
            
    except Exception as e:
        print(f"[LEDGER] Error adding trade to ledger: {e}")
        return False


def update_trade_in_ledger(date_input, ticket, updates):
    """
    Update a trade in the ledger
    
    Args:
        date_input: Date (string, date, or datetime object)
        ticket: Trade ticket number
        updates: Dictionary of fields to update
    """
    date_str = _ensure_date_string(date_input)
    
    try:
        with LEDGER_LOCK:
            ledger = load_ledger(date_str)
            
            if str(ticket) in ledger["trades"]:
                ledger["trades"][str(ticket)].update(updates)
                save_ledger(date_str, ledger)
                print(f"[LEDGER] Updated trade {ticket} in ledger")
                return True
            else:
                print(f"[LEDGER] Trade {ticket} not found in ledger")
                return False
                
    except Exception as e:
        print(f"[LEDGER] Error updating trade in ledger: {e}")
        return False


def get_trade_from_ledger(date_input, ticket):
    """
    Get a trade from the ledger
    
    Args:
        date_input: Date (string, date, or datetime object)
        ticket: Trade ticket number
    
    Returns:
        dict: Trade data or None
    """
    date_str = _ensure_date_string(date_input)
    
    try:
        ledger = load_ledger(date_str)
        return ledger["trades"].get(str(ticket))
    except Exception as e:
        print(f"[LEDGER] Error getting trade from ledger: {e}")
        return None


def get_ledger_summary(date_input):
    """
    Get summary for a specific date
    
    Args:
        date_input: Date (string, date, or datetime object)
    
    Returns:
        dict: Summary data
    """
    date_str = _ensure_date_string(date_input)
    
    try:
        ledger = load_ledger(date_str)
        return ledger.get("summary", {})
    except Exception as e:
        print(f"[LEDGER] Error getting ledger summary: {e}")
        return {"total_trades": 0, "wins": 0, "losses": 0, "total_pnl": 0}


def get_ledger_trade(date_input, ticket):
    """
    Alias for get_trade_from_ledger - for backward compatibility
    
    Args:
        date_input: Date (string, date, or datetime object)
        ticket: Trade ticket number
    
    Returns:
        dict: Trade data or None
    """
    return get_trade_from_ledger(date_input, ticket)


def update_ledger_partial_close(date_input, ticket, partial_close_price, remaining_lot):
    """
    Update ledger when partial close occurs
    
    Args:
        date_input: Date (string, date, or datetime object)
        ticket: Trade ticket number
        partial_close_price: Price at which partial close occurred
        remaining_lot: Remaining lot size after partial close
    
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        updates = {
            "partial_close": True,
            "partial_close_price": partial_close_price,
            "remaining_lot": remaining_lot,
            "partial_close_time": datetime.now().isoformat()
        }
        return update_trade_in_ledger(date_input, ticket, updates)
    except Exception as e:
        print(f"[LEDGER] Error updating partial close: {e}")
        return False


def update_ledger_trade_close(date_input, ticket, outcome, close_price, close_time, pnl, balance):
    """
    Update ledger when trade closes
    
    Args:
        date_input: Date (string, date, or datetime object)
        ticket: Trade ticket number
        outcome: "WIN" or "LOSS"
        close_price: Price at which trade closed
        close_time: Time of close
        pnl: Profit/loss amount
        balance: Account balance after close
    
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        updates = {
            "outcome": outcome,
            "close_price": close_price,
            "close_time": close_time,
            "pnl": pnl,
            "balance": balance,
            "closed_at": datetime.now().isoformat()
        }
        return update_trade_in_ledger(date_input, ticket, updates)
    except Exception as e:
        print(f"[LEDGER] Error updating trade close: {e}")
        return False