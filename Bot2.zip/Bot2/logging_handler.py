"""Logging functionality for Trading Bot - FIXED"""
import csv
from datetime import date, datetime, timedelta
from pathlib import Path
import config  # Import module, not variables
from utils import fmt_date, parse_ist_hhmm, now_ist
from email_handler import send_email

def csv_path(d: date) -> Path:
    return config.LOG_DIR / f"trades_{fmt_date(d)}.csv"

def init_csv(d: date):
    p = csv_path(d)
    if not p.exists():
        with open(p, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(config.LOG_HEADER)

def append_csv(d: date, row: list):
    p = csv_path(d)
    try:
        with open(p, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(row)
    except Exception as e:
        print(f"[CSV] Failed to append: {e}")

def init_heartbeat_log(d: date):
    with config.HEARTBEAT_LOG_LOCK:
        if config.HEARTBEAT_LOG_FILE and not config.HEARTBEAT_LOG_FILE.closed:
            config.HEARTBEAT_LOG_FILE.close()
        
        log_path = config.HEARTBEAT_LOG_DIR / f"heartbeat_{fmt_date(d)}.log"
        config.HEARTBEAT_LOG_FILE = open(log_path, "a", encoding="utf-8")
        timestamp = now_ist().strftime("%Y-%m-%d %H:%M:%S")
        config.HEARTBEAT_LOG_FILE.write(f"{timestamp} | [START] Heartbeat log started for {fmt_date(d)}\n")
        config.HEARTBEAT_LOG_FILE.flush()

def write_heartbeat(message: str):
    with config.HEARTBEAT_LOG_LOCK:
        if config.HEARTBEAT_LOG_FILE and not config.HEARTBEAT_LOG_FILE.closed:
            timestamp = now_ist().strftime("%Y-%m-%d %H:%M:%S")
            config.HEARTBEAT_LOG_FILE.write(f"{timestamp} | {message}\n")
            config.HEARTBEAT_LOG_FILE.flush()
        else:
            timestamp = now_ist().strftime("%Y-%m-%d %H:%M:%S")
            print(f"[HEARTBEAT] {timestamp} | {message}")

def close_heartbeat_log():
    with config.HEARTBEAT_LOG_LOCK:
        if config.HEARTBEAT_LOG_FILE and not config.HEARTBEAT_LOG_FILE.closed:
            timestamp = now_ist().strftime("%Y-%m-%d %H:%M:%S")
            config.HEARTBEAT_LOG_FILE.write(f"{timestamp} | [END] Heartbeat log closed\n")
            config.HEARTBEAT_LOG_FILE.flush()
            config.HEARTBEAT_LOG_FILE.close()

def email_heartbeat_log_if_needed(ist_day: date):
    """Email previous day's heartbeat log at configured time - ONCE PER DAY
    
    CRITICAL FIX: Sets flag IMMEDIATELY on first call to prevent multiple sends.
    The function is called every second from main loop, so we need to ensure
    it only sends once at the configured time (default 12:00 AM).
    """
    
    # CRITICAL: Check if already emailed today FIRST
    if config.HEARTBEAT_LOG_EMAILED_TODAY:
        return  # Already sent today, don't check time
    
    ist_now = now_ist()
    email_hh, email_mm = parse_ist_hhmm(config.HEARTBEAT_LOG_EMAIL_TIME)
    
    # Check if it's the configured time
    if ist_now.hour == email_hh and ist_now.minute == email_mm:
        # IMMEDIATELY set flag to prevent race condition
        # This MUST happen BEFORE the email send attempt
        config.HEARTBEAT_LOG_EMAILED_TODAY = True
        
        prev_day = ist_day - timedelta(days=1)
        log_path = config.HEARTBEAT_LOG_DIR / f"heartbeat_{fmt_date(prev_day)}.log"
        
        if log_path.exists():
            try:
                send_email(
                    f"Heartbeat Log - {fmt_date(prev_day)}",
                    f"Attached is the heartbeat log for {fmt_date(prev_day)}",
                    log_path
                )
                print(f"[HEARTBEAT_LOG] ✓ Emailed log for {fmt_date(prev_day)}")
            except Exception as e:
                print(f"[HEARTBEAT_LOG] ✗ Email failed: {e}")
                # Flag is already set, so won't retry
        else:
            print(f"[HEARTBEAT_LOG] No log file found for {fmt_date(prev_day)}")

def reset_heartbeat_email_flag():
    """Reset the email flag for a new day - call on day rollover"""
    config.HEARTBEAT_LOG_EMAILED_TODAY = False