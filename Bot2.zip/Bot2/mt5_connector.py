"""
MT5 Connector with Multi-Instance Support
Allows multiple bots to run with separate MT5 installations
"""
import MetaTrader5 as mt5
from datetime import datetime
import time

# Global MT5 path (set from config)
MT5_PATH = None

def init_mt5(path=None, login=None, password=None, server=None, timeout=60000):
    """
    Initialize MT5 connection with optional specific path
    
    Args:
        path: Full path to terminal64.exe (e.g., "C:\\MT5_Vantage\\terminal64.exe")
        login: MT5 account number
        password: MT5 password
        server: MT5 server name
        timeout: Connection timeout in milliseconds
    
    Returns:
        bool: True if successful, False otherwise
    """
    global MT5_PATH
    
    # Store path for reconnections
    if path:
        MT5_PATH = path
    
    try:
        # Initialize with or without path
        if MT5_PATH:
            print(f"[MT5] Initializing with specific path: {MT5_PATH}")
            if not mt5.initialize(path=MT5_PATH, login=login, password=password, 
                                  server=server, timeout=timeout):
                error = mt5.last_error()
                print(f"[MT5] Initialize failed with path. Error: {error}")
                return False
        else:
            print(f"[MT5] Initializing with default MT5 installation")
            if not mt5.initialize(login=login, password=password, 
                                  server=server, timeout=timeout):
                error = mt5.last_error()
                print(f"[MT5] Initialize failed. Error: {error}")
                return False
        
        # Get account info
        account_info = mt5.account_info()
        if account_info is None:
            print(f"[MT5] Failed to get account info")
            return False
        
        print(f"[MT5] Connected successfully!")
        print(f"[MT5] Account: {account_info.login}")
        print(f"[MT5] Server: {account_info.server}")
        print(f"[MT5] Balance: ${account_info.balance:.2f}")
        
        return True
        
    except Exception as e:
        print(f"[MT5] Exception during initialization: {e}")
        return False


def shutdown_mt5():
    """Shutdown MT5 connection"""
    try:
        mt5.shutdown()
        print("[MT5] Connection closed")
        return True
    except Exception as e:
        print(f"[MT5] Error during shutdown: {e}")
        return False


def reconnect_mt5(login=None, password=None, server=None):
    """
    Reconnect to MT5 (useful after connection loss)
    Uses stored MT5_PATH if available
    """
    global MT5_PATH
    
    print("[MT5] Attempting to reconnect...")
    shutdown_mt5()
    time.sleep(2)
    
    return init_mt5(path=MT5_PATH, login=login, password=password, server=server)


def place_trade(symbol, order_type, lot_size, sl_price, tp_price, comment=""):
    """
    Place a trade on MT5
    
    Args:
        symbol: Trading symbol (e.g., "XAUUSD")
        order_type: mt5.ORDER_TYPE_BUY or mt5.ORDER_TYPE_SELL
        lot_size: Position size
        sl_price: Stop loss price
        tp_price: Take profit price
        comment: Trade comment
    
    Returns:
        int: Ticket number if successful, None otherwise
    """
    try:
        # Get current price
        tick = mt5.symbol_info_tick(symbol)
        if tick is None:
            print(f"[MT5] Failed to get tick for {symbol}")
            return None
        
        # Set price based on order type
        price = tick.ask if order_type == mt5.ORDER_TYPE_BUY else tick.bid
        
        # Prepare request
        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": lot_size,
            "type": order_type,
            "price": price,
            "sl": sl_price,
            "tp": tp_price,
            "deviation": 20,
            "magic": 234000,
            "comment": comment,
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        
        # Send order
        result = mt5.order_send(request)
        
        if result is None:
            print(f"[MT5] Order send returned None")
            return None
        
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            print(f"[MT5] Order failed: {result.retcode} - {result.comment}")
            return None
        
        print(f"[MT5] Order placed successfully! Ticket: {result.order}")
        return result.order
        
    except Exception as e:
        print(f"[MT5] Exception placing trade: {e}")
        return None


def verify_position_exists(ticket):
    """
    Check if position with given ticket exists
    
    Args:
        ticket: Position ticket number
    
    Returns:
        bool: True if position exists and is open, False otherwise
    """
    try:
        positions = mt5.positions_get(ticket=ticket)
        return positions is not None and len(positions) > 0
    except Exception as e:
        print(f"[MT5] Error checking position {ticket}: {e}")
        return False


def get_position(ticket):
    """
    Get position details by ticket
    
    Args:
        ticket: Position ticket number
    
    Returns:
        Position object or None
    """
    try:
        positions = mt5.positions_get(ticket=ticket)
        if positions and len(positions) > 0:
            return positions[0]
        return None
    except Exception as e:
        print(f"[MT5] Error getting position {ticket}: {e}")
        return None


def close_position(ticket, lot_size=None, comment="Close"):
    """
    Close a position (full or partial)
    
    Args:
        ticket: Position ticket number
        lot_size: Volume to close (None = close all)
        comment: Close comment
    
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        position = get_position(ticket)
        if position is None:
            print(f"[MT5] Position {ticket} not found")
            return False
        
        # Determine volume to close
        volume = lot_size if lot_size else position.volume
        
        # Determine opposite order type
        order_type = mt5.ORDER_TYPE_SELL if position.type == mt5.ORDER_TYPE_BUY else mt5.ORDER_TYPE_BUY
        
        # Get current price
        tick = mt5.symbol_info_tick(position.symbol)
        if tick is None:
            print(f"[MT5] Failed to get tick for {position.symbol}")
            return False
        
        price = tick.bid if order_type == mt5.ORDER_TYPE_SELL else tick.ask
        
        # Prepare close request
        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": position.symbol,
            "volume": volume,
            "type": order_type,
            "position": ticket,
            "price": price,
            "deviation": 20,
            "magic": 234000,
            "comment": comment,
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }
        
        # Send close order
        result = mt5.order_send(request)
        
        if result is None:
            print(f"[MT5] Close order send returned None")
            return False
        
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            print(f"[MT5] Close failed: {result.retcode} - {result.comment}")
            return False
        
        print(f"[MT5] Position {ticket} closed successfully!")
        return True
        
    except Exception as e:
        print(f"[MT5] Exception closing position {ticket}: {e}")
        return False


def get_balance():
    """Get current account balance"""
    try:
        account_info = mt5.account_info()
        if account_info:
            return account_info.balance
        return None
    except Exception as e:
        print(f"[MT5] Error getting balance: {e}")
        return None


def get_equity():
    """Get current account equity"""
    try:
        account_info = mt5.account_info()
        if account_info:
            return account_info.equity
        return None
    except Exception as e:
        print(f"[MT5] Error getting equity: {e}")
        return None


def get_symbol_info(symbol):
    """Get symbol information"""
    try:
        return mt5.symbol_info(symbol)
    except Exception as e:
        print(f"[MT5] Error getting symbol info for {symbol}: {e}")
        return None


def get_tick(symbol):
    """Get latest tick for symbol"""
    try:
        return mt5.symbol_info_tick(symbol)
    except Exception as e:
        print(f"[MT5] Error getting tick for {symbol}: {e}")
        return None


def close_position_partial(ticket, volume, comment="Partial Close"):
    """
    Close partial position
    
    Args:
        ticket: Position ticket number
        volume: Volume to close
        comment: Close comment
    
    Returns:
        bool: True if successful, False otherwise
    """
    return close_position(ticket=ticket, lot_size=volume, comment=comment)


def compute_sl_tp(entry_price, signal, sl_pips, tp_pips, pip_value=0.10):
    """
    Compute SL and TP prices based on entry price and pips
    
    Args:
        entry_price: Entry price
        signal: "BUY" or "SELL"
        sl_pips: Stop loss in pips
        tp_pips: Take profit in pips
        pip_value: Value of 1 pip (default 0.10 for gold)
    
    Returns:
        tuple: (sl_price, tp_price)
    """
    if signal == "BUY":
        sl_price = entry_price - (sl_pips * pip_value)
        tp_price = entry_price + (tp_pips * pip_value)
    else:  # SELL
        sl_price = entry_price + (sl_pips * pip_value)
        tp_price = entry_price - (tp_pips * pip_value)
    
    return sl_price, tp_price


def modify_position(ticket, sl_price=None, tp_price=None):
    """
    Modify SL/TP of an existing position
    
    Args:
        ticket: Position ticket number
        sl_price: New stop loss price (None = keep current)
        tp_price: New take profit price (None = keep current)
    
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        position = get_position(ticket)
        if position is None:
            print(f"[MT5] Position {ticket} not found")
            return False
        
        # Use current values if not specified
        if sl_price is None:
            sl_price = position.sl
        if tp_price is None:
            tp_price = position.tp
        
        # Prepare modification request
        request = {
            "action": mt5.TRADE_ACTION_SLTP,
            "position": ticket,
            "sl": sl_price,
            "tp": tp_price,
        }
        
        # Send modification
        result = mt5.order_send(request)
        
        if result is None:
            print(f"[MT5] Modify order send returned None")
            return False
        
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            print(f"[MT5] Modify failed: {result.retcode} - {result.comment}")
            return False
        
        print(f"[MT5] Position {ticket} modified successfully! SL: {sl_price}, TP: {tp_price}")
        return True
        
    except Exception as e:
        print(f"[MT5] Exception modifying position {ticket}: {e}")
        return False


# For backward compatibility
def mt5_init(path=None, login=None, password=None, server=None):
    """Alias for init_mt5"""
    return init_mt5(path=path, login=login, password=password, server=server)


def mt5_shutdown():
    """Alias for shutdown_mt5"""
    return shutdown_mt5()
