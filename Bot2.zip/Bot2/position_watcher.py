"""Position watcher with WordPress integration - FIXED VERSION"""
import MetaTrader5 as mt5
import threading
import time as _time
from datetime import datetime, timedelta, date
from config import (
    SYMBOL, MAGIC, MAX_POSITION_HOLD_HOURS, PARTIAL_CLOSE_TRIGGER_PIPS,
    PARTIAL_CLOSE_PERCENTAGE_EVEN, PARTIAL_CLOSE_PERCENTAGE_ODD,
    ACTIVE_WATCHERS, WATCHERS_LOCK, TRADES_CLOSED_TODAY, TRADES_LOCK,
    RUN_HEARTBEAT, LAST_SLOT_CLOSED, LAST_SLOT_CLOSE_TIME, LAST_SLOT_TIME,
    LEDGER_LOCK, LEDGER_DATA, PIP_SIZE
)
from mt5_connector import close_position_partial
from trading_logic import compute_sl_tp
from ledger import update_ledger_partial_close, update_ledger_trade_close, save_ledger
from logging_handler import append_csv, write_heartbeat
from utils import now_ist
from email_handler import send_email

# Import WordPress integration
from wordpress_integration import wp_save_trade, wp_update_position, wp_remove_position, wp_send_push_notification

# Lock for partial close operations to prevent race conditions
from threading import Lock
PARTIAL_CLOSE_LOCK = Lock()


def get_ledger_entry_by_ticket(ticket: int) -> dict:
    """
    Find ledger entry by position ticket.
    First checks if ticket is used as key, then searches by position_id field.
    Handles both old field names (sl, tp, volume) and new ones (sl_price, tp_price, lot_size).
    """
    with LEDGER_LOCK:
        trades = LEDGER_DATA.get("trades", {})
        
        # Method 1: Check if ticket is the key directly
        if str(ticket) in trades:
            entry = trades[str(ticket)]
            return _normalize_ledger_entry(str(ticket), entry)
        
        # Method 2: Search by position_id field
        for tag, entry in trades.items():
            pos_id = entry.get("position_id") or entry.get("ticket")
            if pos_id == ticket:
                return _normalize_ledger_entry(tag, entry)
    
    return None


def _normalize_ledger_entry(tag: str, entry: dict) -> dict:
    """Normalize field names for compatibility with both old and new formats."""
    return {
        "trade_number": entry.get("trade_number", 0),
        "entry_time": entry.get("entry_time", ""),
        "entry_price": entry.get("entry_price", 0.0),
        "sl": entry.get("sl_price") or entry.get("sl", 0.0),
        "tp": entry.get("tp_price") or entry.get("tp", 0.0),
        "volume": entry.get("lot_size") or entry.get("volume", 0.0),
        "signal": entry.get("signal", ""),
        "tag": entry.get("tag") or tag,
        "partial_close_price": entry.get("partial_close_price"),
    }


def spawn_watcher(ticket: int, signal: str, tag: str, ist_day: date):
    """Spawn a watcher thread for a position - prevents duplicates"""
    
    # Check if watcher already exists for this ticket
    with WATCHERS_LOCK:
        if ticket in ACTIVE_WATCHERS:
            existing_thread = ACTIVE_WATCHERS[ticket]
            if existing_thread.is_alive():
                print(f"[WATCHER-{ticket}] Already exists and running - skipping duplicate")
                return
            else:
                # Remove dead thread reference
                del ACTIVE_WATCHERS[ticket]
    
    watcher_thread = threading.Thread(
        target=position_watcher,
        args=(ticket, signal, tag, ist_day),
        daemon=True
    )
    
    with WATCHERS_LOCK:
        ACTIVE_WATCHERS[ticket] = watcher_thread
    
    watcher_thread.start()
    print(f"[WATCHER-{ticket}] Spawned watcher thread")

def position_watcher(ticket: int, signal: str, tag: str, ist_day: date):
    """Monitor a position for partial close and final close"""
    global LAST_SLOT_CLOSED, LAST_SLOT_CLOSE_TIME
    
    print(f"[WATCHER-{ticket}] Started monitoring")
    write_heartbeat(f"[WATCHER-{ticket}] Started")
    
    partial_close_done = False
    reanchored = False  # Track if SL/TP has been reanchored
    start_time = datetime.now()
    timeout = timedelta(hours=MAX_POSITION_HOLD_HOURS)
    
    try:
        while RUN_HEARTBEAT.is_set():
            if datetime.now() - start_time > timeout:
                print(f"[WATCHER-{ticket}] Timeout reached")
                write_heartbeat(f"[WATCHER-{ticket}] Timeout")
                break
            
            positions = mt5.positions_get(ticket=ticket)
            
            if not positions:
                # Position closed - update WordPress
                print(f"[WATCHER-{ticket}] Position closed")
                
                # FIXED: Use helper function instead of get_ledger_trade
                ledger_entry = get_ledger_entry_by_ticket(ticket)
                
                if ledger_entry:
                    trade_number = ledger_entry["trade_number"]
                    entry_time = ledger_entry["entry_time"]
                    entry_price = ledger_entry["entry_price"]
                    sl_price = ledger_entry["sl"]
                    tp_price = ledger_entry["tp"]
                    lot_size = ledger_entry["volume"]
                    partial_close_price = ledger_entry.get("partial_close_price")
                    
                    # Get close details from MT5
                    deals = mt5.history_deals_get(position=ticket)
                    close_price = None
                    close_time = None
                    pnl = 0.0
                    outcome = "UNKNOWN"
                    
                    if deals:
                        for deal in deals:
                            if getattr(deal, "entry", -1) == 1:
                                close_price = getattr(deal, "price", 0.0)
                                close_time = datetime.fromtimestamp(getattr(deal, "time", 0)).strftime("%H:%M:%S")
                                pnl += getattr(deal, "profit", 0.0)
                        
                        if close_price:
                            if signal == "BUY":
                                if close_price >= tp_price - 0.05:
                                    outcome = "TP"
                                elif close_price <= sl_price + 0.05:
                                    outcome = "SL"
                                else:
                                    outcome = "MANUAL"
                            else:
                                if close_price <= tp_price + 0.05:
                                    outcome = "TP"
                                elif close_price >= sl_price - 0.05:
                                    outcome = "SL"
                                else:
                                    outcome = "MANUAL"
                    
                    # Get balance
                    account_info = mt5.account_info()
                    balance = account_info.balance if account_info else 0.0
                    
                    # Update ledger
                    date_str = ist_day.strftime("%Y-%m-%d") if hasattr(ist_day, 'strftime') else str(ist_day)
                    update_ledger_trade_close(date_str, ticket, outcome, close_price or 0.0, close_time or now_ist().strftime("%H:%M:%S"), pnl, balance)
                    
                    # Save to WordPress (with error handling)
                    try:
                        wp_save_trade(
                            ticket=ticket,
                            trade_date=ist_day.strftime("%Y-%m-%d"),
                            trade_number=trade_number,
                            entry_time=entry_time,
                            entry_price=entry_price,
                            sl_price=sl_price,
                            tp_price=tp_price,
                            lot_size=lot_size,
                            signal=signal,
                            outcome=outcome,
                            partial_close='YES' if partial_close_price else 'NO',
                            partial_close_price=partial_close_price,
                            close_time=close_time,
                            pnl=pnl,
                            balance=balance,
                            tag=tag
                        )
                    except Exception:
                        pass
                    
                    # Remove from positions
                    try:
                        wp_remove_position(ticket)
                    except Exception:
                        pass
                    
                    # Log to CSV
                    row = [
                        ist_day.strftime("%d-%m-%Y"),
                        trade_number,
                        entry_time,
                        f"{entry_price:.2f}",
                        f"{sl_price:.2f}",
                        f"{tp_price:.2f}",
                        f"{partial_close_price:.2f}" if partial_close_price else "-",
                        f"{lot_size:.2f}",
                        outcome,
                        "YES" if partial_close_price else "NO",
                        f"{pnl:.2f}",
                        f"{balance:.2f}"
                    ]
                    
                    append_csv(ist_day, row)
                    
                    print(f"[WATCHER-{ticket}] Logged: {outcome}, PnL=${pnl:.2f}")
                    write_heartbeat(f"[WATCHER-{ticket}] Closed: {outcome}, PnL=${pnl:.2f}")
                    
                    # Send push notification for SL/TP hit
                    try:
                        if outcome == 'TP':
                            wp_send_push_notification(
                                'tp_hit',
                                '🟢 Take Profit Hit',
                                f'Profit: ${pnl:.2f} | Ticket #{ticket}'
                            )
                        elif outcome == 'SL':
                            wp_send_push_notification(
                                'sl_hit',
                                '🔴 Stop Loss Hit',
                                f'Loss: ${abs(pnl):.2f} | Ticket #{ticket}'
                            )
                    except Exception:
                        pass
                else:
                    print(f"[WATCHER-{ticket}] No ledger entry found - position closed externally")
                    write_heartbeat(f"[WATCHER-{ticket}] Closed (no ledger entry)")
                
                with TRADES_LOCK:
                    global TRADES_CLOSED_TODAY
                    TRADES_CLOSED_TODAY += 1
                
                if ledger_entry and ledger_entry.get("entry_time") == LAST_SLOT_TIME:
                    LAST_SLOT_CLOSED = True
                    LAST_SLOT_CLOSE_TIME = datetime.now()
                    print(f"[WATCHER-{ticket}] Last slot closed")
                    write_heartbeat(f"[WATCHER-{ticket}] Last slot closed")
                
                break
            
            # Check for partial close and update WordPress
            if not partial_close_done:
                pos = positions[0]
                current_volume = pos.volume
                entry_price = pos.price_open
                
                tick = mt5.symbol_info_tick(SYMBOL)
                if tick:
                    current_price = tick.bid if signal == "BUY" else tick.ask
                    
                    # Calculate profit in pips using PIP_SIZE from config
                    if signal == "BUY":
                        profit_pips = (current_price - entry_price) / PIP_SIZE
                    else:
                        profit_pips = (entry_price - current_price) / PIP_SIZE
                    
                    # Calculate current PnL
                    current_pnl = profit_pips * PIP_SIZE * current_volume * 100
                    
                    # Update WordPress position with current data (every 5 iterations to reduce DB load)
                    if not hasattr(position_watcher, '_wp_counter'):
                        position_watcher._wp_counter = 0
                    position_watcher._wp_counter += 1
                    
                    if position_watcher._wp_counter >= 5:  # Update every 5 seconds instead of every second
                        position_watcher._wp_counter = 0
                        ledger_entry = get_ledger_entry_by_ticket(ticket)
                        if ledger_entry:
                            try:
                                wp_update_position(
                                    ticket=ticket,
                                    signal=signal,
                                    entry_price=entry_price,
                                    current_price=current_price,
                                    sl_price=ledger_entry["sl"],
                                    tp_price=ledger_entry["tp"],
                                    lot_size=current_volume,
                                    current_pnl=current_pnl,
                                    partial_closed=False,
                                    opened_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                                )
                            except Exception as e:
                                pass  # Silently fail - don't spam logs
                    
                    # Check for partial close trigger at +50 pips
                    if profit_pips >= PARTIAL_CLOSE_TRIGGER_PIPS:
                        # Use lock to prevent double partial close
                        with PARTIAL_CLOSE_LOCK:
                            # Double-check partial_close_done inside lock
                            if partial_close_done:
                                continue
                            
                            lot_int = int(current_volume / 0.01)
                            is_even = (lot_int % 2 == 0)
                            
                            close_pct = PARTIAL_CLOSE_PERCENTAGE_EVEN if is_even else PARTIAL_CLOSE_PERCENTAGE_ODD
                            close_volume = round(current_volume * close_pct, 2)
                            
                            if close_volume >= 0.01 and close_volume < current_volume:
                                print(f"[WATCHER-{ticket}] +{profit_pips:.1f} pips - Triggering partial close of {close_volume:.2f} lots")
                                
                                result = close_position_partial(ticket, close_volume, signal)
                                
                                # close_position_partial returns True/False, not MT5 result object
                                if result == True:
                                    partial_close_done = True
                                    
                                    # Fix: Correct argument order - (date_str, ticket, price, remaining_lot)
                                    date_str = ist_day.strftime("%Y-%m-%d") if hasattr(ist_day, 'strftime') else str(ist_day)
                                    remaining_lot = current_volume - close_volume
                                    update_ledger_partial_close(date_str, ticket, current_price, remaining_lot)
                                    
                                    # Update WordPress with partial close
                                    if ledger_entry:
                                        try:
                                            wp_update_position(
                                                ticket=ticket,
                                                signal=signal,
                                                entry_price=entry_price,
                                                current_price=current_price,
                                                sl_price=ledger_entry["sl"],
                                                tp_price=ledger_entry["tp"],
                                                lot_size=current_volume - close_volume,
                                                current_pnl=current_pnl,
                                                partial_closed=True,
                                                opened_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                                            )
                                        except Exception:
                                            pass  # Silently fail
                                    
                                    print(f"[WATCHER-{ticket}] ✓ Partial close SUCCESS: {close_volume:.2f} lots at +{profit_pips:.1f} pips")
                                    write_heartbeat(f"[WATCHER-{ticket}] Partial: {close_volume:.2f} lots at +{profit_pips:.1f} pips")
                                    
                                    # Send push notification for partial close
                                    try:
                                        wp_send_push_notification(
                                            'partial_close',
                                            '✂️ Partial Close Triggered',
                                            f'+{profit_pips:.0f} pips | Closed {close_volume:.2f} lots | Ticket #{ticket}'
                                        )
                                    except Exception:
                                        pass
                                else:
                                    print(f"[WATCHER-{ticket}] Partial close FAILED")
                                    write_heartbeat(f"[WATCHER-{ticket}] Partial close failed")
            
            # Reanchor SL/TP based on actual entry price (only once)
            if not reanchored:
                try:
                    pos = positions[0]
                    entry = float(pos.price_open)
                    current_sl = float(pos.sl)
                    current_tp = float(pos.tp)
                    expected_sl, expected_tp = compute_sl_tp(entry, signal)
                    
                    sl_diff = abs(current_sl - expected_sl)
                    tp_diff = abs(current_tp - expected_tp)
                    
                    # Only reanchor if difference is significant but not too large (external modification)
                    if sl_diff > 0.5 or tp_diff > 0.5:
                        print(f"[WATCHER-{ticket}] External modification detected - skipping reanchor")
                        write_heartbeat(f"[WATCHER-{ticket}] External SL/TP modification detected")
                    else:
                        req = {
                            "action": mt5.TRADE_ACTION_SLTP,
                            "symbol": SYMBOL,
                            "position": ticket,
                            "sl": float(expected_sl),
                            "tp": float(expected_tp),
                            "magic": MAGIC
                        }
                        res = mt5.order_send(req)
                        ret = getattr(res, 'retcode', None)
                        
                        # 10009 = DONE, 10025 = NO_CHANGES (already correct)
                        if ret == mt5.TRADE_RETCODE_DONE or ret == 10025:
                            if ret == 10025:
                                print(f"[WATCHER-{ticket}] SL/TP already correct (no changes needed)")
                                write_heartbeat(f"[WATCHER-{ticket}] SL/TP verified correct")
                            else:
                                print(f"[WATCHER-{ticket}] Reanchored SL={expected_sl:.2f} TP={expected_tp:.2f}")
                                write_heartbeat(f"[WATCHER-{ticket}] Reanchored SL/TP successfully")
                            
                            # Update ledger with correct SL/TP
                            with LEDGER_LOCK:
                                for ltag, lentry in LEDGER_DATA.get("trades", {}).items():
                                    pos_id = lentry.get("position_id") or lentry.get("ticket")
                                    if pos_id == ticket:
                                        # Update both old and new field names
                                        lentry["sl"] = expected_sl
                                        lentry["sl_price"] = expected_sl
                                        lentry["tp"] = expected_tp
                                        lentry["tp_price"] = expected_tp
                                        lentry["entry_price"] = entry
                                        save_ledger(ist_day, LEDGER_DATA)
                                        break
                        else:
                            print(f"[WATCHER-{ticket}] Reanchor failed: ret={ret}")
                            write_heartbeat(f"[WATCHER-{ticket}] Reanchor failed: {ret}")
                    
                    reanchored = True
                except Exception as e:
                    print(f"[WATCHER-{ticket}] Reanchor error: {e}")
                    write_heartbeat(f"[WATCHER-{ticket}] Reanchor error: {e}")
                    reanchored = True  # Don't retry on error
            
            _time.sleep(1)  # Check every 1 second
    
    except Exception as e:
        print(f"[WATCHER-{ticket}] Error: {e}")
        write_heartbeat(f"[WATCHER-{ticket}] Error: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        with WATCHERS_LOCK:
            ACTIVE_WATCHERS.pop(ticket, None)
        
        print(f"[WATCHER-{ticket}] Stopped")
        write_heartbeat(f"[WATCHER-{ticket}] Stopped")