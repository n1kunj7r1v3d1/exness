"""
Report Generator Module - FIXED
Creates daily/weekly/monthly trading reports and sends via email
"""
import MetaTrader5 as mt5
import csv
from datetime import datetime, date, timedelta
import time as _time
from pathlib import Path
from typing import List
from config import (
    LOG_DIR, LOG_HEADER, SYMBOL, MAGIC, IST_TZ,
    REPORT_HISTORY_WAIT_MINUTES, REPORT_VERIFICATION_RETRIES,
    REPORT_WAIT_TRIGGERED, REPORT_WAIT_START_TIME, REPORT_WAIT_LOCK,
    SKIPPED_SLOTS, SKIPPED_SLOTS_LOCK, EMAIL_SENT_TODAY,
    LAST_SLOT_CLOSED, LAST_SLOT_TIME, LAST_SLOT_CLOSE_TIME,
    REPORT_WAIT_AFTER_LAST_CLOSE, LEDGER_DATA, LEDGER_LOCK
)
from utils import fmt_date
from email_handler import send_email
from balance_manager import get_withdrawals_for_period
from ledger_manager import load_ledger, save_ledger, get_ledger_filepath
from mt5_manager import _ist_from_epoch

def generate_daily_report_csv(ist_day: date, executed_slots: set) -> Path:
    """
    Generate daily CSV report from ledger data.
    Returns the path to the generated CSV file.
    """
    daily_file = LOG_DIR / f"daily_report_{fmt_date(ist_day)}.csv"
    
    # Get trades from ledger
    with LEDGER_LOCK:
        trades = []
        for tag, entry in sorted(LEDGER_DATA["trades"].items()):
            if entry["status"] == "CLOSED":
                trades.append(entry)
    
    trades.sort(key=lambda x: x["trade_number"])
    
    # Get skipped slots
    with SKIPPED_SLOTS_LOCK:
        skipped_dict = dict(SKIPPED_SLOTS)
    
    # Write CSV with UTF-8 encoding
    with open(daily_file, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(LOG_HEADER)
        
        # Write trades
        for tr in trades:
            partial_close_price_str = f"{tr.get('partial_close_price'):.3f}" if tr.get('partial_close_price') else ""
            partial_close_net_str = f"${tr.get('partial_close_net'):.2f}" if tr.get('partial_close_net') is not None else ""
            
            w.writerow([
                tr["date"], str(tr["trade_number"]), tr["entry_time"],
                f"{tr['entry_price']:.3f}", f"{tr['sl_price']:.3f}", f"{tr['tp_price']:.3f}",
                partial_close_price_str,
                f"{tr['lot_size']:.2f}", tr["trade_outcome"],
                partial_close_net_str,
                f"${tr['pnl']:.2f}", f"${tr['account_balance']:.2f}"
            ])
        
        # Add summary
        blank = [""] * len(LOG_HEADER)
        w.writerow(blank)
        
        # Trade count
        count_row = [""] * len(LOG_HEADER)
        count_row[8] = f"Trades executed: {len(trades)}/18"
        w.writerow(count_row)
        
        # Opening/Closing balance
        opening = LEDGER_DATA.get("opening_balance", 0.0)
        closing = LEDGER_DATA.get("closing_balance", 0.0)
        pnl = closing - opening
        
        open_row = [""] * len(LOG_HEADER)
        open_row[8] = "Opening Balance"
        open_row[11] = f"${opening:.2f}"
        w.writerow(open_row)
        
        close_row = [""] * len(LOG_HEADER)
        close_row[8] = "Closing Balance"
        close_row[11] = f"${closing:.2f}"
        w.writerow(close_row)
        
        pnl_row = [""] * len(LOG_HEADER)
        pnl_row[8] = "Daily P&L"
        pnl_row[11] = f"${pnl:.2f}" if pnl >= 0 else f"-${abs(pnl):.2f}"
        w.writerow(pnl_row)
        
        # Win/Loss stats
        wins = sum(1 for t in trades if t.get('pnl', 0) > 0)
        losses = sum(1 for t in trades if t.get('pnl', 0) < 0)
        win_rate = (wins / len(trades) * 100) if trades else 0
        
        w.writerow(blank)
        stats_row = [""] * len(LOG_HEADER)
        stats_row[8] = f"Wins: {wins} | Losses: {losses} | Win Rate: {win_rate:.1f}%"
        w.writerow(stats_row)
        
        # Skipped slots
        if skipped_dict:
            w.writerow(blank)
            skip_header = [""] * len(LOG_HEADER)
            skip_header[8] = f"⚠ Skipped Slots ({len(skipped_dict)}/18)"
            w.writerow(skip_header)
            
            for slot_time in sorted(skipped_dict.keys()):
                reason = skipped_dict[slot_time]
                skip_row = [""] * len(LOG_HEADER)
                skip_row[8] = f"{slot_time} IST: {reason}"
                w.writerow(skip_row)
    
    return daily_file

def generate_weekly_report(end_date: date) -> Path:
    """
    Generate weekly report for the past 7 days.
    Returns the path to the generated report.
    """
    start_date = end_date - timedelta(days=6)
    weekly_file = LOG_DIR / f"weekly_report_{fmt_date(start_date)}_to_{fmt_date(end_date)}.csv"
    
    # Collect all trades from past 7 days
    all_trades = []
    daily_pnls = []
    
    for day_offset in range(7):
        day = start_date + timedelta(days=day_offset)
        ledger_data = load_ledger(day)
        
        day_pnl = 0
        for tag, entry in ledger_data.get("trades", {}).items():
            if entry.get("status") == "CLOSED":
                all_trades.append({**entry, "date": day})
                if entry.get("pnl"):
                    day_pnl += entry["pnl"]
        
        daily_pnls.append({"date": day, "pnl": day_pnl})
    
    # Write report
    with open(weekly_file, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        
        # Header
        w.writerow(["NEXUS PRO - WEEKLY TRADING REPORT"])
        w.writerow([f"Period: {fmt_date(start_date)} to {fmt_date(end_date)}"])
        w.writerow([])
        
        # Summary stats
        total_trades = len(all_trades)
        wins = sum(1 for t in all_trades if t.get('pnl', 0) > 0)
        losses = sum(1 for t in all_trades if t.get('pnl', 0) < 0)
        total_pnl = sum(t.get('pnl', 0) for t in all_trades)
        win_rate = (wins / total_trades * 100) if total_trades > 0 else 0
        
        w.writerow(["SUMMARY"])
        w.writerow(["Total Trades:", total_trades])
        w.writerow(["Wins:", wins])
        w.writerow(["Losses:", losses])
        w.writerow(["Win Rate:", f"{win_rate:.1f}%"])
        w.writerow(["Total P&L:", f"${total_pnl:.2f}"])
        w.writerow([])
        
        # Daily breakdown
        w.writerow(["DAILY BREAKDOWN"])
        w.writerow(["Date", "P&L"])
        for day_data in daily_pnls:
            w.writerow([fmt_date(day_data["date"]), f"${day_data['pnl']:.2f}"])
        w.writerow([])
        
        # All trades
        w.writerow(["ALL TRADES"])
        w.writerow(["Date", "Trade#", "Entry Time", "Entry Price", "SL", "TP", "Lot Size", "Outcome", "P&L", "Balance"])
        
        for t in sorted(all_trades, key=lambda x: (x["date"], x.get("trade_number", 0))):
            w.writerow([
                fmt_date(t["date"]),
                t.get("trade_number", ""),
                t.get("entry_time", ""),
                f"{t.get('entry_price', 0):.3f}",
                f"{t.get('sl_price', 0):.3f}",
                f"{t.get('tp_price', 0):.3f}",
                f"{t.get('lot_size', 0):.2f}",
                t.get("trade_outcome", ""),
                f"${t.get('pnl', 0):.2f}",
                f"${t.get('account_balance', 0):.2f}"
            ])
    
    return weekly_file

def generate_monthly_report(end_date: date) -> Path:
    """
    Generate monthly report for the past 30 days.
    Returns the path to the generated report.
    """
    start_date = end_date - timedelta(days=29)
    monthly_file = LOG_DIR / f"monthly_report_{fmt_date(start_date)}_to_{fmt_date(end_date)}.csv"
    
    # Collect all trades from past 30 days
    all_trades = []
    daily_pnls = []
    
    for day_offset in range(30):
        day = start_date + timedelta(days=day_offset)
        ledger_data = load_ledger(day)
        
        day_pnl = 0
        for tag, entry in ledger_data.get("trades", {}).items():
            if entry.get("status") == "CLOSED":
                all_trades.append({**entry, "date": day})
                if entry.get("pnl"):
                    day_pnl += entry["pnl"]
        
        daily_pnls.append({"date": day, "pnl": day_pnl})
    
    # Write report
    with open(monthly_file, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        
        # Header
        w.writerow(["NEXUS PRO - MONTHLY TRADING REPORT"])
        w.writerow([f"Period: {fmt_date(start_date)} to {fmt_date(end_date)}"])
        w.writerow([])
        
        # Summary stats
        total_trades = len(all_trades)
        wins = sum(1 for t in all_trades if t.get('pnl', 0) > 0)
        losses = sum(1 for t in all_trades if t.get('pnl', 0) < 0)
        total_pnl = sum(t.get('pnl', 0) for t in all_trades)
        win_rate = (wins / total_trades * 100) if total_trades > 0 else 0
        
        avg_win = sum(t.get('pnl', 0) for t in all_trades if t.get('pnl', 0) > 0) / wins if wins > 0 else 0
        avg_loss = abs(sum(t.get('pnl', 0) for t in all_trades if t.get('pnl', 0) < 0)) / losses if losses > 0 else 0
        profit_factor = avg_win / avg_loss if avg_loss > 0 else 0
        
        w.writerow(["SUMMARY"])
        w.writerow(["Total Trades:", total_trades])
        w.writerow(["Wins:", wins])
        w.writerow(["Losses:", losses])
        w.writerow(["Win Rate:", f"{win_rate:.1f}%"])
        w.writerow(["Total P&L:", f"${total_pnl:.2f}"])
        w.writerow(["Average Win:", f"${avg_win:.2f}"])
        w.writerow(["Average Loss:", f"${avg_loss:.2f}"])
        w.writerow(["Profit Factor:", f"{profit_factor:.2f}"])
        w.writerow([])
        
        # Weekly breakdown
        w.writerow(["WEEKLY BREAKDOWN"])
        w.writerow(["Week", "P&L"])
        for week_num in range(4):
            week_start = start_date + timedelta(days=week_num * 7)
            week_end = min(week_start + timedelta(days=6), end_date)
            week_pnl = sum(d["pnl"] for d in daily_pnls 
                          if week_start <= d["date"] <= week_end)
            w.writerow([f"Week {week_num + 1} ({fmt_date(week_start)} to {fmt_date(week_end)})", 
                       f"${week_pnl:.2f}"])
        w.writerow([])
        
        # Daily breakdown (condensed)
        w.writerow(["DAILY BREAKDOWN"])
        w.writerow(["Date", "Trades", "P&L"])
        daily_stats = {}
        for t in all_trades:
            d = t["date"]
            if d not in daily_stats:
                daily_stats[d] = {"trades": 0, "pnl": 0}
            daily_stats[d]["trades"] += 1
            daily_stats[d]["pnl"] += t.get("pnl", 0)
        
        for day in sorted(daily_stats.keys()):
            stats = daily_stats[day]
            w.writerow([fmt_date(day), stats["trades"], f"${stats['pnl']:.2f}"])
    
    return monthly_file

def send_daily_report(ist_day: date, executed_slots: set):
    """Send daily trading report via email"""
    try:
        report_file = generate_daily_report_csv(ist_day, executed_slots)
        executed_count = len(executed_slots)
        
        subject = f"Daily Report - {fmt_date(ist_day)} ({executed_count}/18 trades)"
        body = (
            f"Daily trading report for {fmt_date(ist_day)}\n\n"
            f"Trades executed: {executed_count}/18\n"
            f"See attached CSV for full details."
        )
        
        send_email(subject, body, report_file)
        print(f"[REPORT] ✓ Daily report sent for {fmt_date(ist_day)}")
        return True
    except Exception as e:
        print(f"[REPORT] ✗ Daily report failed: {e}")
        return False

def send_weekly_report(end_date: date):
    """Send weekly trading report via email"""
    try:
        report_file = generate_weekly_report(end_date)
        start_date = end_date - timedelta(days=6)
        
        subject = f"Weekly Report - {fmt_date(start_date)} to {fmt_date(end_date)}"
        body = (
            f"Weekly trading report for period:\n"
            f"{fmt_date(start_date)} to {fmt_date(end_date)}\n\n"
            f"See attached CSV for full details."
        )
        
        send_email(subject, body, report_file)
        print(f"[REPORT] ✓ Weekly report sent")
        return True
    except Exception as e:
        print(f"[REPORT] ✗ Weekly report failed: {e}")
        return False

def send_monthly_report(end_date: date):
    """Send monthly trading report via email"""
    try:
        report_file = generate_monthly_report(end_date)
        start_date = end_date - timedelta(days=29)
        
        subject = f"Monthly Report - {fmt_date(start_date)} to {fmt_date(end_date)}"
        body = (
            f"Monthly trading report for period:\n"
            f"{fmt_date(start_date)} to {fmt_date(end_date)}\n\n"
            f"See attached CSV for full details."
        )
        
        send_email(subject, body, report_file)
        print(f"[REPORT] ✓ Monthly report sent")
        return True
    except Exception as e:
        print(f"[REPORT] ✗ Monthly report failed: {e}")
        return False

def send_reports(ist_day: date, executed_slots: set, today_server_sched: dict):
    """
    Generate and send daily/weekly/monthly reports.
    Called at end of trading day after all positions closed.
    """
    print(f"[REPORT] Generating reports for {fmt_date(ist_day)}")
    
    # Always send daily report
    send_daily_report(ist_day, executed_slots)
    
    # Send weekly report on Fridays (weekday 4)
    if ist_day.weekday() == 4:
        print("[REPORT] Friday detected - generating weekly report")
        send_weekly_report(ist_day)
    
    # Send monthly report on last day of month
    next_day = ist_day + timedelta(days=1)
    if next_day.month != ist_day.month:
        print("[REPORT] End of month detected - generating monthly report")
        send_monthly_report(ist_day)

def check_day_end_conditions(ist_day: date, executed_slots: set, today_server_sched: dict):
    """
    Smart report generation with time-based trigger.
    Waits for last slot to close then sends reports.
    """
    global EMAIL_SENT_TODAY, REPORT_WAIT_TRIGGERED, REPORT_WAIT_START_TIME, LAST_SLOT_CLOSED
    
    if EMAIL_SENT_TODAY:
        return
    
    # Check: Was last slot (20:35) executed?
    if LAST_SLOT_TIME not in executed_slots:
        return
    
    # Check: Did 20:35 position close?
    if not LAST_SLOT_CLOSED:
        return
    
    # Start 2-minute countdown
    with REPORT_WAIT_LOCK:
        if not REPORT_WAIT_TRIGGERED:
            REPORT_WAIT_TRIGGERED = True
            REPORT_WAIT_START_TIME = LAST_SLOT_CLOSE_TIME
            print(f"\n{'='*60}")
            print(f"[REPORT] Last slot ({LAST_SLOT_TIME}) position closed")
            print(f"[REPORT] Waiting {REPORT_WAIT_AFTER_LAST_CLOSE} seconds for history sync...")
            print(f"{'='*60}\n")
            return
        
        # Check if 2 minutes elapsed
        elapsed_seconds = _time.time() - REPORT_WAIT_START_TIME
        if elapsed_seconds < REPORT_WAIT_AFTER_LAST_CLOSE:
            return
    
    # 2 minutes elapsed - send reports
    print(f"[REPORT] Wait complete. Generating reports...")
    
    try:
        send_reports(ist_day, executed_slots, today_server_sched)
        print(f"[REPORT] ✓ Reports sent successfully")
        EMAIL_SENT_TODAY = True
        
    except Exception as e:
        print(f"[REPORT] ✗ Report generation failed: {e}")
        # Still set flag to prevent infinite retries
        EMAIL_SENT_TODAY = True

def attempt_report_generation(ist_day: date):
    """
    Wrapper function for backward compatibility.
    Checks if it's time to generate reports.
    """
    pass  # Actual logic is in check_day_end_conditions