"""Test script to verify REQUIRED_OPENING_TIMES calculation"""
from datetime import datetime, timedelta, date, time as dt_time

IST_TRADE_TIMES = [
    "05:50", "06:30", "08:05", "08:55", "09:25", "09:45", "10:05", "10:35",
    "18:30", "18:35", "19:00", "19:05", "19:30", "19:35", "19:45", "20:05", "20:30", "20:35"
]

def parse_ist_hhmm(hhmm: str):
    import re
    m = re.match(r'^(\d{1,2}):(\d{1,2})(?::\d{1,2})?$', str(hhmm).strip())
    if not m:
        raise ValueError(f"Bad time format: {hhmm}")
    h, mn = int(m.group(1)), int(m.group(2))
    return h, mn

def calculate_required_opening_times():
    """Calculate required opening times for signal generation"""
    required_times = []
    for trade_time in IST_TRADE_TIMES:
        hh, mm = parse_ist_hhmm(trade_time)
        opening_dt = datetime.combine(date.today(), dt_time(hh, mm)) - timedelta(minutes=5)
        opening_key = opening_dt.strftime("%H:%M")
        if opening_key not in required_times:
            required_times.append(opening_key)
    return required_times

REQUIRED_OPENING_TIMES = calculate_required_opening_times()

print("=" * 60)
print("REQUIRED_OPENING_TIMES CALCULATION TEST")
print("=" * 60)
print(f"\nIST_TRADE_TIMES = {IST_TRADE_TIMES}")
print(f"\nREQUIRED_OPENING_TIMES = {REQUIRED_OPENING_TIMES}")
print(f"\nTotal trade times: {len(IST_TRADE_TIMES)}")
print(f"Total required opening times: {len(REQUIRED_OPENING_TIMES)}")
print("\nMapping:")
print("-" * 60)
for trade_time in IST_TRADE_TIMES:
    hh, mm = parse_ist_hhmm(trade_time)
    opening_dt = datetime.combine(date.today(), dt_time(hh, mm)) - timedelta(minutes=5)
    opening_key = opening_dt.strftime("%H:%M")
    print(f"Trade at {trade_time} → Opening time: {opening_key}")

print("\n" + "=" * 60)
print("VERIFICATION:")
print("=" * 60)
print(f"Is '10:00' in REQUIRED_OPENING_TIMES? {'10:00' in REQUIRED_OPENING_TIMES}")
print(f"Is '10:30' in REQUIRED_OPENING_TIMES? {'10:30' in REQUIRED_OPENING_TIMES}")
print(f"Is '18:25' in REQUIRED_OPENING_TIMES? {'18:25' in REQUIRED_OPENING_TIMES}")
print(f"Is '18:30' in REQUIRED_OPENING_TIMES? {'18:30' in REQUIRED_OPENING_TIMES}")