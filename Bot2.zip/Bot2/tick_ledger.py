"""
Tick Ledger System - Prevents Backfill Data Issues
Captures actual tick prices at signal time and stores them
"""
import MetaTrader5 as mt5
import json
import os
from datetime import datetime, timedelta
from pathlib import Path

# Ledger storage directory
LEDGER_DIR = Path("tick_ledgers")
LEDGER_DIR.mkdir(exist_ok=True)


def get_ledger_filename(date_str):
    """
    Get ledger filename for a specific date
    
    Args:
        date_str: Date in YYYY-MM-DD format
    
    Returns:
        Path object for ledger file
    """
    return LEDGER_DIR / f"tick_ledger_{date_str}.json"


def capture_tick_price(symbol, slot_time):
    """
    Capture current tick price for a trading slot
    
    Args:
        symbol: Trading symbol (e.g., "XAUUSD")
        slot_time: Time slot (e.g., "10:30")
    
    Returns:
        dict: Tick data or None if failed
    """
    try:
        # Get current tick
        tick = mt5.symbol_info_tick(symbol)
        if tick is None:
            print(f"[TICK_LEDGER] Failed to get tick for {symbol}")
            return None
        
        tick_data = {
            "time": slot_time,
            "timestamp": datetime.now().isoformat(),
            "bid": tick.bid,
            "ask": tick.ask,
            "last": tick.last,
            "volume": tick.volume,
        }
        
        # Save to today's ledger
        today = datetime.now().strftime("%Y-%m-%d")
        save_tick_to_ledger(today, slot_time, tick_data)
        
        print(f"[TICK_LEDGER] Captured tick at {slot_time}: Bid={tick.bid}, Ask={tick.ask}")
        return tick_data
        
    except Exception as e:
        print(f"[TICK_LEDGER] Error capturing tick: {e}")
        return None


def save_tick_to_ledger(date_str, slot_time, tick_data):
    """
    Save tick data to ledger file
    
    Args:
        date_str: Date in YYYY-MM-DD format
        slot_time: Time slot
        tick_data: Tick data dictionary
    """
    try:
        ledger_file = get_ledger_filename(date_str)
        
        # Load existing ledger or create new
        if ledger_file.exists():
            with open(ledger_file, 'r') as f:
                ledger = json.load(f)
        else:
            ledger = {"date": date_str, "ticks": {}}
        
        # Add tick data
        ledger["ticks"][slot_time] = tick_data
        
        # Save ledger
        with open(ledger_file, 'w') as f:
            json.dump(ledger, f, indent=2)
        
        print(f"[TICK_LEDGER] Saved tick to ledger: {date_str} - {slot_time}")
        
    except Exception as e:
        print(f"[TICK_LEDGER] Error saving tick to ledger: {e}")


def get_tick_from_ledger(date_str, slot_time):
    """
    Get tick data from ledger
    
    Args:
        date_str: Date in YYYY-MM-DD format
        slot_time: Time slot
    
    Returns:
        dict: Tick data or None if not found
    """
    try:
        ledger_file = get_ledger_filename(date_str)
        
        if not ledger_file.exists():
            print(f"[TICK_LEDGER] No ledger found for {date_str}")
            return None
        
        with open(ledger_file, 'r') as f:
            ledger = json.load(f)
        
        tick_data = ledger.get("ticks", {}).get(slot_time)
        
        if tick_data:
            print(f"[TICK_LEDGER] Retrieved tick from ledger: {slot_time}")
        else:
            print(f"[TICK_LEDGER] No tick found in ledger for {slot_time}")
        
        return tick_data
        
    except Exception as e:
        print(f"[TICK_LEDGER] Error reading tick from ledger: {e}")
        return None


def backfill_todays_opens(symbol, trading_times):
    """
    Backfill tick prices for today's trading times (startup recovery)
    
    Args:
        symbol: Trading symbol
        trading_times: List of time slots
    
    Returns:
        dict: Mapping of slot_time -> tick_data
    """
    print("[TICK_LEDGER] Starting backfill of today's tick prices...")
    
    today = datetime.now().strftime("%Y-%m-%d")
    current_time = datetime.now().strftime("%H:%M")
    
    backfilled = {}
    
    for slot_time in trading_times:
        # Only backfill for times that have already passed
        if slot_time <= current_time:
            # Check if we already have it in ledger
            tick_data = get_tick_from_ledger(today, slot_time)
            
            if tick_data:
                backfilled[slot_time] = tick_data
                print(f"[TICK_LEDGER] Found existing tick for {slot_time}")
            else:
                # Try to get from MT5 (may be backfill data - be careful!)
                try:
                    tick = mt5.symbol_info_tick(symbol)
                    if tick:
                        tick_data = {
                            "time": slot_time,
                            "timestamp": datetime.now().isoformat(),
                            "bid": tick.bid,
                            "ask": tick.ask,
                            "last": tick.last,
                            "volume": tick.volume,
                            "backfilled": True  # Mark as backfilled
                        }
                        save_tick_to_ledger(today, slot_time, tick_data)
                        backfilled[slot_time] = tick_data
                        print(f"[TICK_LEDGER] Backfilled tick for {slot_time} (may be approximate)")
                except Exception as e:
                    print(f"[TICK_LEDGER] Error backfilling {slot_time}: {e}")
    
    print(f"[TICK_LEDGER] Backfill complete. Recovered {len(backfilled)} ticks")
    return backfilled


def cleanup_old_tick_ledgers(days_to_keep=30):
    """
    Clean up old tick ledger files
    
    Args:
        days_to_keep: Number of days to keep ledgers
    """
    try:
        cutoff_date = datetime.now() - timedelta(days=days_to_keep)
        
        for ledger_file in LEDGER_DIR.glob("tick_ledger_*.json"):
            # Extract date from filename
            date_str = ledger_file.stem.replace("tick_ledger_", "")
            
            try:
                file_date = datetime.strptime(date_str, "%Y-%m-%d")
                
                if file_date < cutoff_date:
                    ledger_file.unlink()
                    print(f"[TICK_LEDGER] Deleted old ledger: {date_str}")
            except ValueError:
                print(f"[TICK_LEDGER] Invalid ledger filename: {ledger_file.name}")
        
        print(f"[TICK_LEDGER] Cleanup complete. Keeping last {days_to_keep} days")
        
    except Exception as e:
        print(f"[TICK_LEDGER] Error during cleanup: {e}")


def get_all_ticks_for_date(date_str):
    """
    Get all tick data for a specific date
    
    Args:
        date_str: Date in YYYY-MM-DD format
    
    Returns:
        dict: All ticks for the date
    """
    try:
        ledger_file = get_ledger_filename(date_str)
        
        if not ledger_file.exists():
            return {}
        
        with open(ledger_file, 'r') as f:
            ledger = json.load(f)
        
        return ledger.get("ticks", {})
        
    except Exception as e:
        print(f"[TICK_LEDGER] Error reading all ticks: {e}")
        return {}


def verify_tick_quality(tick_data):
    """
    Verify if tick data is high quality (not backfilled)
    
    Args:
        tick_data: Tick data dictionary
    
    Returns:
        bool: True if high quality, False if suspicious
    """
    if not tick_data:
        return False
    
    # Check if marked as backfilled
    if tick_data.get("backfilled", False):
        print("[TICK_LEDGER] Warning: Using backfilled tick data")
        return False
    
    # Check if timestamp is recent (within 1 minute of slot time)
    try:
        tick_time = datetime.fromisoformat(tick_data["timestamp"])
        now = datetime.now()
        time_diff = abs((now - tick_time).total_seconds())
        
        if time_diff > 60:
            print(f"[TICK_LEDGER] Warning: Tick timestamp is {time_diff:.0f}s old")
            return False
        
    except Exception as e:
        print(f"[TICK_LEDGER] Error verifying tick quality: {e}")
        return False
    
    return True


# Utility function for getting signal price
def get_signal_price(tick_data, signal_type):
    """
    Get the appropriate price from tick data based on signal type
    
    Args:
        tick_data: Tick data dictionary
        signal_type: "BUY" or "SELL"
    
    Returns:
        float: Price to use for signal
    """
    if not tick_data:
        return None
    
    if signal_type == "BUY":
        return tick_data.get("ask")  # Use ask price for BUY
    else:  # SELL
        return tick_data.get("bid")  # Use bid price for SELL
