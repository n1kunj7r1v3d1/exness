"""
Ledger Manager Module
Handles internal trade ledger for tracking all trades independently
"""
import json
import MetaTrader5 as mt5
from datetime import datetime, date, timedelta, timezone
from pathlib import Path
from typing import Dict, Optional
from config import (
    LOG_DIR, LEDGER_LOCK, LEDGER_DATA, SYMBOL, MAGIC,
    DAILY_OPENING_BALANCE, IST_TZ
)
from utils import fmt_date
from mt5_manager import _ist_from_epoch

# WordPress Integration
from wordpress_integration import wp_save_trade

def get_ledger_filepath(ist_day: date) -> Path:
    """Get the ledger file path for a specific date."""
    return LOG_DIR / f"trade_ledger_{fmt_date(ist_day)}.json"

def load_ledger(ist_day: date) -> Dict:
    """Load the ledger for a specific day."""
    ledger_file = get_ledger_filepath(ist_day)
    try:
        if ledger_file.exists():
            with open(ledger_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                print(f"[LEDGER] Loaded existing ledger: {len(data.get('trades', {}))} trades")
                return data
    except Exception as e:
        print(f"[LEDGER] Error loading ledger: {e}")
    
    # Return empty ledger structure
    return {
        "date": fmt_date(ist_day),
        "opening_balance": 0.0,
        "closing_balance": 0.0,
        "trades": {}
    }

def save_ledger(ist_day: date, ledger_data: Dict):
    """Save the ledger to disk (atomic write)."""
    ledger_file = get_ledger_filepath(ist_day)
    temp_file = ledger_file.with_suffix('.json.tmp')
    
    try:
        with open(temp_file, 'w', encoding='utf-8') as f:
            json.dump(ledger_data, f, indent=2, ensure_ascii=False)
        
        # Atomic replace
        temp_file.replace(ledger_file)
        
    except Exception as e:
        print(f"[LEDGER] Error saving ledger: {e}")
        if temp_file.exists():
            temp_file.unlink()

def create_ledger_entry(position_id: int, ist_day: date, trade_number: int, 
                       entry_time: str, entry_price: float, sl_price: float, 
                       tp_price: float, lot_size: float, side: str, tag: str):
    """Create a new ledger entry when trade opens."""
    global LEDGER_DATA
    
    with LEDGER_LOCK:
        entry_key = tag  # e.g., "2025-10-19_05:50"
        
        LEDGER_DATA["trades"][entry_key] = {
            "position_id": position_id,
            "date": fmt_date(ist_day),
            "trade_number": trade_number,
            "entry_time": entry_time,
            "entry_price": round(entry_price, 3),
            "sl_price": round(sl_price, 3),
            "tp_price": round(tp_price, 3),
            "lot_size": round(lot_size, 2),
            "side": side,
            "tag": tag,
            "trade_outcome": None,
            "pnl": None,
            "exit_time": None,
            "account_balance": None,
            "status": "OPEN",
            # New partial close tracking fields
            "partial_close_triggered": False,
            "partial_close_price": None,
            "partial_close_lots": None,
            "partial_close_pnl": None,
            "remaining_lots": None,
            "remaining_pnl": None,
            "partial_close_net": None
        }
        
        # Save to disk
        save_ledger(ist_day, LEDGER_DATA)
        
        print(f"[LEDGER] OK Created entry for {tag} (Position: {position_id})")

def update_ledger_entry(position_id: int, ist_day: date, exit_time: str, 
                       trade_outcome: str, pnl: float, account_balance: float):
    """Update ledger entry when trade closes."""
    global LEDGER_DATA, DAILY_CLOSING_BALANCE
    
    with LEDGER_LOCK:
        # Find entry by position_id
        entry_key = None
        for key, entry in LEDGER_DATA["trades"].items():
            if entry["position_id"] == position_id:
                entry_key = key
                break
        
        if entry_key:
            LEDGER_DATA["trades"][entry_key].update({
                "exit_time": exit_time,
                "trade_outcome": trade_outcome,
                "pnl": round(pnl, 2),
                "account_balance": round(account_balance, 2),
                "status": "CLOSED"
            })
            
            # Update daily closing balance
            DAILY_CLOSING_BALANCE = account_balance
            LEDGER_DATA["closing_balance"] = round(account_balance, 2)
            
            # Save to disk
            save_ledger(ist_day, LEDGER_DATA)
            
            print(f"[LEDGER] OK Updated entry for Position {position_id}: {trade_outcome} ${pnl:.2f}")
        else:
            print(f"[LEDGER] WARNING: Position {position_id} not found in ledger")

def rebuild_ledger_from_mt5(ist_day: date) -> Dict:
    """Rebuild ledger from MT5 history (crash recovery)."""
    print(f"[LEDGER] Rebuilding ledger from MT5 history for {fmt_date(ist_day)}...")
    
    ledger_data = {
        "date": fmt_date(ist_day),
        "opening_balance": 0.0,
        "closing_balance": 0.0,
        "trades": {}
    }
    
    day_start = datetime.combine(ist_day, dt_time(0,0), tzinfo=IST_TZ)
    day_end = datetime.combine(ist_day, dt_time(23,59,59), tzinfo=IST_TZ)
    
    delta_min = ist_to_server_delta_minutes_for_date(ist_day)
    start_server = (day_start + timedelta(minutes=delta_min)).replace(tzinfo=None)
    end_server = (day_end + timedelta(minutes=delta_min)).replace(tzinfo=None)
    
    deals = mt5.history_deals_get(start_server, end_server) or []
    
    # Group by position ID
    by_pos = {}
    for d in deals:
        if d.symbol != SYMBOL or int(getattr(d, "magic", 0)) != MAGIC:
            continue
        pid = int(getattr(d, "position_id", 0)) or int(getattr(d, "ticket", 0))
        if pid <= 0:
            continue
        by_pos.setdefault(pid, []).append(d)
    
    # Rebuild each position
    trade_number = 0
    running_balance = load_baseline()
    ledger_data["opening_balance"] = running_balance
    
    for pid, lst in sorted(by_pos.items()):
        lst.sort(key=lambda x: x.time)
        
        open_deal = None
        close_deal = None
        for d in lst:
            entry_type = int(getattr(d, "entry", 0))
            if entry_type == mt5.DEAL_ENTRY_IN:
                open_deal = d
            elif entry_type == mt5.DEAL_ENTRY_OUT:
                close_deal = d
        
        if not open_deal:
            continue
        
        trade_number += 1
        
        open_time_ist = _ist_from_epoch(open_deal.time)
        entry_time = open_time_ist.strftime("%H:%M")
        entry_price = float(open_deal.price)
        volume = float(open_deal.volume)
        side = "BUY" if getattr(open_deal, "type", 0) == mt5.DEAL_TYPE_BUY else "SELL"
        comment = getattr(open_deal, "comment", "")
        
        # Extract tag from comment
        tag = comment.split("|")[-1] if "|" in comment else f"{ist_day.isoformat()}_{entry_time}"
        
        sl, tp = compute_sl_tp(entry_price, side)
        
        entry_key = tag
        
        ledger_data["trades"][entry_key] = {
            "position_id": pid,
            "date": fmt_date(ist_day),
            "trade_number": trade_number,
            "entry_time": entry_time,
            "entry_price": round(entry_price, 3),
            "sl_price": round(sl, 3),
            "tp_price": round(tp, 3),
            "lot_size": round(volume, 2),
            "side": side,
            "tag": tag,
            "trade_outcome": None,
            "pnl": None,
            "exit_time": None,
            "account_balance": None,
            "status": "OPEN" if not close_deal else "CLOSED",
            "partial_close_triggered": False,
            "partial_close_price": None,
            "partial_close_lots": None,
            "partial_close_pnl": None,
            "remaining_lots": None,
            "remaining_pnl": None,
            "partial_close_net": None
        }
        
        if close_deal:
            close_time_ist = _ist_from_epoch(close_deal.time)
            exit_time = close_time_ist.strftime("%H:%M")
            
            net_profit = sum(float(x.profit) for x in lst)
            outcome = "PROFIT" if net_profit > 0 else "LOSS"
            
            running_balance += net_profit
            
            ledger_data["trades"][entry_key].update({
                "exit_time": exit_time,
                "trade_outcome": outcome,
                "pnl": round(net_profit, 2),
                "account_balance": round(running_balance, 2),
                "status": "CLOSED"
            })
    
    ledger_data["closing_balance"] = round(running_balance, 2)
    
    print(f"[LEDGER] OK Rebuilt ledger: {len(ledger_data['trades'])} trades")
    
    return ledger_data

# ===== Crash Recovery Functions =====
def recover_trading_state_from_mt5(ist_day: date):
    """
    Query MT5 to rebuild today's trading state after restart.
    FIXED: Counts positions correctly, falls back to ledger if mismatch.
    """
    global TRADES_OPENED_TODAY, TRADES_CLOSED_TODAY
    
    print(f"[RECOVERY] Rebuilding trading state for {fmt_date(ist_day)}...")
    
    day_start = datetime.combine(ist_day, dt_time(0,0), tzinfo=IST_TZ)
    day_end = datetime.combine(ist_day, dt_time(23,59,59), tzinfo=IST_TZ)
    
    delta_min = ist_to_server_delta_minutes_for_date(ist_day)
    start_server = (day_start + timedelta(minutes=delta_min)).replace(tzinfo=None)
    end_server = (day_end + timedelta(minutes=delta_min)).replace(tzinfo=None)
    
    # Query all deals for today
    deals = mt5.history_deals_get(start_server, end_server) or []
    
    # Group by position ID
    by_pos = {}
    for d in deals:
        if d.symbol != SYMBOL or int(getattr(d, "magic", 0)) != MAGIC:
            continue
        pid = int(getattr(d, "position_id", 0)) or int(getattr(d, "ticket", 0))
        if pid <= 0:
            continue
        by_pos.setdefault(pid, []).append(d)
    
    # FIXED: Count POSITIONS, not individual deals
    opened_count = 0
    closed_count = 0
    
    for pid, lst in by_pos.items():
        has_entry_in = False
        has_entry_out = False
        
        for d in lst:
            entry_type = int(getattr(d, "entry", 0))
            if entry_type == mt5.DEAL_ENTRY_IN:
                has_entry_in = True
            elif entry_type == mt5.DEAL_ENTRY_OUT:
                has_entry_out = True
        
        # Only count if position was actually opened by our bot
        if has_entry_in:
            opened_count += 1
            # Only count as closed if it was both opened AND closed
            if has_entry_out:
                closed_count += 1
    
    # Check currently open positions
    positions = mt5.positions_get(symbol=SYMBOL)
    currently_open = 0
    if positions:
