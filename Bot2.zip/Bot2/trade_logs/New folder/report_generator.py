"""
Report Generator Module
Creates daily trading reports and summaries
"""
import MetaTrader5 as mt5
import csv
from datetime import datetime, date, timedelta
import time as _time
from pathlib import Path
from typing import List
from config import (
    LOG_DIR, LOG_HEADER, SYMBOL, MAGIC, IST_TZ,
    REPORT_HISTORY_WAIT_MINUTES, REPORT_VERIFICATION_RETRIES,
    REPORT_WAIT_TRIGGERED, REPORT_WAIT_START_TIME, REPORT_WAIT_LOCK,
    SKIPPED_SLOTS, SKIPPED_SLOTS_LOCK
)
from utils import fmt_date
from email_manager import send_email
from balance_manager import get_withdrawals_for_period
from ledger_manager import load_ledger, save_ledger
from mt5_manager import _ist_from_epoch

    baseline = load_baseline()
    
    expected_slots = set(IST_TRADE_TIMES)
    
    # Get skipped slots with reasons
    with SKIPPED_SLOTS_LOCK:
        skipped_dict = dict(SKIPPED_SLOTS)
    
    # Count executed vs total
    executed_count = len(executed_slots)
    total_count = len(IST_TRADE_TIMES)
    
    # CHANGE 4: Daily report uses LEDGER ONLY (no MT5 verification)
    daily_file = LOG_DIR / f"{fmt_date(ist_day)}.csv"
    build_daily_report_from_ledger(ist_day, baseline, daily_file, skipped_dict)
    
    # Updated email subject to show X/18 trades
    subject = f"Daily Trading Log — {fmt_date(ist_day)} ({executed_count}/{total_count} trades executed)"
    send_email(subject, "Attached is today's trading log.", daily_file)
    
    # CHANGE 5: Weekly report uses HYBRID (MT5 for past days, ledger for current day)
    if ist_day.weekday() == 4:
        start_week = ist_day - timedelta(days=4)
        start_dt = datetime.combine(start_week, dt_time(0,0), tzinfo=IST_TZ)
        end_dt = day_end
        weekly_file = LOG_DIR / f"weekly_{fmt_date(ist_day)}.csv"
        
        build_weekly_report_hybrid(start_week, ist_day, baseline, weekly_file)
        send_email(f"Weekly Trading Log — week ending {fmt_date(ist_day)}", "Attached is the weekly trading log.", weekly_file)
        
        # CHANGE 6: Monthly report uses HYBRID (MT5 for past days, ledger for current day)
        y, m = ist_day.year, ist_day.month
        next_month = date(y+1, 1, 1) if m == 12 else date(y, m+1, 1)
        last_day = next_month - timedelta(days=1)
        if last_day.weekday() > 4:
            last_business = last_day - timedelta(days=last_day.weekday() - 4)
        else:
            last_business = last_day
        
        if ist_day == last_business:
            start_month = date(y, m, 1)
            start_dt_m = datetime.combine(start_month, dt_time(0,0), tzinfo=IST_TZ)
            monthly_file = LOG_DIR / f"monthly_{y}-{m:02d}.csv"
            
            build_monthly_report_hybrid(start_month, ist_day, baseline, monthly_file)
            send_email(f"Monthly Trading Log — {y}-{m:02d}", "Attached is the monthly trading log.", monthly_file)
    
    EMAIL_SENT_TODAY = True

def send_emergency_report(ist_day: date, executed_slots: set):
    """
    Emergency fallback report using ONLY ledger data (no MT5 verification).
    This CANNOT crash because it doesn't depend on MT5 history.
    FIXED: Uses UTF-8 encoding for CSV writes.
    """
    global EMAIL_SENT_TODAY, LEDGER_DATA
    
    daily_file = LOG_DIR / f"{fmt_date(ist_day)}_EMERGENCY.csv"
    
    # Get trades from ledger
    with LEDGER_LOCK:
        trades = []
        for tag, entry in sorted(LEDGER_DATA["trades"].items()):
            if entry["status"] == "CLOSED":
                trades.append(entry)
    
    trades.sort(key=lambda x: x["trade_number"])
    
    # Get skipped slots
    with SKIPPED_SLOTS_LOCK:
        skipped_dict = dict(SKIPPED_SLOTS)
    
    # Write CSV with UTF-8 encoding
    with open(daily_file, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(LOG_HEADER)
        
        # Write trades
        for tr in trades:
            partial_close_price_str = f"{tr.get('partial_close_price'):.3f}" if tr.get('partial_close_price') else ""
            partial_close_net_str = f"${tr.get('partial_close_net'):.2f}" if tr.get('partial_close_net') is not None else ""
            
            w.writerow([
                tr["date"], str(tr["trade_number"]), tr["entry_time"],
                f"{tr['entry_price']:.3f}", f"{tr['sl_price']:.3f}", f"{tr['tp_price']:.3f}",
                partial_close_price_str,
                f"{tr['lot_size']:.2f}", tr["trade_outcome"],
                partial_close_net_str,
                f"${tr['pnl']:.2f}", f"${tr['account_balance']:.2f}"
            ])
        
        # Add summary
        blank = [""] * len(LOG_HEADER)
        w.writerow(blank)
        
        # Emergency notice
        notice_row = [""] * len(LOG_HEADER)
        notice_row[8] = "WARNING EMERGENCY REPORT - MT5 verification skipped due to error"
        w.writerow(notice_row)
        
        w.writerow(blank)
        
        # Trade count
        count_row = [""] * len(LOG_HEADER)
        count_row[8] = f"Trades executed: {len(trades)}/18"
        w.writerow(count_row)
        
        # Opening/Closing balance
        opening = LEDGER_DATA.get("opening_balance", 0.0)
        closing = LEDGER_DATA.get("closing_balance", 0.0)
        pnl = closing - opening
        
        open_row = [""] * len(LOG_HEADER)
        open_row[8] = "Opening Balance"
        open_row[11] = f"${opening:.2f}"
        w.writerow(open_row)
        
        close_row = [""] * len(LOG_HEADER)
        close_row[8] = "Closing Balance"
        close_row[11] = f"${closing:.2f}"
        w.writerow(close_row)
        
        pnl_row = [""] * len(LOG_HEADER)
        pnl_row[8] = "PnL"
        pnl_row[11] = f"${pnl:.2f}" if pnl >= 0 else f"-${abs(pnl):.2f}"
        w.writerow(pnl_row)
        
        # Skipped slots
        if skipped_dict:
            w.writerow(blank)
            skip_header = [""] * len(LOG_HEADER)
            skip_header[8] = f"WARNING Skipped Slots ({len(skipped_dict)}/18)"
            w.writerow(skip_header)
            
            for slot_time in sorted(skipped_dict.keys()):
                reason = skipped_dict[slot_time]
                skip_row = [""] * len(LOG_HEADER)
                skip_row[8] = f"{slot_time} IST: {reason}"
                w.writerow(skip_row)
    
    # Send email
    executed_count = len(executed_slots)
    subject = f"WARNING EMERGENCY Daily Log — {fmt_date(ist_day)} ({executed_count}/18 trades)"
    body = (
        f"Emergency report generated due to MT5 verification failure.\n\n"
        f"All trade data is from internal ledger (reliable).\n"
        f"Bot is still running normally.\n\n"
        f"Check logs for error details."
    )
    send_email(subject, body, daily_file)
    
    EMAIL_SENT_TODAY = True

def check_day_end_conditions(ist_day: date, executed_slots: set, today_server_sched: dict):
    """
    NEW: Smart report generation with time-based trigger
    CRASH-PROOF: Will NEVER crash - has triple-layer error handling
    """
    global EMAIL_SENT_TODAY, REPORT_WAIT_TRIGGERED, REPORT_WAIT_START_TIME, LAST_SLOT_CLOSED
    
    if EMAIL_SENT_TODAY:
        return
    
    # Check: Was last slot (20:35) executed?
    if LAST_SLOT_TIME not in executed_slots:
        return
    
    # Check: Did 20:35 position close?
    if not LAST_SLOT_CLOSED:
        return
    
    # Start 2-minute countdown
    with REPORT_WAIT_LOCK:
        if not REPORT_WAIT_TRIGGERED:
            REPORT_WAIT_TRIGGERED = True
            REPORT_WAIT_START_TIME = LAST_SLOT_CLOSE_TIME
            print(f"\n{'='*60}")
            print(f"[REPORT] Last slot ({LAST_SLOT_TIME}) position closed")
            print(f"[REPORT] Waiting {REPORT_WAIT_AFTER_LAST_CLOSE} seconds for MT5 history sync...")
            print(f"{'='*60}\n")
            return
        
        # Check if 2 minutes elapsed
        elapsed_seconds = _time.time() - REPORT_WAIT_START_TIME
        if elapsed_seconds < REPORT_WAIT_AFTER_LAST_CLOSE:
            return
    
    # 2 minutes elapsed - send reports with TRIPLE-LAYER ERROR HANDLING
    print(f"[REPORT] Wait complete. Generating reports from ledger...")
    
    try:
        # LAYER 1: Try normal report generation
        send_reports(ist_day, executed_slots, today_server_sched)
        print(f"[REPORT] OK Reports sent successfully")
        
    except Exception as e1:
        print(f"[REPORT] WARNING ERROR in normal report generation: {e1}")
        print(f"[REPORT] Attempting emergency fallback...")
        
        try:
            # LAYER 2: Try simplified report (ledger only, no MT5 verification)
            send_emergency_report(ist_day, executed_slots)
            print(f"[REPORT] OK Emergency report sent")
            
        except Exception as e2:
            print(f"[REPORT] WARNING ERROR in emergency report: {e2}")
            print(f"[REPORT] Attempting minimal notification...")
            
            try:
                # LAYER 3: Send minimal email notification
                executed_count = len(executed_slots)
                subject = f"WARNING Bot Report Failed — {fmt_date(ist_day)} ({executed_count}/18 trades)"
                body = (
                    f"Report generation failed with errors:\n\n"
                    f"Primary error: {str(e1)}\n"
                    f"Secondary error: {str(e2)}\n\n"
                    f"Bot is still running. Check logs and ledger file manually:\n"
                    f"{get_ledger_filepath(ist_day)}\n\n"
                    f"Executed slots: {sorted(executed_slots)}"
                )
                send_email(subject, body)
                print(f"[REPORT] OK Minimal notification sent")
                
            except Exception as e3:
                print(f"[REPORT] ERROR ALL report methods failed: {e3}")
                print(f"[REPORT] Bot will continue running despite report failure")
            
            finally:
                # CRITICAL: Always mark as sent to prevent infinite retries
                EMAIL_SENT_TODAY = True

# ===== Main loop =====
def main():
    global BALANCE_QUERIED_TODAY, WITHDRAWAL_DETECTED_TODAY, REPORT_WAIT_TRIGGERED, REPORT_WAIT_START_TIME
    global LEDGER_DATA, DAILY_OPENING_BALANCE, DAILY_CLOSING_BALANCE, LAST_SLOT_CLOSED, LAST_SLOT_CLOSE_TIME
    global SKIPPED_SLOTS, HEARTBEAT_LOG_EMAILED_TODAY
    
    init_mt5()
    print("[INIT] MT5 initialized for Exness")
    print(f"[INIT] ENHANCED VERSION with:")
    print(f"[INIT]   - Tick Price Ledger (accurate backfill from live data)")
    print(f"[INIT]   - Internal Ledger (primary source for reports)")
    print(f"[INIT]   - Smart report generation (2-min wait after last slot closes)")
    print(f"[INIT]   - 24/7 withdrawal detection via MT5 history")
    print(f"[INIT]   - Crash recovery (rebuilds state from MT5)")
    print(f"[INIT]   - Balance query at {BALANCE_QUERY_TIME} IST")
    print(f"[INIT]   - Signal threshold: 0.02 pips")
    print(f"[INIT]   - Skip tracking with detailed reasons")
    print(f"[INIT]   - CRASH-PROOF: Triple-layer error handling")
    print(f"[INIT]   - FIXED: UTF-8 encoding for all CSV files")
    print(f"[INIT]   - Thursday trading: {'DISABLED' if SKIP_THURSDAY else 'ENABLED'}")
    print(f"[INIT]   - Watcher timeout: {MAX_POSITION_HOLD_HOURS}h")
    
    # Clean up old tick ledgers
    cleanup_old_tick_ledgers()
    
    # Determine current day
    now_ist = datetime.now(timezone.utc).astimezone(IST_TZ)
    current_ist_day = now_ist.date()
    
    # Initialize heartbeat log immediately at startup
    init_heartbeat_log(current_ist_day)
    print(f"[HEARTBEAT_LOG] Started logging for {fmt_date(current_ist_day)}")
    
    # Show day of week and Thursday status
    day_name = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'][current_ist_day.weekday()]
    print(f"\n[INIT] Today is {day_name}, {fmt_date(current_ist_day)}")
    if SKIP_THURSDAY and current_ist_day.weekday() == 3:
        print(f"[INIT] ⚠️  THURSDAY - All 18 trades will be skipped today (SKIP_THURSDAY=True)")
        print(f"[INIT] Bot will still run, monitor balance, and generate report at end of day\n")
    
    # Load or rebuild ledger
    ledger_file = get_ledger_filepath(current_ist_day)
    if ledger_file.exists():
        print(f"[LEDGER] Loading existing ledger for {fmt_date(current_ist_day)}")
        LEDGER_DATA = load_ledger(current_ist_day)
    else:
        print(f"[LEDGER] Creating new ledger for {fmt_date(current_ist_day)}")
        LEDGER_DATA = load_ledger(current_ist_day)
        
        # Try to rebuild from MT5 if bot restarted mid-day
        print(f"[LEDGER] Checking if we need to rebuild from MT5...")
        rebuilt_ledger = rebuild_ledger_from_mt5(current_ist_day)
        if rebuilt_ledger["trades"]:
            LEDGER_DATA = rebuilt_ledger
            save_ledger(current_ist_day, LEDGER_DATA)
            print(f"[LEDGER] OK Ledger rebuilt from MT5")
    
    # Set opening balance from ledger or baseline
    if LEDGER_DATA.get("opening_balance", 0.0) > 0:
        DAILY_OPENING_BALANCE = LEDGER_DATA["opening_balance"]
    else:
        DAILY_OPENING_BALANCE = load_baseline()
        LEDGER_DATA["opening_balance"] = DAILY_OPENING_BALANCE
