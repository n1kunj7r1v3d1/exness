"""
WordPress MySQL Integration for Trading Bot
Connects your MT5 bot directly to WordPress database
"""
import mysql.connector
import requests
from datetime import datetime
from typing import Optional

# WordPress Database Configuration
# UPDATE THESE WITH YOUR WORDPRESS DATABASE CREDENTIALS
WP_DB_CONFIG = {
    'host': '103.191.209.38',  # e.g., '45.123.456.789' or 'localhost'
    'database': 'cmkbyysn_wp423',  # Your WordPress database name
    'user': 'cmkbyysn_wp423',  # Your WordPress database username
    'password': '25-m1!rSLp',  # Your WordPress database password
    'port': 3306,
    'connection_timeout': 30,
    'autocommit': True,
    'pool_name': 'wp_pool',
    'pool_size': 3,
    'pool_reset_session': True
}

# WordPress table prefix (default is 'wp_' but check your database)
TABLE_PREFIX = 'wp9y_'

# Multi-Account Support
# Set this to match your account ID from dashboard (Dashboard → Multi-Account)
ACCOUNT_ID = 1  # Default: Account 1 (Vantage Main)

# Dashboard URL for push notifications
DASHBOARD_URL = 'https://nexuspro.in'  # UPDATE THIS to your actual dashboard URL

class WordPressDB:
    def __init__(self):
        self.connection = None
        self.connect()
    
    def connect(self):
        """Establish connection to WordPress database"""
        try:
            self.connection = mysql.connector.connect(**WP_DB_CONFIG)
            print("[WP_DB] Connected to WordPress database")
        except Exception as e:
            print(f"[WP_DB] Connection failed: {e}")
            self.connection = None
    
    def execute(self, query: str, params: tuple = None):
        """Execute SQL query with retry logic"""
        max_retries = 3
        
        for attempt in range(max_retries):
            try:
                # Ensure connection is alive
                if not self.connection:
                    self.connect()
                else:
                    try:
                        self.connection.ping(reconnect=True, attempts=3, delay=1)
                    except:
                        self.connect()
                
                if not self.connection:
                    continue
                
                cursor = self.connection.cursor()
                cursor.execute(query, params)
                self.connection.commit()
                cursor.close()
                return True
                
            except mysql.connector.Error as e:
                print(f"[WP_DB] Query failed (attempt {attempt + 1}/{max_retries}): {e}")
                self.connection = None  # Force reconnect on next attempt
                if attempt == max_retries - 1:
                    return False
            except Exception as e:
                print(f"[WP_DB] Unexpected error: {e}")
                return False
        
        return False
    
    def execute_fetch(self, query: str, params: tuple = None):
        """Execute query and fetch results with retry logic"""
        max_retries = 3
        
        for attempt in range(max_retries):
            try:
                # Ensure connection is alive
                if not self.connection:
                    self.connect()
                else:
                    try:
                        self.connection.ping(reconnect=True, attempts=3, delay=1)
                    except:
                        self.connect()
                
                if not self.connection:
                    continue
                
                cursor = self.connection.cursor(dictionary=True)
                cursor.execute(query, params)
                results = cursor.fetchall()
                cursor.close()
                return results
                
            except mysql.connector.Error as e:
                print(f"[WP_DB] Query failed (attempt {attempt + 1}/{max_retries}): {e}")
                self.connection = None  # Force reconnect on next attempt
                if attempt == max_retries - 1:
                    return None
            except Exception as e:
                print(f"[WP_DB] Unexpected error: {e}")
                return None
        
        return None
    
    def save_trade(self, ticket: int, trade_date: str, trade_number: int, 
                   entry_time: str, entry_price: float, sl_price: float, 
                   tp_price: float, lot_size: float, signal: str, 
                   outcome: str = None, partial_close: str = 'NO',
                   partial_close_price: float = None, close_time: str = None,
                   pnl: float = 0.0, balance: float = 0.0, tag: str = '',
                   account_id: int = None):
        """Save or update trade in WordPress database"""
        
        # Use configured ACCOUNT_ID if not provided
        if account_id is None:
            account_id = ACCOUNT_ID
        
        query = f"""
        REPLACE INTO {TABLE_PREFIX}tbd_trades 
        (ticket, trade_date, trade_number, entry_time, entry_price, sl_price, tp_price,
         lot_size, `signal`, outcome, partial_close, partial_close_price, close_time,
         pnl, balance, tag, account_id, created_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
        """
        
        params = (ticket, trade_date, trade_number, entry_time, entry_price, sl_price,
                 tp_price, lot_size, signal, outcome, partial_close, partial_close_price,
                 close_time, pnl, balance, tag, account_id)
        
        success = self.execute(query, params)
        
        if success:
            print(f"[WP_DB] Trade {ticket} saved to WordPress (Account ID: {account_id})")
            # Update daily stats
            self.update_daily_stats(trade_date)
        
        return success
    
    def update_position(self, ticket: int, signal: str, entry_price: float,
                       current_price: float, sl_price: float, tp_price: float,
                       lot_size: float, current_pnl: float, partial_closed: bool,
                       opened_at: str):
        """Update open position in WordPress database"""
        
        query = f"""
        REPLACE INTO {TABLE_PREFIX}tbd_positions
        (ticket, `signal`, entry_price, current_price, sl_price, tp_price,
         lot_size, current_pnl, partial_closed, opened_at, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
        """
        
        params = (ticket, signal, entry_price, current_price, sl_price, tp_price,
                 lot_size, current_pnl, 1 if partial_closed else 0, opened_at)
        
        return self.execute(query, params)
    
    def remove_position(self, ticket: int):
        """Remove closed position from WordPress database"""
        
        query = f"DELETE FROM {TABLE_PREFIX}tbd_positions WHERE ticket = %s"
        
        return self.execute(query, (ticket,))
    
    def update_bot_status(self, status: str, balance: float, equity: float,
                         open_positions: int, today_pnl: float, today_trades: int):
        """Update bot status in WordPress database"""
        
        query = f"""
        UPDATE {TABLE_PREFIX}tbd_status
        SET status = %s, balance = %s, equity = %s, open_positions = %s,
            today_pnl = %s, today_trades = %s, last_update = NOW()
        WHERE id = 1
        """
        
        params = (status, balance, equity, open_positions, today_pnl, today_trades)
        
        return self.execute(query, params)
    
    def log_activity(self, level: str, message: str):
        """Log activity to WordPress database"""
        
        query = f"""
        INSERT INTO {TABLE_PREFIX}tbd_logs (log_level, log_message, created_at)
        VALUES (%s, %s, NOW())
        """
        
        return self.execute(query, (level, message))
    
    def update_daily_stats(self, trade_date: str):
        """Calculate and update daily statistics"""
        
        # Get all trades for the date
        query = f"""
        SELECT * FROM {TABLE_PREFIX}tbd_trades WHERE trade_date = %s
        """
        
        trades = self.execute_fetch(query, (trade_date,))
        
        if not trades:
            return
        
        # Calculate stats
        total_trades = len(trades)
        winning_trades = sum(1 for t in trades if t['pnl'] > 0)
        losing_trades = sum(1 for t in trades if t['pnl'] < 0)
        total_pnl = sum(t['pnl'] for t in trades)
        win_rate = (winning_trades / total_trades * 100) if total_trades > 0 else 0
        
        opening_balance = trades[0]['balance'] - trades[0]['pnl'] if trades else 0
        closing_balance = trades[-1]['balance'] if trades else 0
        
        # Update stats
        query = f"""
        REPLACE INTO {TABLE_PREFIX}tbd_stats
        (stat_date, opening_balance, closing_balance, total_trades, winning_trades,
         losing_trades, total_pnl, win_rate, created_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, NOW())
        """
        
        params = (trade_date, opening_balance, closing_balance, total_trades,
                 winning_trades, losing_trades, total_pnl, win_rate)
        
        return self.execute(query, params)
    
    def get_config(self, config_key: str) -> Optional[str]:
        """Get configuration value from WordPress"""
        
        query = f"""
        SELECT config_value FROM {TABLE_PREFIX}tbd_config WHERE config_key = %s
        """
        
        result = self.execute_fetch(query, (config_key,))
        
        return result[0]['config_value'] if result else None
    
    def close(self):
        """Close database connection"""
        if self.connection and self.connection.is_connected():
            self.connection.close()
            print("[WP_DB] Connection closed")

# Global instance
wp_db = WordPressDB()

# Convenience functions for easy integration
def wp_save_trade(**kwargs):
    """Save trade to WordPress - use this in your watcher"""
    return wp_db.save_trade(**kwargs)

def wp_update_position(**kwargs):
    """Update position in WordPress - use this in your watcher"""
    return wp_db.update_position(**kwargs)

def wp_remove_position(ticket: int):
    """Remove position from WordPress - use when trade closes"""
    return wp_db.remove_position(ticket)

def wp_update_bot_status(**kwargs):
    """Update bot status - call in main loop"""
    return wp_db.update_bot_status(**kwargs)

def wp_log(level: str, message: str):
    """Log activity to WordPress"""
    return wp_db.log_activity(level, message)

def wp_get_config(key: str):
    """Get config from WordPress"""
    return wp_db.get_config(key)

# ============================================
# PUSH NOTIFICATION FUNCTIONS
# ============================================

def wp_send_push_notification(notification_type: str, title: str, body: str):
    """
    Send push notification to all subscribed browsers
    
    Args:
        notification_type: 'trade_executed', 'partial_close', 'sl_hit', 'tp_hit'
        title: Notification title
        body: Notification body text
    """
    try:
        # Check if this notification type is enabled
        enabled = wp_db.get_config(f'push_{notification_type}')
        if enabled != '1':
            print(f"[PUSH] {notification_type} notifications disabled")
            return False
        
        # Call the dashboard API to send push notification
        api_url = f"{DASHBOARD_URL}/api/send-push.php"
        
        payload = {
            'type': notification_type,
            'title': title,
            'body': body
        }
        
        response = requests.post(api_url, json=payload, timeout=10)
        
        if response.status_code == 200:
            result = response.json()
            if result.get('success'):
                print(f"[PUSH] Notification sent: {title}")
                return True
            else:
                print(f"[PUSH] Failed: {result.get('message', 'Unknown error')}")
                return False
        else:
            print(f"[PUSH] HTTP error: {response.status_code}")
            return False
            
    except requests.exceptions.Timeout:
        print(f"[PUSH] Timeout sending notification")
        return False
    except Exception as e:
        print(f"[PUSH] Error sending notification: {e}")
        return False

# ============================================
# BOT CONTROL FUNCTIONS
# ============================================

def wp_check_bot_status() -> str:
    """
    Check if bot should be running or paused
    Returns: 'running' or 'paused'
    """
    try:
        status = wp_db.get_config('bot_status')
        return status if status else 'running'
    except Exception as e:
        print(f"[WP_DB] Error checking bot status: {e}")
        return 'running'  # Default to running if error

def wp_get_fire_timing_offset() -> int:
    """
    Get fire timing offset from database
    Returns: Integer seconds (-2, 0, 2, 5, etc.)
    """
    try:
        offset = wp_db.get_config('fire_timing_offset')
        return int(offset) if offset else 0
    except Exception as e:
        print(f"[WP_DB] Error getting fire timing: {e}")
        return 0  # Default to exact time

def wp_get_trading_days() -> dict:
    """
    Get enabled trading days from database
    Returns: {'monday': True, 'tuesday': True, ...}
    """
    try:
        days = {}
        for day in ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']:
            enabled = wp_db.get_config(f'{day}_enabled')
            days[day] = (enabled == '1')
        return days
    except Exception as e:
        print(f"[WP_DB] Error getting trading days: {e}")
        # Default schedule (your current settings)
        return {
            'monday': True,
            'tuesday': True,
            'wednesday': True,
            'thursday': False,  # Your current setting
            'friday': True
        }

def wp_is_trading_day(day_name: str) -> bool:
    """
    Check if a specific day is enabled for trading
    Args: day_name - 'monday', 'tuesday', etc. (lowercase)
    Returns: True/False
    """
    try:
        enabled = wp_db.get_config(f'{day_name.lower()}_enabled')
        return enabled == '1'
    except Exception as e:
        print(f"[WP_DB] Error checking trading day: {e}")
        # Default: all days except Thursday
        return day_name.lower() != 'thursday'

def wp_update_hwm_lwm(balance: float, equity: float, trade_date: str):
    """
    Update High Water Mark and Low Water Mark in stats
    Args: 
        balance - Current balance
        equity - Current equity  
        trade_date - Date string (YYYY-MM-DD)
    """
    try:
        # Get current stats for the date
        query = f"""
        SELECT hwm_balance, hwm_equity, lwm_balance, lwm_equity 
        FROM {TABLE_PREFIX}tbd_stats 
        WHERE stat_date = %s
        """
        
        result = wp_db.execute_fetch(query, (trade_date,))
        
        if result and len(result) > 0:
            current = result[0]
            hwm_balance = max(float(current['hwm_balance'] or 0), balance)
            hwm_equity = max(float(current['hwm_equity'] or 0), equity)
            lwm_balance = min(float(current['lwm_balance'] or balance), balance) if current['lwm_balance'] else balance
            lwm_equity = min(float(current['lwm_equity'] or equity), equity) if current['lwm_equity'] else equity
        else:
            # First time, set current values as both HWM and LWM
            hwm_balance = balance
            hwm_equity = equity
            lwm_balance = balance
            lwm_equity = equity
        
        # Update stats
        query = f"""
        UPDATE {TABLE_PREFIX}tbd_stats 
        SET hwm_balance = %s, hwm_equity = %s, lwm_balance = %s, lwm_equity = %s
        WHERE stat_date = %s
        """
        
        wp_db.execute(query, (hwm_balance, hwm_equity, lwm_balance, lwm_equity, trade_date))
        
    except Exception as e:
        print(f"[WP_DB] Error updating HWM/LWM: {e}")
