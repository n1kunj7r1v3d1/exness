"""
WordPress MySQL Integration for Trading Bot
Connects your MT5 bot directly to WordPress database
FIXED: Proper connection pooling for multi-threaded access
"""
import mysql.connector
from mysql.connector import pooling
import requests
from datetime import datetime
from typing import Optional
import threading

# WordPress Database Configuration
WP_DB_CONFIG = {
    'host': '103.191.209.38',
    'database': 'cmkbyysn_wp423',
    'user': 'cmkbyysn_wp423',
    'password': '25-m1!rSLp',
    'port': 3306,
    'connection_timeout': 30,
    'autocommit': True,
}

# WordPress table prefix
TABLE_PREFIX = 'wp9y_'

# Multi-Account Support
ACCOUNT_ID = 1  # Default: Account 1 (Vantage Main)

# Dashboard URL for push notifications
DASHBOARD_URL = 'https://nikunjtrivedi.in/mahadev'

# Connection pool (thread-safe)
_connection_pool = None
_pool_lock = threading.Lock()

def get_connection_pool():
    """Get or create the connection pool (thread-safe)"""
    global _connection_pool
    
    with _pool_lock:
        if _connection_pool is None:
            try:
                _connection_pool = pooling.MySQLConnectionPool(
                    pool_name="wp_pool",
                    pool_size=3,  # REDUCED from 5 to 3 - prevents exhaustion
                    pool_reset_session=True,
                    **WP_DB_CONFIG
                )
                print("[WP_DB] Connection pool created (size=3)")
            except Exception as e:
                print(f"[WP_DB] Failed to create pool: {e}")
                return None
    
    return _connection_pool


def execute_query(query: str, params: tuple = None, fetch: bool = False, retries: int = 2):
    """
    Execute a query using a connection from the pool with retry logic.
    Connection is automatically returned to pool after use.
    
    Args:
        query: SQL query string
        params: Query parameters tuple
        fetch: True to fetch results, False for INSERT/UPDATE
        retries: Number of retry attempts on failure (default: 2)
    """
    pool = get_connection_pool()
    if not pool:
        return None if fetch else False
    
    last_error = None
    
    for attempt in range(retries + 1):
        connection = None
        cursor = None
        
        try:
            # Get connection from pool (blocks if all in use)
            connection = pool.get_connection()
            
            # Ping to ensure connection is alive
            try:
                connection.ping(reconnect=True, attempts=1, delay=0)
            except:
                # Connection dead, get a new one
                connection.close()
                connection = pool.get_connection()
            
            cursor = connection.cursor(dictionary=True) if fetch else connection.cursor()
            
            cursor.execute(query, params)
            
            if fetch:
                results = cursor.fetchall()
                return results
            else:
                connection.commit()
                return True
                
        except mysql.connector.errors.PoolError as e:
            # Pool exhausted - wait and retry
            last_error = e
            if attempt < retries:
                print(f"[WP_DB] Pool exhausted, retry {attempt + 1}/{retries}")
                import time
                time.sleep(0.5)
                continue
            print(f"[WP_DB] Pool exhausted after {retries} retries: {e}")
            return None if fetch else False
                
        except mysql.connector.Error as e:
            last_error = e
            error_code = e.errno if hasattr(e, 'errno') else 'unknown'
            
            # Retry on connection errors
            if error_code in [2013, 2006] and attempt < retries:
                print(f"[WP_DB] Connection lost, retry {attempt + 1}/{retries}")
                import time
                time.sleep(0.5)
                continue
            
            # Only print if it's not a transient error or final attempt
            if error_code not in [2013, 2006] or attempt == retries:
                print(f"[WP_DB] Query error ({error_code}): {e}")
            return None if fetch else False
            
        except Exception as e:
            last_error = e
            print(f"[WP_DB] Unexpected error: {e}")
            return None if fetch else False
            
        finally:
            # CRITICAL: Always close cursor and return connection to pool
            if cursor:
                try:
                    cursor.close()
                except:
                    pass
            if connection:
                try:
                    connection.close()  # Returns connection to pool
                except:
                    pass
    
    # Should never reach here, but just in case
    if last_error:
        print(f"[WP_DB] Query failed after {retries} retries: {last_error}")
    return None if fetch else False


# ============================================
# TRADE FUNCTIONS
# ============================================

def wp_save_trade(ticket: int, trade_date: str, trade_number: int, 
               entry_time: str, entry_price: float, sl_price: float, 
               tp_price: float, lot_size: float, signal: str, 
               outcome: str = None, partial_close: str = 'NO',
               partial_close_price: float = None, close_time: str = None,
               pnl: float = 0.0, balance: float = 0.0, tag: str = '',
               account_id: int = None):
    """Save or update trade in WordPress database"""
    
    if account_id is None:
        account_id = ACCOUNT_ID
    
    query = f"""
    REPLACE INTO {TABLE_PREFIX}tbd_trades 
    (ticket, trade_date, trade_number, entry_time, entry_price, sl_price, tp_price,
     lot_size, `signal`, outcome, partial_close, partial_close_price, close_time,
     pnl, balance, tag, account_id, created_at)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
    """
    
    params = (ticket, trade_date, trade_number, entry_time, entry_price, sl_price,
             tp_price, lot_size, signal, outcome, partial_close, partial_close_price,
             close_time, pnl, balance, tag, account_id)
    
    success = execute_query(query, params)
    
    if success:
        print(f"[WP_DB] Trade {ticket} saved to WordPress")
        # Update daily stats
        update_daily_stats(trade_date)
    else:
        print(f"[WP_DB] FAILED to save trade {ticket}")
    
    return success


def wp_update_position(ticket: int, signal: str, entry_price: float,
                   current_price: float, sl_price: float, tp_price: float,
                   lot_size: float, current_pnl: float, partial_closed: bool,
                   opened_at: str):
    """Update open position in WordPress database"""
    
    query = f"""
    REPLACE INTO {TABLE_PREFIX}tbd_positions
    (ticket, `signal`, entry_price, current_price, sl_price, tp_price,
     lot_size, current_pnl, partial_closed, opened_at, updated_at)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
    """
    
    params = (ticket, signal, entry_price, current_price, sl_price, tp_price,
             lot_size, current_pnl, 1 if partial_closed else 0, opened_at)
    
    return execute_query(query, params)


def wp_remove_position(ticket: int):
    """Remove closed position from WordPress database"""
    
    query = f"DELETE FROM {TABLE_PREFIX}tbd_positions WHERE ticket = %s"
    return execute_query(query, (ticket,))


def wp_update_bot_status(status: str, balance: float, equity: float,
                     open_positions: int, today_pnl: float, today_trades: int):
    """Update bot status in WordPress database"""
    
    query = f"""
    UPDATE {TABLE_PREFIX}tbd_status
    SET status = %s, balance = %s, equity = %s, open_positions = %s,
        today_pnl = %s, today_trades = %s, last_update = NOW()
    WHERE id = 1
    """
    
    params = (status, balance, equity, open_positions, today_pnl, today_trades)
    return execute_query(query, params)


def wp_log(level: str, message: str):
    """Log activity to WordPress database"""
    
    query = f"""
    INSERT INTO {TABLE_PREFIX}tbd_logs (log_level, log_message, created_at)
    VALUES (%s, %s, NOW())
    """
    
    return execute_query(query, (level, message))


def update_daily_stats(trade_date: str):
    """Calculate and update daily statistics"""
    
    # Get all trades for the date
    query = f"""
    SELECT * FROM {TABLE_PREFIX}tbd_trades WHERE trade_date = %s
    """
    
    trades = execute_query(query, (trade_date,), fetch=True)
    
    if not trades:
        return
    
    # Calculate stats
    total_trades = len(trades)
    winning_trades = sum(1 for t in trades if t['pnl'] and t['pnl'] > 0)
    losing_trades = sum(1 for t in trades if t['pnl'] and t['pnl'] < 0)
    total_pnl = sum(t['pnl'] for t in trades if t['pnl'])
    win_rate = (winning_trades / total_trades * 100) if total_trades > 0 else 0
    
    opening_balance = trades[0]['balance'] - trades[0]['pnl'] if trades and trades[0]['pnl'] else 0
    closing_balance = trades[-1]['balance'] if trades else 0
    
    # Update stats
    query = f"""
    REPLACE INTO {TABLE_PREFIX}tbd_stats
    (stat_date, opening_balance, closing_balance, total_trades, winning_trades,
     losing_trades, total_pnl, win_rate, created_at)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, NOW())
    """
    
    params = (trade_date, opening_balance, closing_balance, total_trades,
             winning_trades, losing_trades, total_pnl, win_rate)
    
    return execute_query(query, params)


def wp_get_config(config_key: str) -> Optional[str]:
    """Get configuration value from WordPress"""
    
    query = f"""
    SELECT config_value FROM {TABLE_PREFIX}tbd_config WHERE config_key = %s
    """
    
    result = execute_query(query, (config_key,), fetch=True)
    
    return result[0]['config_value'] if result else None


# ============================================
# PUSH NOTIFICATION FUNCTIONS
# ============================================

def wp_send_push_notification(notification_type: str, title: str, body: str):
    """
    Send push notification to all subscribed browsers
    
    Args:
        notification_type: 'trade_executed', 'partial_close', 'sl_hit', 'tp_hit'
        title: Notification title
        body: Notification body text
    """
    try:
        # Check if this notification type is enabled - ISSUE #7 FIX
        enabled_value = wp_get_config(f'push_{notification_type}')
        
        # Default to enabled if no config exists
        if enabled_value is None:
            enabled = '1'  # Default to enabled
            print(f"[PUSH] {notification_type} config not found, defaulting to ENABLED")
        else:
            enabled = enabled_value
        
        if enabled != '1':
            print(f"[PUSH] {notification_type} notifications disabled")
            return False
        
        # Call the dashboard API to send push notification
        api_url = f"{DASHBOARD_URL}/api/send-push.php"
        
        payload = {
            'type': notification_type,
            'title': title,
            'body': body
        }
        
        response = requests.post(api_url, json=payload, timeout=10)
        
        if response.status_code == 200:
            result = response.json()
            if result.get('success'):
                print(f"[PUSH] Notification sent: {title}")
                return True
            else:
                print(f"[PUSH] Failed: {result.get('message', 'Unknown error')}")
                return False
        else:
            print(f"[PUSH] HTTP error: {response.status_code}")
            return False
            
    except requests.exceptions.Timeout:
        print(f"[PUSH] Timeout sending notification")
        return False
    except Exception as e:
        print(f"[PUSH] Error: {e}")
        return False


# ============================================
# BOT CONTROL FUNCTIONS
# ============================================

def wp_check_bot_status() -> str:
    """
    Check if bot should be running or paused
    Returns: 'running' or 'paused'
    """
    try:
        status = wp_get_config('bot_status')
        return status if status else 'running'
    except Exception as e:
        return 'running'  # Default to running if error


def wp_get_fire_timing_offset() -> int:
    """
    Get fire timing offset from database
    Returns: Integer seconds (-2, 0, 2, 5, etc.)
    """
    try:
        offset = wp_get_config('fire_timing_offset')
        return int(offset) if offset else 0
    except Exception as e:
        return 0


def wp_get_trading_days() -> dict:
    """
    Get enabled trading days from database
    Returns: {'monday': True, 'tuesday': True, ...}
    """
    try:
        days = {}
        for day in ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']:
            enabled = wp_get_config(f'{day}_enabled')
            days[day] = (enabled == '1')
        return days
    except Exception as e:
        return {
            'monday': True,
            'tuesday': True,
            'wednesday': True,
            'thursday': False,
            'friday': True
        }


def wp_is_trading_day(day_name: str) -> bool:
    """
    Check if a specific day is enabled for trading
    Args: day_name - 'monday', 'tuesday', etc. (lowercase)
    Returns: True/False
    """
    try:
        enabled = wp_get_config(f'{day_name.lower()}_enabled')
        return enabled == '1'
    except Exception as e:
        return day_name.lower() != 'thursday'


def wp_update_hwm_lwm(balance: float, equity: float, trade_date: str):
    """
    Update High Water Mark and Low Water Mark in stats
    """
    try:
        query = f"""
        SELECT hwm_balance, hwm_equity, lwm_balance, lwm_equity 
        FROM {TABLE_PREFIX}tbd_stats 
        WHERE stat_date = %s
        """
        
        result = execute_query(query, (trade_date,), fetch=True)
        
        if result and len(result) > 0:
            current = result[0]
            hwm_balance = max(float(current['hwm_balance'] or 0), balance)
            hwm_equity = max(float(current['hwm_equity'] or 0), equity)
            lwm_balance = min(float(current['lwm_balance'] or balance), balance) if current['lwm_balance'] else balance
            lwm_equity = min(float(current['lwm_equity'] or equity), equity) if current['lwm_equity'] else equity
        else:
            hwm_balance = balance
            hwm_equity = equity
            lwm_balance = balance
            lwm_equity = equity
        
        query = f"""
        UPDATE {TABLE_PREFIX}tbd_stats 
        SET hwm_balance = %s, hwm_equity = %s, lwm_balance = %s, lwm_equity = %s
        WHERE stat_date = %s
        """
        
        execute_query(query, (hwm_balance, hwm_equity, lwm_balance, lwm_equity, trade_date))
        
    except Exception as e:
        print(f"[WP_DB] Error updating HWM/LWM: {e}")


# ============================================
# TEST CONNECTION ON IMPORT
# ============================================

def test_connection():
    """Test database connection on startup"""
    pool = get_connection_pool()
    if pool:
        try:
            conn = pool.get_connection()
            conn.close()
            print("[WP_DB] Connection test successful")
            return True
        except Exception as e:
            print(f"[WP_DB] Connection test failed: {e}")
            return False
    return False

# Test connection when module loads
test_connection()