"""
Find WordPress Table Prefix
"""
from wordpress_integration import wp_db

print("="*60)
print("FINDING WORDPRESS TABLE PREFIX")
print("="*60)

# Check all tables in the database
print("\nChecking all tables in your database...")
query = "SHOW TABLES"
result = wp_db.execute_fetch(query)

if result:
    all_tables = [list(table.values())[0] for table in result]
    print(f"\nFound {len(all_tables)} tables total")
    
    # Look for WordPress core tables
    print("\nLooking for WordPress tables...")
    wp_tables = [t for t in all_tables if 'posts' in t or 'users' in t or 'options' in t]
    
    if wp_tables:
        print(f"\nWordPress tables found:")
        for table in wp_tables[:5]:
            print(f"  - {table}")
        
        # Extract prefix from first table
        first_table = wp_tables[0]
        if 'posts' in first_table:
            prefix = first_table.replace('posts', '')
        elif 'users' in first_table:
            prefix = first_table.replace('users', '')
        elif 'options' in first_table:
            prefix = first_table.replace('options', '')
        else:
            prefix = 'wp_'
        
        print(f"\n✅ DETECTED PREFIX: '{prefix}'")
        print(f"\n📝 UPDATE YOUR wordpress_integration.py:")
        print(f"   Change this line:")
        print(f"   TABLE_PREFIX = '{prefix}'")
    
    # Look for trading bot tables
    print("\n\nLooking for trading bot tables...")
    tbd_tables = [t for t in all_tables if 'tbd_' in t]
    
    if tbd_tables:
        print(f"Found {len(tbd_tables)} trading bot tables:")
        for table in tbd_tables:
            print(f"  ✅ {table}")
        
        # Extract prefix
        first_tbd = tbd_tables[0]
        tbd_prefix = first_tbd.split('tbd_')[0]
        
        if tbd_prefix != prefix:
            print(f"\n⚠️  WARNING: Trading bot tables use different prefix!")
            print(f"   WordPress prefix: '{prefix}'")
            print(f"   Trading bot prefix: '{tbd_prefix}'")
            print(f"\n   Use: TABLE_PREFIX = '{tbd_prefix}'")
        else:
            print(f"\n✅ Trading bot tables use correct prefix: '{prefix}'")
    else:
        print("❌ No trading bot tables found")
        print(f"\nYou need to create tables with prefix '{prefix}'")
        print(f"\nIn the SQL file, replace 'wp_' with '{prefix}' and run again")

else:
    print("❌ Could not retrieve table list")

print("\n" + "="*60)