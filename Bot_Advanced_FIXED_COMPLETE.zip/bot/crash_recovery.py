"""Crash recovery for Trading Bot"""
import MetaTrader5 as mt5
from datetime import date, datetime, timedelta
from config import SYMBOL, MAGIC, TRADES_OPENED_TODAY, TRADES_CLOSED_TODAY, TRADES_LOCK
from utils import now_ist
from position_watcher import spawn_watcher
from ledger import load_ledger

def rebuild_from_mt5(ist_day: date):
    """Rebuild trade counters and spawn watchers from MT5 history"""
    global TRADES_OPENED_TODAY, TRADES_CLOSED_TODAY
    
    print(f"[RECOVERY] Rebuilding state from MT5 for {ist_day.strftime('%Y-%m-%d')}")
    
    try:
        # Load ledger
        ledger = load_ledger(ist_day)
        ledger_trades = ledger.get("trades", {})
        
        # Get today's history from MT5
        ist_now = now_ist()
        day_start = datetime.combine(ist_day, datetime.min.time())
        
        deals = mt5.history_deals_get(day_start, ist_now)
        
        opened_tickets = set()
        closed_tickets = set()
        
        if deals:
            for deal in deals:
                if getattr(deal, "magic", 0) != MAGIC:
                    continue
                
                if getattr(deal, "symbol", "") != SYMBOL:
                    continue
                
                ticket = getattr(deal, "position_id", 0)
                entry_type = getattr(deal, "entry", -1)
                
                if entry_type == 0:  # IN
                    opened_tickets.add(ticket)
                elif entry_type == 1:  # OUT
                    closed_tickets.add(ticket)
        
        # Update counters
        with TRADES_LOCK:
            TRADES_OPENED_TODAY = len(opened_tickets)
            TRADES_CLOSED_TODAY = len(closed_tickets)
        
        print(f"[RECOVERY] Recovered: {TRADES_OPENED_TODAY} opened, {TRADES_CLOSED_TODAY} closed")
        
        # Check for open positions and spawn watchers
        positions = mt5.positions_get(symbol=SYMBOL)
        
        if positions:
            for pos in positions:
                if getattr(pos, "magic", 0) != MAGIC:
                    continue
                
                ticket = pos.ticket
                signal = "BUY" if pos.type == 0 else "SELL"
                tag = getattr(pos, "comment", "").replace("60pip_bot|", "")
                
                # Check if watcher should be spawned
                if str(ticket) in ledger_trades:
                    print(f"[RECOVERY] Spawning watcher for position {ticket}")
                    spawn_watcher(ticket, signal, tag, ist_day)
        
        print(f"[RECOVERY] State rebuild complete")
        
    except Exception as e:
        print(f"[RECOVERY] Error: {e}")