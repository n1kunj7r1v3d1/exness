"""Email functionality for Trading Bot"""
import smtplib
import ssl
from email.message import EmailMessage
from pathlib import Path
from config import EMAIL_SENDER, EMAIL_PASSWORD, EMAIL_RECEIVER, SMTP_HOST, SMTP_PORT

def send_email(subject: str, body: str, attachment_path: Path = None):
    try:
        msg = EmailMessage()
        msg["From"] = EMAIL_SENDER
        msg["To"] = EMAIL_RECEIVER
        msg["Subject"] = subject
        msg.set_content(body)
        
        if attachment_path and attachment_path.exists():
            with open(attachment_path, "rb") as f:
                file_data = f.read()
                file_name = attachment_path.name
            msg.add_attachment(file_data, maintype="application", subtype="octet-stream", filename=file_name)
        
        context = ssl.create_default_context()
        with smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, context=context) as server:
            server.login(EMAIL_SENDER, EMAIL_PASSWORD)
            server.send_message(msg)
        
        print(f"[EMAIL] Sent: {subject}")
    except Exception as e:
        print(f"[EMAIL] Failed to send '{subject}': {e}")
