"""Internal ledger management for Trading Bot"""
import json
from datetime import date
from pathlib import Path
from config import LOG_DIR, LEDGER_DATA, LEDGER_LOCK
from utils import fmt_date

def ledger_path(d: date) -> Path:
    return LOG_DIR / f"ledger_{fmt_date(d)}.json"

def load_ledger(d: date) -> dict:
    p = ledger_path(d)
    if p.exists():
        try:
            with open(p, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return {"trades": {}, "opening_balance": 0.0}

def save_ledger(d: date, ledger: dict):
    p = ledger_path(d)
    try:
        with open(p, "w", encoding="utf-8") as f:
            json.dump(ledger, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"[LEDGER] Failed to save: {e}")

def create_ledger_entry(ticket: int, d: date, trade_number: int, ist_hhmm: str,
                       entry_price: float, sl: float, tp: float, volume: float,
                       signal: str, tag: str):
    """Create a new ledger entry for an opened trade"""
    with LEDGER_LOCK:
        if "trades" not in LEDGER_DATA:
            LEDGER_DATA["trades"] = {}
        
        LEDGER_DATA["trades"][str(ticket)] = {
            "trade_number": trade_number,
            "entry_time": ist_hhmm,
            "entry_price": entry_price,
            "sl": sl,
            "tp": tp,
            "volume": volume,
            "signal": signal,
            "tag": tag,
            "status": "open",
            "partial_close_price": None,
            "partial_volume": None,
            "outcome": None,
            "pnl": None,
            "close_time": None
        }
        
        save_ledger(d, LEDGER_DATA)

def update_ledger_partial_close(ticket: int, d: date, partial_price: float, partial_volume: float):
    """Update ledger when partial close occurs"""
    with LEDGER_LOCK:
        ticket_str = str(ticket)
        if ticket_str in LEDGER_DATA.get("trades", {}):
            LEDGER_DATA["trades"][ticket_str]["partial_close_price"] = partial_price
            LEDGER_DATA["trades"][ticket_str]["partial_volume"] = partial_volume
            save_ledger(d, LEDGER_DATA)

def update_ledger_trade_close(ticket: int, d: date, outcome: str, pnl: float, close_time: str):
    """Update ledger when trade fully closes"""
    with LEDGER_LOCK:
        ticket_str = str(ticket)
        if ticket_str in LEDGER_DATA.get("trades", {}):
            LEDGER_DATA["trades"][ticket_str]["status"] = "closed"
            LEDGER_DATA["trades"][ticket_str]["outcome"] = outcome
            LEDGER_DATA["trades"][ticket_str]["pnl"] = pnl
            LEDGER_DATA["trades"][ticket_str]["close_time"] = close_time
            save_ledger(d, LEDGER_DATA)

def get_ledger_trade(ticket: int) -> dict:
    """Get trade info from ledger"""
    with LEDGER_LOCK:
        return LEDGER_DATA.get("trades", {}).get(str(ticket))