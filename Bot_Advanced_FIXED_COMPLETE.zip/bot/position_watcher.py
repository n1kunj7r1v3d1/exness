"""Position watcher with WordPress integration"""
import MetaTrader5 as mt5
import threading
import time as _time
from datetime import datetime, timedelta, date
from config import (
    SYMBOL, MAGIC, MAX_POSITION_HOLD_HOURS, PARTIAL_CLOSE_TRIGGER_PIPS,
    PARTIAL_CLOSE_PERCENTAGE_EVEN, PARTIAL_CLOSE_PERCENTAGE_ODD,
    ACTIVE_WATCHERS, WATCHERS_LOCK, TRADES_CLOSED_TODAY, TRADES_LOCK,
    RUN_HEARTBEAT, LAST_SLOT_CLOSED, LAST_SLOT_CLOSE_TIME, LAST_SLOT_TIME
)
from mt5_connector import close_position_partial
from ledger import update_ledger_partial_close, update_ledger_trade_close, get_ledger_trade
from logging_handler import append_csv, write_heartbeat
from utils import now_ist
from email_handler import send_email

# Import WordPress integration
from wordpress_integration import wp_save_trade, wp_update_position, wp_remove_position

def spawn_watcher(ticket: int, signal: str, tag: str, ist_day: date):
    """Spawn a watcher thread for a position"""
    watcher_thread = threading.Thread(
        target=position_watcher,
        args=(ticket, signal, tag, ist_day),
        daemon=True
    )
    
    with WATCHERS_LOCK:
        ACTIVE_WATCHERS[ticket] = watcher_thread
    
    watcher_thread.start()

def position_watcher(ticket: int, signal: str, tag: str, ist_day: date):
    """Monitor a position for partial close and final close"""
    global LAST_SLOT_CLOSED, LAST_SLOT_CLOSE_TIME
    
    print(f"[WATCHER-{ticket}] Started monitoring")
    write_heartbeat(f"[WATCHER-{ticket}] Started")
    
    partial_close_done = False
    start_time = datetime.now()
    timeout = timedelta(hours=MAX_POSITION_HOLD_HOURS)
    
    try:
        while RUN_HEARTBEAT.is_set():
            if datetime.now() - start_time > timeout:
                print(f"[WATCHER-{ticket}] Timeout reached")
                write_heartbeat(f"[WATCHER-{ticket}] Timeout")
                break
            
            positions = mt5.positions_get(ticket=ticket)
            
            if not positions:
                # Position closed - update WordPress
                print(f"[WATCHER-{ticket}] Position closed")
                
                ledger_entry = get_ledger_trade(ticket)
                
                if ledger_entry:
                    trade_number = ledger_entry["trade_number"]
                    entry_time = ledger_entry["entry_time"]
                    entry_price = ledger_entry["entry_price"]
                    sl_price = ledger_entry["sl"]
                    tp_price = ledger_entry["tp"]
                    lot_size = ledger_entry["volume"]
                    partial_close_price = ledger_entry.get("partial_close_price")
                    
                    # Get close details from MT5
                    deals = mt5.history_deals_get(position=ticket)
                    close_price = None
                    close_time = None
                    pnl = 0.0
                    outcome = "UNKNOWN"
                    
                    if deals:
                        for deal in deals:
                            if getattr(deal, "entry", -1) == 1:
                                close_price = getattr(deal, "price", 0.0)
                                close_time = datetime.fromtimestamp(getattr(deal, "time", 0)).strftime("%H:%M:%S")
                                pnl += getattr(deal, "profit", 0.0)
                        
                        if close_price:
                            if signal == "BUY":
                                if close_price >= tp_price - 0.05:
                                    outcome = "TP"
                                elif close_price <= sl_price + 0.05:
                                    outcome = "SL"
                                else:
                                    outcome = "MANUAL"
                            else:
                                if close_price <= tp_price + 0.05:
                                    outcome = "TP"
                                elif close_price >= sl_price - 0.05:
                                    outcome = "SL"
                                else:
                                    outcome = "MANUAL"
                    
                    # Get balance
                    account_info = mt5.account_info()
                    balance = account_info.balance if account_info else 0.0
                    
                    # Update ledger
                    update_ledger_trade_close(ticket, ist_day, outcome, pnl, close_time or now_ist().strftime("%H:%M:%S"))
                    
                    # Save to WordPress
                    wp_save_trade(
                        ticket=ticket,
                        trade_date=ist_day.strftime("%Y-%m-%d"),
                        trade_number=trade_number,
                        entry_time=entry_time,
                        entry_price=entry_price,
                        sl_price=sl_price,
                        tp_price=tp_price,
                        lot_size=lot_size,
                        signal=signal,
                        outcome=outcome,
                        partial_close='YES' if partial_close_price else 'NO',
                        partial_close_price=partial_close_price,
                        close_time=close_time,
                        pnl=pnl,
                        balance=balance,
                        tag=tag
                    )
                    
                    # Remove from positions
                    wp_remove_position(ticket)
                    
                    # Log to CSV
                    row = [
                        ist_day.strftime("%d-%m-%Y"),
                        trade_number,
                        entry_time,
                        f"{entry_price:.2f}",
                        f"{sl_price:.2f}",
                        f"{tp_price:.2f}",
                        f"{partial_close_price:.2f}" if partial_close_price else "-",
                        f"{lot_size:.2f}",
                        outcome,
                        "YES" if partial_close_price else "NO",
                        f"{pnl:.2f}",
                        f"{balance:.2f}"
                    ]
                    
                    append_csv(ist_day, row)
                    
                    print(f"[WATCHER-{ticket}] Logged: {outcome}, PnL=${pnl:.2f}")
                    write_heartbeat(f"[WATCHER-{ticket}] Closed: {outcome}, PnL=${pnl:.2f}")
                
                with TRADES_LOCK:
                    global TRADES_CLOSED_TODAY
                    TRADES_CLOSED_TODAY += 1
                
                if ledger_entry and entry_time == LAST_SLOT_TIME:
                    LAST_SLOT_CLOSED = True
                    LAST_SLOT_CLOSE_TIME = datetime.now()
                    print(f"[WATCHER-{ticket}] Last slot closed")
                    write_heartbeat(f"[WATCHER-{ticket}] Last slot closed")
                
                break
            
            # Check for partial close and update WordPress
            if not partial_close_done:
                pos = positions[0]
                current_volume = pos.volume
                entry_price = pos.price_open
                
                tick = mt5.symbol_info_tick(SYMBOL)
                if tick:
                    current_price = tick.bid if signal == "BUY" else tick.ask
                    
                    if signal == "BUY":
                        profit_pips = (current_price - entry_price) / 0.10
                    else:
                        profit_pips = (entry_price - current_price) / 0.10
                    
                    # Calculate current PnL
                    current_pnl = profit_pips * 0.10 * current_volume * 100
                    
                    # Update WordPress position with current data
                    ledger_entry = get_ledger_trade(ticket)
                    if ledger_entry:
                        wp_update_position(
                            ticket=ticket,
                            signal=signal,
                            entry_price=entry_price,
                            current_price=current_price,
                            sl_price=ledger_entry["sl"],
                            tp_price=ledger_entry["tp"],
                            lot_size=current_volume,
                            current_pnl=current_pnl,
                            partial_closed=False,
                            opened_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        )
                    
                    if profit_pips >= PARTIAL_CLOSE_TRIGGER_PIPS:
                        lot_int = int(current_volume / 0.01)
                        is_even = (lot_int % 2 == 0)
                        
                        close_pct = PARTIAL_CLOSE_PERCENTAGE_EVEN if is_even else PARTIAL_CLOSE_PERCENTAGE_ODD
                        close_volume = round(current_volume * close_pct, 2)
                        
                        if close_volume >= 0.01 and close_volume < current_volume:
                            result = close_position_partial(ticket, close_volume, signal)
                            
                            if result and result.retcode == mt5.TRADE_RETCODE_DONE:
                                partial_close_done = True
                                
                                update_ledger_partial_close(ticket, ist_day, current_price, close_volume)
                                
                                # Update WordPress with partial close
                                wp_update_position(
                                    ticket=ticket,
                                    signal=signal,
                                    entry_price=entry_price,
                                    current_price=current_price,
                                    sl_price=ledger_entry["sl"],
                                    tp_price=ledger_entry["tp"],
                                    lot_size=current_volume - close_volume,
                                    current_pnl=current_pnl,
                                    partial_closed=True,
                                    opened_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                                )
                                
                                print(f"[WATCHER-{ticket}] Partial close: {close_volume:.2f} lots")
                                write_heartbeat(f"[WATCHER-{ticket}] Partial: {close_volume:.2f} lots")
            
            _time.sleep(2)
    
    except Exception as e:
        print(f"[WATCHER-{ticket}] Error: {e}")
        write_heartbeat(f"[WATCHER-{ticket}] Error: {e}")
    
    finally:
        with WATCHERS_LOCK:
            ACTIVE_WATCHERS.pop(ticket, None)
        
        print(f"[WATCHER-{ticket}] Stopped")
        write_heartbeat(f"[WATCHER-{ticket}] Stopped")