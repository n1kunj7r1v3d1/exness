"""
Email Manager Module
Handles email sending with attachments and backups
"""
import smtplib
import ssl
import shutil
from datetime import datetime
from email.message import EmailMessage
from pathlib import Path
from typing import Optional
from config import (
    EMAIL_SENDER, EMAIL_PASSWORD, EMAIL_RECEIVER,
    SMTP_HOST, SMTP_PORT, LOG_DIR
)

def send_email(subject: str, body: str, filepath: Optional[Path] = None):
    """Send email with optional CSV attachment"""
    try:
        msg = EmailMessage()
        msg["From"] = EMAIL_SENDER
        msg["To"] = EMAIL_RECEIVER
        msg["Subject"] = subject
        msg.set_content(body)
        if filepath and filepath.exists():
            with open(filepath, "rb") as f:
                msg.add_attachment(f.read(), maintype="application", subtype="csv", filename=filepath.name)
        context = ssl.create_default_context()
        with smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, context=context) as server:
            server.login(EMAIL_SENDER, EMAIL_PASSWORD)
            server.send_message(msg)
        print(f"[EMAIL] Sent: {subject} {'(with attachment)' if filepath else ''}")
    except Exception as e:
        print(f"[EMAIL] Failed to send: {e}")
        if filepath:
            backup = LOG_DIR / "failed_emails" / f"{filepath.stem}_BACKUP_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            backup.parent.mkdir(exist_ok=True)
            try:
                shutil.copy(filepath, backup)
                print(f"[EMAIL] Backup saved: {backup}")
            except Exception:
                pass
