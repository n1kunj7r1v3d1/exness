"""
MT5 Trading Bot for XAU/USD - Exness Demo Configuration
Main execution loop and orchestration

ENHANCED VERSION - Features:
- Smart report generation with trade verification
- 24/7 withdrawal detection via MT5 history
- Crash recovery with ledger rebuild
- Balance query at 05:45 IST
- Internal ledger tracking
- Partial close at +50 pips
- Tick ledger for accurate backfill
"""
import MetaTrader5 as mt5
import threading
import time as _time
from datetime import datetime, date, timedelta, time as dt_time
from config import (
    SYMBOL, MAGIC, OPEN_TRADES_GLOBAL, EMAIL_SENT_TODAY,
    RUN_HEARTBEAT, TRADES_OPENED_TODAY, TRADES_CLOSED_TODAY, TRADES_LOCK,
    ACTIVE_WATCHERS, WATCHERS_LOCK, BALANCE_QUERIED_TODAY,
    WITHDRAWAL_DETECTED_TODAY, BALANCE_QUERY_TIME, HEARTBEAT_LOG_EMAIL_TIME,
    HEARTBEAT_LOG_EMAILED_TODAY, SKIP_THURSDAY, IST_TZ, IST_TRADE_TIMES,
    CANDLE_OPENS, CANDLE_OPENS_LOCK, SKIPPED_SLOTS, SKIPPED_SLOTS_LOCK,
    LEDGER_DATA, DAILY_OPENING_BALANCE, REPORT_WAIT_TRIGGERED,
    REPORT_WAIT_START_TIME, LAST_SLOT_CLOSED, LAST_SLOT_CLOSE_TIME,
    FIRE_WINDOW_SECONDS, EARLY_TRIGGER_WINDOW_SECONDS
)
from utils import fmt_date, parse_ist_hhmm
from mt5_manager import (
    init_mt5, shutdown_mt5, ist_to_server_delta_minutes_for_date,
    build_server_schedule_for_day
)
from email_manager import send_email
from balance_manager import balance_monitor_thread, query_and_set_opening_balance, load_baseline
from logger import (
    init_heartbeat_log, close_heartbeat_log, email_heartbeat_log,
    cleanup_old_tick_ledgers, log_to_heartbeat
)
from ledger_manager import load_ledger, save_ledger, rebuild_ledger_from_mt5, create_ledger_entry
from trading_logic import (
    backfill_todays_opens, get_signal_from_live_opens, lot_size_simple_compound,
    place_trade, verify_position_exists, compute_sl_tp
)
from position_watcher import spawn_watcher
from report_generator import check_day_end_conditions, update_next_slot

# WordPress Integration
from wordpress_integration import (
    test_wordpress_connection, wp_update_bot_status,
    wp_log, BOT_STATUS_UPDATE_INTERVAL
)

        save_ledger(current_ist_day, LEDGER_DATA)
    
    print(f"[LEDGER] Opening balance: ${DAILY_OPENING_BALANCE:.2f}")
    
    # Initialize heartbeat log file for today
    init_heartbeat_log(current_ist_day)
    
    # Initialize current balance immediately on startup
    try:
        acc = mt5.account_info()
        if acc:
            global LAST_KNOWN_BALANCE
            with BALANCE_LOCK:
                LAST_KNOWN_BALANCE = float(acc.balance)
            print(f"[INIT] Current balance initialized: ${LAST_KNOWN_BALANCE:.2f}")
        else:
            print(f"[INIT] WARNING: Could not fetch current balance from MT5")
    except Exception as e:
        print(f"[INIT] ERROR: Failed to initialize balance: {e}")
    
    # Test WordPress connection at startup
    print("\n[WORDPRESS] Testing WordPress database connection...")
    test_wordpress_connection()
    wp_log("info", "Trading bot started", f"Day: {fmt_date(current_ist_day)}")
    
    # RECOVERY: Rebuild state from MT5
    print(f"\n[RECOVERY] Starting crash recovery...")
    recover_trading_state_from_mt5(current_ist_day)
    executed_ist_today = recover_executed_slots_from_mt5(current_ist_day)
    recover_withdrawals_from_mt5(current_ist_day)
    recover_orphaned_positions(current_ist_day)
    print(f"[RECOVERY] Complete\n")
    
    # Initialize schedule
    today_server_sched, delta_min = build_server_schedule_for_day(current_ist_day)
    
    global EMAIL_SENT_TODAY, TRADES_OPENED_TODAY, TRADES_CLOSED_TODAY
    
    # Start threads
    hb = threading.Thread(target=heartbeat_thread, daemon=True)
    hb.start()
    
    open_monitor = threading.Thread(target=opening_price_monitor_thread, daemon=True)
    open_monitor.start()
    
    # Start balance monitor thread
    bal_monitor = threading.Thread(target=balance_monitor_thread, daemon=True)
    bal_monitor.start()
    
    # Backfill opening prices
    backfill_todays_opens(current_ist_day)
    
    # Update next slot
    now_server = (now_ist + timedelta(minutes=delta_min)).replace(tzinfo=None)
    update_next_slot(now_server, today_server_sched, executed_ist_today, current_ist_day, delta_min)
    
    try:
        while True:
            now_utc = datetime.now(timezone.utc)
            now_ist = now_utc.astimezone(IST_TZ)
            ist_day = now_ist.date()
            current_time_key = now_ist.strftime("%H:%M")
            
            # Balance query at 05:45
            if current_time_key == BALANCE_QUERY_TIME and not BALANCE_QUERIED_TODAY:
                query_and_set_opening_balance(ist_day)
            
            # Email heartbeat log at 00:05 IST
            if current_time_key == HEARTBEAT_LOG_EMAIL_TIME and not HEARTBEAT_LOG_EMAILED_TODAY:
                yesterday = ist_day - timedelta(days=1)
                email_heartbeat_log(yesterday)
                HEARTBEAT_LOG_EMAILED_TODAY = True
            
            # Day rollover
            if ist_day != current_ist_day:
                with TRADES_LOCK:
                    if TRADES_OPENED_TODAY != TRADES_CLOSED_TODAY:
                        send_email(
                            "ALERT: Open trades at day rollover",
                            f"Opened: {TRADES_OPENED_TODAY}, Closed: {TRADES_CLOSED_TODAY}\n"
                            "Some positions may still be open from yesterday."
                        )
                
                # Close previous day's heartbeat log
                close_heartbeat_log()
                
                executed_ist_today.clear()
                current_ist_day = ist_day
                today_server_sched, delta_min = build_server_schedule_for_day(ist_day)
                EMAIL_SENT_TODAY = False
                BALANCE_QUERIED_TODAY = False
                WITHDRAWAL_DETECTED_TODAY = False
                REPORT_WAIT_TRIGGERED = False
                REPORT_WAIT_START_TIME = None
                LAST_SLOT_CLOSED = False
                LAST_SLOT_CLOSE_TIME = None
                HEARTBEAT_LOG_EMAILED_TODAY = False  # Reset for new day
                
                with TRADES_LOCK:
                    TRADES_OPENED_TODAY = 0
                    TRADES_CLOSED_TODAY = 0
                
                with CANDLE_OPENS_LOCK:
                    CANDLE_OPENS.clear()
                
                with SKIPPED_SLOTS_LOCK:
                    SKIPPED_SLOTS.clear()
                
                # Create new ledger for new day
                LEDGER_DATA = load_ledger(ist_day)
                DAILY_OPENING_BALANCE = load_baseline()
                LEDGER_DATA["opening_balance"] = DAILY_OPENING_BALANCE
                save_ledger(ist_day, LEDGER_DATA)
                
                print(f"\n{'='*60}")
                print(f"[DAY] New IST day: {fmt_date(ist_day)}")
                print(f"[DAY] Day of week: {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'][ist_day.weekday()]}")
                print(f"[DAY] Server-IST delta: {delta_min:+} minutes")
                print(f"[DAY] Opening balance: ${DAILY_OPENING_BALANCE:.2f}")
                if SKIP_THURSDAY and ist_day.weekday() == 3:
                    print(f"[DAY] ⚠️  THURSDAY - All trading disabled (SKIP_THURSDAY=True)")
                print(f"{'='*60}\n")
                
                # Initialize new heartbeat log for new day
                init_heartbeat_log(ist_day)
                print(f"[HEARTBEAT_LOG] New log started for {fmt_date(ist_day)}")
                
                # Clean up old tick ledgers
                cleanup_old_tick_ledgers()
                
                backfill_todays_opens(ist_day)
                
                update_next_slot(
                    (now_ist + timedelta(minutes=delta_min)).replace(tzinfo=None),
                    today_server_sched, executed_ist_today, ist_day, delta_min
                )
            
            # Update open trades counter
            try:
                positions = mt5.positions_get(symbol=SYMBOL)
                count = 0
                if positions:
                    for p in positions:
                        if getattr(p, "magic", 0) == MAGIC:
                            count += 1
                global OPEN_TRADES_GLOBAL
                OPEN_TRADES_GLOBAL = count
            except Exception:
                OPEN_TRADES_GLOBAL = 0
            
            # Trading logic
            delta_min = ist_to_server_delta_minutes_for_date(ist_day)
            now_server = (now_ist + timedelta(minutes=delta_min)).replace(tzinfo=None)
            
            # Check if today is Thursday and skip trading if configured
            is_thursday = ist_day.weekday() == 3  # Thursday = 3
            
            for ist_hhmm, fire_dt_server in list(today_server_sched.items()):
                if ist_hhmm in executed_ist_today:
                    continue
                
                lag = (now_server - fire_dt_server).total_seconds()
                
                # TIMING FIX: Only fire when within window (0 to 10 seconds after scheduled time)
                if -EARLY_TRIGGER_WINDOW_SECONDS <= lag <= FIRE_WINDOW_SECONDS:
                    # Additional precision check: Only fire when seconds are 0-10
                    current_second = now_server.second
                    
                    if current_second > 10:
                        # Too late in the minute, skip this cycle
                        continue
                    
                    # Skip Thursday trading if configured
                    if SKIP_THURSDAY and is_thursday:
                        skip_reason = "Thursday trading disabled (SKIP_THURSDAY=True)"
                        with SKIPPED_SLOTS_LOCK:
                            SKIPPED_SLOTS[ist_hhmm] = skip_reason
                        print(f"[SKIP] {ist_hhmm} IST: {skip_reason}")
                        executed_ist_today.add(ist_hhmm)
                        update_next_slot(now_server, today_server_sched, executed_ist_today, ist_day, delta_min)
                        continue
                    
                    signal, skip_reason = get_signal_from_live_opens(ist_hhmm)
                    
                    if not signal:
                        # Trade skipped - record reason
                        if skip_reason:
                            with SKIPPED_SLOTS_LOCK:
                                SKIPPED_SLOTS[ist_hhmm] = skip_reason
                            print(f"[SKIP] {ist_hhmm} IST: {skip_reason}")
                        
                        executed_ist_today.add(ist_hhmm)
                        update_next_slot(now_server, today_server_sched, executed_ist_today, ist_day, delta_min)
                        continue
                    
                    vol = lot_size_simple_compound()
                    tag = f"{ist_day.isoformat()}_{ist_hhmm}"
                    
                    print(f"[SIGNAL] IST {ist_hhmm} (Server: {now_server.strftime('%H:%M:%S')}) -> {signal}, vol={vol:.2f}")
                    
                    result = place_trade(signal, vol, tag)
                    executed_ist_today.add(ist_hhmm)
                    update_next_slot(now_server, today_server_sched, executed_ist_today, ist_day, delta_min)
                    
                    if result and result.retcode == mt5.TRADE_RETCODE_DONE:
                        pos_ticket = verify_position_exists(result, f"60pip_bot|{tag}")
                        
                        if pos_ticket:
                            with TRADES_LOCK:
                                TRADES_OPENED_TODAY += 1
                                trade_number = TRADES_OPENED_TODAY
                            
                            # Get entry details
                            tick = mt5.symbol_info_tick(SYMBOL)
                            entry_price = tick.ask if signal == "BUY" else tick.bid
                            sl, tp = compute_sl_tp(entry_price, signal)
                            
                            # Create ledger entry
                            create_ledger_entry(
                                pos_ticket, ist_day, trade_number,
                                ist_hhmm, entry_price, sl, tp,
                                vol, signal, tag
                            )
                            
                            spawn_watcher(pos_ticket, signal, tag, ist_day)
                            print(f"[SUCCESS] Position {pos_ticket} opened and watcher spawned")
                        else:
                            print(f"[ERROR] Trade reported success but position not found for {tag}")
                            # Record as skipped due to verification failure
                            with SKIPPED_SLOTS_LOCK:
                                SKIPPED_SLOTS[ist_hhmm] = "Trade placement verification failed"
                    else:
                        print(f"[TRADE] Failed: ret={getattr(result, 'retcode', None)}")
                        # Record as skipped due to trade failure
                        with SKIPPED_SLOTS_LOCK:
                            SKIPPED_SLOTS[ist_hhmm] = f"Trade placement failed - MT5 error code {getattr(result, 'retcode', 'unknown')}"
                
                elif lag > FIRE_WINDOW_SECONDS:
                    # Slot expired without execution
                    with SKIPPED_SLOTS_LOCK:
                        if ist_hhmm not in SKIPPED_SLOTS:
                            SKIPPED_SLOTS[ist_hhmm] = f"Slot expired (missed time window by {int(lag)}s)"
                    
                    executed_ist_today.add(ist_hhmm)
                    update_next_slot(now_server, today_server_sched, executed_ist_today, ist_day, delta_min)
            
            # Check for report generation
            check_day_end_conditions(ist_day, executed_ist_today, today_server_sched)
            
            _time.sleep(1)
    
    except KeyboardInterrupt:
        print("\n[STOP] Bot interrupted by user")
    finally:
        RUN_HEARTBEAT.clear()
        _time.sleep(0.5)
        
        with WATCHERS_LOCK:
            active = list(ACTIVE_WATCHERS.values())
        
        for thr in active:
            if thr.is_alive():
                thr.join(timeout=2.0)
        
        shutdown_mt5()
        print("[SHUTDOWN] MT5 closed")

if __name__ == "__main__":
    main()