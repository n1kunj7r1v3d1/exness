"""
Trading Logic Module
Handles signal generation, lot sizing, and trade placement
"""
import MetaTrader5 as mt5
from datetime import datetime, date, timedelta, time as dt_time
import time as _time
from typing import Optional, Tuple, List
from config import (
    SYMBOL, SL_PIPS, TP_PIPS, PIP_SIZE, DOLLAR_PER_PIP_PER_001LOT,
    DEVIATION, MAGIC, MIN_LOT, MAX_LOSS_PER_TRADE_USD,
    CANDLE_OPENS, CANDLE_OPENS_LOCK, IST_TZ
)
from utils import REQUIRED_OPENING_TIMES, parse_ist_hhmm
from balance_manager import load_baseline
from logger import save_tick_to_ledger, get_tick_from_ledger, log_to_heartbeat

def recover_executed_slots_from_mt5(ist_day: date) -> set:
    """
    Determine which IST time slots were already executed today.
    FIXED: Checks ledger first (most reliable).
    """
    # First try from ledger (most reliable)
    executed_slots = set()
    
    with LEDGER_LOCK:
        for tag, entry in LEDGER_DATA["trades"].items():
            time_part = entry.get("entry_time", "")
            if time_part in IST_TRADE_TIMES:
                executed_slots.add(time_part)
    
    if executed_slots:
        print(f"[RECOVERY] Executed slots from ledger: {sorted(executed_slots)}")
        return executed_slots
    
    # Fallback to MT5 history if ledger empty
    day_start = datetime.combine(ist_day, dt_time(0,0), tzinfo=IST_TZ)
    day_end = datetime.combine(ist_day, dt_time(23,59,59), tzinfo=IST_TZ)
    
    delta_min = ist_to_server_delta_minutes_for_date(ist_day)
    start_server = (day_start + timedelta(minutes=delta_min)).replace(tzinfo=None)
    end_server = (day_end + timedelta(minutes=delta_min)).replace(tzinfo=None)
    
    deals = mt5.history_deals_get(start_server, end_server) or []
    
    for d in deals:
        if d.symbol != SYMBOL or int(getattr(d, "magic", 0)) != MAGIC:
            continue
        
        entry_type = int(getattr(d, "entry", 0))
        if entry_type == mt5.DEAL_ENTRY_IN:  # Opening trade
            comment = getattr(d, "comment", "")
            
            if "_" in comment:
                try:
                    time_part = comment.split("_")[-1]  # "05:50"
                    if time_part in IST_TRADE_TIMES:
                        executed_slots.add(time_part)
                except Exception:
                    pass
    
    if executed_slots:
        print(f"[RECOVERY] Executed slots from MT5: {sorted(executed_slots)}")
    else:
        print(f"[RECOVERY] No slots executed yet today")
    
    return executed_slots

def recover_withdrawals_from_mt5(ist_day: date):
    """
    Check if any withdrawals happened today (before restart).
    """
    day_start = datetime.combine(ist_day, dt_time(0,0), tzinfo=IST_TZ)
    day_end = datetime.combine(ist_day, dt_time(23,59,59), tzinfo=IST_TZ)
    
    delta_min = ist_to_server_delta_minutes_for_date(ist_day)
    start_server = (day_start + timedelta(minutes=delta_min)).replace(tzinfo=None)
    end_server = (day_end + timedelta(minutes=delta_min)).replace(tzinfo=None)
    
    deals = mt5.history_deals_get(start_server, end_server) or []
    
    for deal in deals:
        deal_type = int(getattr(deal, "type", -1))
        if deal_type == 2:  # Balance operation
            profit = float(getattr(deal, "profit", 0.0))
            if profit < 0:
                global WITHDRAWAL_DETECTED_TODAY
                WITHDRAWAL_DETECTED_TODAY = True
                print(f"[RECOVERY] WARNING: Withdrawal detected earlier today: ${abs(profit):.2f}")
                return

# ===== Lot sizing =====
def lot_size_simple_compound() -> float:
    """Simple compounding: Increase 0.01 lot per $100 increment from starting point."""
    acc = mt5.account_info()
    bal = float(getattr(acc, "balance", 0.0)) if acc else 500.0
    
    starting_balance = 500
    starting_lots = 0.05
    
    increments = int((bal - starting_balance) / 100)
    lots = starting_lots + (increments * 0.01)
    
    return max(MIN_LOT, min(lots, 10.0))

def calculate_partial_close_lots(original_lots: float) -> Tuple[float, float]:
    """
    Calculate how many lots to close at +50 pips.
    
    Rules:
    - For 0.01: Close full (0.01)
    - For 0.03: Close 0.02, keep 0.01
    - For 0.05: Close 0.03, keep 0.02
    - For even lots (0.02, 0.04, 0.06...): Close 50%
    - For other odd lots: Close 66% (rounded per MT5)
    
    Returns: (lots_to_close, remaining_lots)
    """
    info = mt5.symbol_info(SYMBOL)
    lot_step = getattr(info, "volume_step", 0.01) if info else 0.01
    min_lot = getattr(info, "volume_min", 0.01) if info else 0.01
    
    # Special cases for small odd lots
    if original_lots == 0.01:
        return 0.01, 0.0  # Close full
    elif original_lots == 0.03:
        return 0.02, 0.01
    elif original_lots == 0.05:
        return 0.03, 0.02
    
    # Check if even or odd lot size
    lots_as_int = int(original_lots / lot_step)
    is_even = (lots_as_int % 2 == 0)
    
    if is_even:
        # Even lots: close exactly 50%
        close_lots = original_lots * PARTIAL_CLOSE_PERCENTAGE_EVEN
    else:
        # Odd lots: close 66%
        close_lots = original_lots * PARTIAL_CLOSE_PERCENTAGE_ODD
    
    # Round to MT5 lot step
    close_lots = round(close_lots / lot_step) * lot_step
    close_lots = max(min_lot, close_lots)
    close_lots = min(close_lots, original_lots - min_lot)  # Ensure at least min_lot remains
    
    remaining_lots = original_lots - close_lots
    remaining_lots = round(remaining_lots / lot_step) * lot_step
    remaining_lots = max(0, remaining_lots)
    
    return round(close_lots, 2), round(remaining_lots, 2)

def calculate_current_pips(entry_price: float, current_price: float, side: str) -> float:
    """Calculate current profit/loss in pips."""
    if side == "BUY":
        pips = (current_price - entry_price) / PIP_SIZE
    else:  # SELL
        pips = (entry_price - current_price) / PIP_SIZE
    return pips

def compute_sl_tp(entry: float, side: str) -> Tuple[float, float]:
    sl_dist = SL_PIPS * PIP_SIZE
    tp_dist = TP_PIPS * PIP_SIZE
    if side == "BUY":
        sl = entry - sl_dist
        tp = entry + tp_dist
    else:
        sl = entry + sl_dist
        tp = entry - tp_dist
    info = mt5.symbol_info(SYMBOL)
    digits = getattr(info, "digits", 2) if info else 2
    return round(sl, digits), round(tp, digits)

def margin_ok(order_type, volume, price) -> bool:
    try:
        mr = mt5.order_calc_margin(order_type, SYMBOL, volume, price)
        acc = mt5.account_info()
        return (mr is not None) and (acc is not None) and (mr <= acc.margin_free)
    except Exception:
        return False

# ===== Trading logic =====
def place_trade(signal: str, volume: float, tag: str):
    # Try 5 times to get tick price
    tick = None
    for retry_attempt in range(5):
        tick = mt5.symbol_info_tick(SYMBOL)
        if tick:
            break
        print(f"[WARNING] Tick not available in place_trade, retry {retry_attempt + 1}/5...")
        import time as _time
        _time.sleep(1)
    
    if not tick:
        print("[TRADE] No tick data after 5 retries")
        return None
    
    price = tick.ask if signal == "BUY" else tick.bid
    sl, tp = compute_sl_tp(price, signal)
    order_type = mt5.ORDER_TYPE_BUY if signal == "BUY" else mt5.ORDER_TYPE_SELL
    
    if not margin_ok(order_type, volume, price):
        print("[MARGIN] Insufficient margin")
        return None
    
    req = {
        "action": mt5.TRADE_ACTION_DEAL,
        "symbol": SYMBOL,
        "volume": float(volume),
        "type": order_type,
        "price": price,
        "sl": sl,
        "tp": tp,
        "deviation": DEVIATION,
        "magic": MAGIC,
        "comment": f"60pip_bot|{tag}",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC  # Fixed: Changed from FOK to IOC for Vantage
    }
    result = mt5.order_send(req)
    print(f"[TRADE] {signal} vol={volume:.2f} @{price:.3f} SL={sl:.3f} TP={tp:.3f} ret={getattr(result,'retcode',None)}")
    return result

# ===== Opening price capture =====
def opening_price_monitor_thread():
    print("[OPEN_MONITOR] Started - capturing opening prices at required times")
    print(f"[OPEN_MONITOR] Will capture opens at: {REQUIRED_OPENING_TIMES}")
    
    last_captured = {}
    
    while RUN_HEARTBEAT.is_set():
        try:
            now_utc = datetime.now(timezone.utc)
            now_ist = now_utc.astimezone(IST_TZ)
            ist_day = now_ist.date()
            current_time_key = now_ist.strftime("%H:%M")
            current_second = now_ist.second
            
            if current_time_key in REQUIRED_OPENING_TIMES:
                if current_second <= 3:
                    capture_id = f"{current_time_key}_{ist_day}"
                    
                    if capture_id not in last_captured:
                        tick = mt5.symbol_info_tick(SYMBOL)
                        if tick:
                            midpoint = (float(tick.bid) + float(tick.ask)) / 2.0
                            
                            with CANDLE_OPENS_LOCK:
                                CANDLE_OPENS[current_time_key] = midpoint
                            
                            last_captured[capture_id] = midpoint
                            print(f"[OPEN_CAPTURE] OK {current_time_key} IST: Opening = {midpoint:.3f}")
                            
                            # CRITICAL: Save to tick ledger immediately
                            save_tick_to_ledger(ist_day, current_time_key, midpoint, source="live")
                    
                    elif current_second <= 2:
                        tick = mt5.symbol_info_tick(SYMBOL)
                        if tick:
                            midpoint = (float(tick.bid) + float(tick.ask)) / 2.0
                            
                            if abs(midpoint - last_captured[capture_id]) > 0.001:
                                with CANDLE_OPENS_LOCK:
                                    CANDLE_OPENS[current_time_key] = midpoint
                                last_captured[capture_id] = midpoint
                                print(f"[OPEN_CAPTURE] UPDATED {current_time_key} IST: Updated = {midpoint:.3f}")
                                
                                # Update tick ledger with new price
                                save_tick_to_ledger(ist_day, current_time_key, midpoint, source="live_update")
            
            if current_second == 0 and now_ist.minute == 0:
                current_date = ist_day
                last_captured = {k: v for k, v in last_captured.items() if current_date.isoformat() in k}
            
            _time.sleep(0.1)
            
        except Exception as e:
            print(f"[OPEN_MONITOR] Error: {e}")
            _time.sleep(1)

def backfill_todays_opens(ist_day: date):
    """
    MODIFIED: Backfill using tick ledger FIRST, fallback to MT5 historical data.
    This ensures accuracy even after bot restarts.
    """
    now_ist = datetime.now(timezone.utc).astimezone(IST_TZ)
    delta_min = ist_to_server_delta_minutes_for_date(ist_day)
    
    print("[BACKFILL] Checking for missing opening prices...")
    
    # Load tick ledger for today
    tick_ledger = load_tick_ledger(ist_day)
    ledger_ticks = tick_ledger.get("ticks", {})
    
    backfilled_count = 0
    ledger_used_count = 0
    mt5_used_count = 0
    
    for time_str in REQUIRED_OPENING_TIMES:
        hh, mm = parse_ist_hhmm(time_str)
        candle_time = datetime.combine(ist_day, dt_time(hh, mm), tzinfo=IST_TZ)
        
        if candle_time < now_ist:
            with CANDLE_OPENS_LOCK:
                if time_str in CANDLE_OPENS:
                    continue
            
            # PRIORITY 1: Check tick ledger first
            ledger_price = get_tick_from_ledger(ist_day, time_str)
            
            if ledger_price is not None:
                with CANDLE_OPENS_LOCK:
                    CANDLE_OPENS[time_str] = ledger_price
                print(f"[BACKFILL] OK {time_str} opening: {ledger_price:.3f} (from LEDGER)")
                backfilled_count += 1
                ledger_used_count += 1
                continue
            
            # PRIORITY 2: Fallback to MT5 historical data
            server_time = (candle_time + timedelta(minutes=delta_min)).replace(tzinfo=None)
            
            rates = mt5.copy_rates_from(SYMBOL, mt5.TIMEFRAME_M5, server_time, 1)
            if rates is not None and len(rates) > 0:
                candle_open = float(rates[0]["open"])
                with CANDLE_OPENS_LOCK:
                    CANDLE_OPENS[time_str] = candle_open
                print(f"[BACKFILL] OK {time_str} opening: {candle_open:.3f} (from MT5)")
                
                # Save to ledger for future reference
                save_tick_to_ledger(ist_day, time_str, candle_open, source="backfill_mt5")
                
                backfilled_count += 1
                mt5_used_count += 1
    
    if backfilled_count > 0:
        print(f"[BACKFILL] Completed: {backfilled_count} opens backfilled "
              f"({ledger_used_count} from ledger, {mt5_used_count} from MT5)")
    else:
        print(f"[BACKFILL] No backfill needed")

def get_signal_from_live_opens(ist_hhmm: str) -> Tuple[Optional[str], Optional[str]]:
    """
    Compare current price vs stored opening price (captured 5 mins ago).
    Returns (signal, skip_reason) where skip_reason is None if trade should proceed.
    """
    hh, mm = parse_ist_hhmm(ist_hhmm)
    opening_dt = datetime.combine(date.today(), dt_time(hh, mm)) - timedelta(minutes=5)
    opening_key = opening_dt.strftime("%H:%M")
    
    with CANDLE_OPENS_LOCK:
        candle_open = CANDLE_OPENS.get(opening_key)
    
    if candle_open is None:
        skip_reason = f"No opening price captured for {opening_key}"
        print(f"[SIGNAL_ERROR] ERROR {skip_reason}")
        return None, skip_reason
    
    # Try 3 times to get tick price for signal generation
    tick = None
    for retry_attempt in range(3):
        tick = mt5.symbol_info_tick(SYMBOL)
        if tick:
            break
        print(f"[WARNING] Tick not available for signal generation, retry {retry_attempt + 1}/3...")
        import time as _time
        _time.sleep(1)
    
    if not tick:
        skip_reason = "No tick data available after 3 retries"
        print(f"[SIGNAL_ERROR] {skip_reason}")
        return None, skip_reason
    
    current_bid = float(tick.bid)
    current_ask = float(tick.ask)
    current_midpoint = (current_bid + current_ask) / 2.0
    
    # CHANGED: threshold from 1 pip to 0.02 pips
    threshold = 0.02 * PIP_SIZE
    diff = current_midpoint - candle_open
    diff_pips = diff / PIP_SIZE
    
    if diff >= threshold:
        signal = "BUY"
    elif diff <= -threshold:
        signal = "SELL"
    else:
        skip_reason = f"Price difference {abs(diff_pips):.3f} pips < 0.02 threshold"
        print(f"[SIGNAL_SKIP] {skip_reason}")
        return None, skip_reason
    
    print(f"[SIGNAL] ╔═══════════════════════════════╗")
    print(f"[SIGNAL] Trade Time: {ist_hhmm} IST")
    print(f"[SIGNAL] ┌─ OPENING @ {opening_key}:00")
    print(f"[SIGNAL] │  Captured: {candle_open:.3f}")
    print(f"[SIGNAL] └─ CURRENT @ {ist_hhmm} (NOW)")
    print(f"[SIGNAL]    MID: {current_midpoint:.3f}")
    print(f"[SIGNAL] Difference: {diff:.3f} ({diff_pips:+.1f} pips)")
    print(f"[SIGNAL] ➜ Decision: {signal}")
    print(f"[SIGNAL] ╚═══════════════════════════════╝")
    
    return signal, None

# ===== Watcher thread =====
def watcher_thread(position_ticket: int, expected_side: str, tag: str, ist_day: date):
    global TRADES_CLOSED_TODAY, LAST_SLOT_CLOSED, LAST_SLOT_CLOSE_TIME
    start_time = _time.time()
    reanchored = False
    partial_close_executed = False
    original_volume = 0.0
    entry_price = 0.0
    
    print(f"[WATCHER] Started for position {position_ticket}")
    
    # Get original volume from ledger
    with LEDGER_LOCK:
        for key, entry in LEDGER_DATA["trades"].items():
            if entry["position_id"] == position_ticket:
                original_volume = entry["lot_size"]
                entry_price = entry["entry_price"]
                break
    
    while True:
        if (_time.time() - start_time) > (MAX_POSITION_HOLD_HOURS * 3600):
            print(f"[WATCHER] Timeout ({MAX_POSITION_HOLD_HOURS}h) for position {position_ticket}")
            break
        
        positions = mt5.positions_get(symbol=SYMBOL)
        pos = None
        if positions:
            for p in positions:
                if int(p.ticket) == position_ticket:
                    pos = p
                    break
        
        if not pos:
            print(f"[WATCHER] Position {position_ticket} closed")
            
            # Get closing info from MT5 history
            try:
                now = datetime.now(timezone.utc).astimezone().replace(tzinfo=None)
                start = now - timedelta(minutes=10)
                deals = mt5.history_deals_get(start, now) or []
                
                # Calculate total PnL and check for partial close
                net_profit = 0.0
                partial_close_pnl = 0.0
                remaining_pnl = 0.0
                partial_close_price = None
                partial_close_lots = 0.0
                
                # Group deals by type
                entry_out_deals = []
                for d in deals:
                    if int(getattr(d, "position_id", 0)) == position_ticket:
                        net_profit += float(getattr(d, "profit", 0.0))
                        entry_type = int(getattr(d, "entry", 0))
                        if entry_type == mt5.DEAL_ENTRY_OUT:
                            entry_out_deals.append(d)
                
                # Get exit time from final close
                exit_time = None
                for d in deals:
                    if int(getattr(d, "position_id", 0)) == position_ticket:
                        entry_type = int(getattr(d, "entry", 0))
                        if entry_type == mt5.DEAL_ENTRY_OUT:
                            close_time_ist = _ist_from_epoch(d.time)
                            exit_time = close_time_ist.strftime("%H:%M")
                
                # Check if partial close was executed
                if partial_close_executed:
                    # We know partial close happened, need to separate PnLs
                    # Sort deals by time
                    entry_out_deals.sort(key=lambda x: x.time)
                    
                    if len(entry_out_deals) >= 1:
                        # First close was partial
                        partial_deal = entry_out_deals[0]
                        partial_close_pnl = float(getattr(partial_deal, "profit", 0.0))
                        partial_close_lots = float(getattr(partial_deal, "volume", 0.0))
                        partial_close_price = float(getattr(partial_deal, "price", 0.0))
                        
                        # If there's a second close, that's the remaining
                        if len(entry_out_deals) >= 2:
                            remaining_deal = entry_out_deals[1]
                            remaining_pnl = float(getattr(remaining_deal, "profit", 0.0))
                        else:
                            # Only partial close happened (for 0.01 lot full close case)
                            remaining_pnl = 0.0
                    
                    # Determine outcome
                    if remaining_pnl > 0:
                        outcome = "Profit"  # Both partial and remaining made profit
                    else:
                        outcome = "Partial Close"  # Partial profit, remaining loss
                    
                    partial_close_net = partial_close_pnl + remaining_pnl
                else:
                    # No partial close - standard full close
                    outcome = "PROFIT" if net_profit > 0 else "LOSS"
                    partial_close_net = None
                
                acc = mt5.account_info()
                current_balance = float(acc.balance) if acc else 0.0
                
                # Update ledger with partial close info
                with LEDGER_LOCK:
                    for key, entry in LEDGER_DATA["trades"].items():
                        if entry["position_id"] == position_ticket:
                            LEDGER_DATA["trades"][key].update({
                                "exit_time": exit_time,
                                "trade_outcome": outcome,
                                "pnl": round(net_profit, 2),
                                "account_balance": round(current_balance, 2),
                                "status": "CLOSED",
                                "partial_close_triggered": partial_close_executed,
                                "partial_close_price": round(partial_close_price, 3) if partial_close_price else None,
                                "partial_close_lots": round(partial_close_lots, 2) if partial_close_executed else None,
                                "partial_close_pnl": round(partial_close_pnl, 2) if partial_close_executed else None,
                                "remaining_lots": round(original_volume - partial_close_lots, 2) if partial_close_executed else None,
                                "remaining_pnl": round(remaining_pnl, 2) if partial_close_executed else None,
                                "partial_close_net": round(partial_close_net, 2) if partial_close_net is not None else None
                            })
                            
                            # Update daily closing balance
                            global DAILY_CLOSING_BALANCE
                            DAILY_CLOSING_BALANCE = current_balance
                            LEDGER_DATA["closing_balance"] = round(current_balance, 2)
                            
                            save_ledger(ist_day, LEDGER_DATA)
                            break
                
                print(f"[LEDGER] OK Updated entry for Position {position_ticket}: {outcome} ${net_profit:.2f}")
                
                # Check if this was the last slot (20:35)
                if LAST_SLOT_TIME in tag:
                    LAST_SLOT_CLOSED = True
                    LAST_SLOT_CLOSE_TIME = _time.time()
                    print(f"[WATCHER] OK Last slot ({LAST_SLOT_TIME}) position closed")
                
            except Exception as e:
                print(f"[WATCHER] Error updating ledger: {e}")
            
            with TRADES_LOCK:
                TRADES_CLOSED_TODAY += 1
            with WATCHERS_LOCK:
                ACTIVE_WATCHERS.pop(position_ticket, None)
            break
        
        # Check for partial close trigger (exactly at +50 pips)
        if not partial_close_executed and original_volume > 0:
            try:
                tick = mt5.symbol_info_tick(SYMBOL)
                if tick:
                    current_price = tick.bid if expected_side == "BUY" else tick.ask
                    current_pips = calculate_current_pips(entry_price, current_price, expected_side)
                    
                    # Trigger partial close exactly at +50 pips
                    if current_pips >= PARTIAL_CLOSE_TRIGGER_PIPS:
                        print(f"[PARTIAL_CLOSE] +50 pips reached for position {position_ticket}")
                        
                        # Calculate how much to close
                        current_volume = float(pos.volume)
                        close_lots, remaining_lots = calculate_partial_close_lots(current_volume)
                        
                        if close_lots > 0 and remaining_lots > 0:
                            print(f"[PARTIAL_CLOSE] Closing {close_lots} lots (keeping {remaining_lots} lots)")
                            
                            # Execute partial close with correct MT5 format
                            close_request = {
                                "action": mt5.TRADE_ACTION_DEAL,
                                "symbol": SYMBOL,
                                "volume": float(close_lots),
                                "type": mt5.ORDER_TYPE_SELL if expected_side == "BUY" else mt5.ORDER_TYPE_BUY,
                                "position": position_ticket,
                                "price": tick.bid if expected_side == "BUY" else tick.ask,
                                "deviation": DEVIATION,
                                "magic": MAGIC,
                                "comment": f"PC_{position_ticket}",
                                "type_time": mt5.ORDER_TIME_GTC,
                                "type_filling": mt5.ORDER_FILLING_IOC,  # Fixed: Changed from FOK to IOC for Vantage
                            }
                            
                            result = mt5.order_send(close_request)
                            
                            if result:
                                if result.retcode == mt5.TRADE_RETCODE_DONE:
                                    partial_close_executed = True
                                    print(f"[PARTIAL_CLOSE] SUCCESS - Closed {close_lots} lots at +50 pips")
                                    print(f"[PARTIAL_CLOSE] Remaining {remaining_lots} lots will continue to TP/SL")
                                else:
                                    error_code = result.retcode
                                    error_msg = getattr(result, 'comment', 'No error message')
                                    print(f"[PARTIAL_CLOSE] FAILED - MT5 Error {error_code}: {error_msg}")
                                    partial_close_executed = True  # Don't retry to avoid spam
                            else:
                                print(f"[PARTIAL_CLOSE] FAILED - order_send returned None")
                                partial_close_executed = True  # Don't retry
                        else:
                            print(f"[PARTIAL_CLOSE] Cannot execute - close_lots={close_lots}, remaining_lots={remaining_lots}")
                            partial_close_executed = True  # Mark as executed to avoid retry
                            
            except Exception as e:
                print(f"[PARTIAL_CLOSE] Error: {e}")
                partial_close_executed = True  # Don't retry on exception
        
        # Reanchor SL/TP (only once)
        if not reanchored:
            try:
                entry = float(pos.price_open)
                current_sl = float(pos.sl)
                current_tp = float(pos.tp)
                expected_sl, expected_tp = compute_sl_tp(entry, expected_side)
                
                sl_diff = abs(current_sl - expected_sl)
                tp_diff = abs(current_tp - expected_tp)
                
                if sl_diff > 0.5 or tp_diff > 0.5:
                    print(f"[WATCHER] External modification detected on {position_ticket}")
                else:
                    req = {
                        "action": mt5.TRADE_ACTION_SLTP,
                        "symbol": SYMBOL,
                        "position": position_ticket,
                        "sl": float(expected_sl),
                        "tp": float(expected_tp),
                        "magic": MAGIC
                    }
                    res = mt5.order_send(req)
                    print(f"[WATCHER] Reanchored {position_ticket}: ret={getattr(res,'retcode',None)}")
                reanchored = True
            except Exception as e:
                print(f"[WATCHER] Reanchor failed for {position_ticket}: {e}")
        
        _time.sleep(1)

def spawn_watcher(position_ticket: int, side: str, tag: str, ist_day: date):
    thr = threading.Thread(target=watcher_thread, args=(position_ticket, side, tag, ist_day), daemon=True)
    thr.start()
    with WATCHERS_LOCK:
        ACTIVE_WATCHERS[position_ticket] = thr

def verify_position_exists(result, expected_tag: str) -> Optional[int]:
    if not result or result.retcode != mt5.TRADE_RETCODE_DONE:
        return None
    
    _time.sleep(5)
    
    positions = mt5.positions_get(symbol=SYMBOL)
    if positions:
        for p in positions:
            try:
                if getattr(p, "magic", 0) == MAGIC and expected_tag in getattr(p, "comment", ""):
                    return int(p.ticket)
            except Exception:
                continue
    
    try:
        deal_id = int(getattr(result, "deal", 0))
        if deal_id > 0:
            now = datetime.now(timezone.utc).astimezone().replace(tzinfo=None)
            start = now - timedelta(minutes=10)
            deals = mt5.history_deals_get(start, now) or []
            for d in deals:
                if int(getattr(d, "ticket", 0)) == deal_id:
                    pid = int(getattr(d, "position_id", 0))
                    if pid > 0:
                        return pid
    except Exception:
        pass
    
    print(f"[VERIFY] Position not found for tag {expected_tag}")
    return None

def recover_orphaned_positions(ist_day: date):
    try:
        positions = mt5.positions_get(symbol=SYMBOL)
        if not positions:
            return
        
        count = 0
        for p in positions:
            try:
                if getattr(p, "magic", 0) != MAGIC:
                    continue
                ticket = int(p.ticket)
                side = "BUY" if getattr(p, "type", 0) == mt5.POSITION_TYPE_BUY else "SELL"
                tag = getattr(p, "comment", "unknown")
                spawn_watcher(ticket, side, tag, ist_day)
                count += 1
            except Exception:
                continue
        
        if count > 0:
            print(f"[RESTART] Recovered {count} orphaned positions")
    except Exception as e:
        print(f"[RESTART] Recovery failed: {e}")

# ===== History-based reporting =====
def collect_closed_trades(start_ist: datetime, end_ist: datetime) -> List[dict]:
    delta_min = ist_to_server_delta_minutes_for_date(start_ist.date())
    start_server = (start_ist + timedelta(minutes=delta_min)).replace(tzinfo=None)
    end_server = (end_ist + timedelta(minutes=delta_min)).replace(tzinfo=None)
    
    print(f"[HISTORY] Querying deals from {start_server} to {end_server}")
    deals = mt5.history_deals_get(start_server, end_server) or []
    print(f"[HISTORY] Retrieved {len(deals)} total deals from MT5")
    
    by_pos: Dict[int, List] = {}
    
    for d in deals:
        try:
            if d.symbol != SYMBOL or int(getattr(d, "magic", 0)) != MAGIC:
                continue
            pid = int(getattr(d, "position_id", 0)) or int(getattr(d, "ticket", 0))
            if pid <= 0:
                continue
            by_pos.setdefault(pid, []).append(d)
        except Exception:
            continue
    
    print(f"[HISTORY] Found {len(by_pos)} unique positions for {SYMBOL} with MAGIC {MAGIC}")
    
    trades = []
    skipped_positions = []
    
    for pid, lst in by_pos.items():
        lst.sort(key=lambda x: x.time)
        
        open_deal = None
        close_deal = None
        for d in lst:
            entry_type = int(getattr(d, "entry", 0))
            if entry_type == mt5.DEAL_ENTRY_IN:
                open_deal = d
            elif entry_type == mt5.DEAL_ENTRY_OUT:
                close_deal = d
        
        if not open_deal or not close_deal:
            skipped_positions.append(pid)
            has_in = "YES" if open_deal else "NO"
            has_out = "YES" if close_deal else "NO"
            print(f"[WARNING] Position {pid} incomplete - ENTRY_IN:{has_in} ENTRY_OUT:{has_out}")
            continue
        
        open_time_ist = _ist_from_epoch(open_deal.time)
        date_str = open_time_ist.strftime(DATE_FMT)
        time_str = open_time_ist.strftime("%H:%M")

def build_server_schedule_for_day(ist_day: date) -> Tuple[dict, int]:
    """
    Build server schedule for the given IST day.
    Returns: (schedule_dict, delta_minutes)
    """
    from config import IST_TRADE_TIMES
    from utils import ist_to_server_delta_minutes_for_date
    
    delta_min = ist_to_server_delta_minutes_for_date(ist_day)
    sched = {}
    
    for hhmm in IST_TRADE_TIMES:
        hh, mm = parse_ist_hhmm(hhmm)
        ist_dt = datetime.combine(ist_day, dt_time(hh, mm))
        server_dt = ist_dt + timedelta(minutes=delta_min)
        sched[hhmm] = server_dt.replace(tzinfo=None)
    
    return sched, delta_min