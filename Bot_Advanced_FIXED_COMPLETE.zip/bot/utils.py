"""Utility functions for MT5 Trading Bot"""
from datetime import date, datetime, timedelta, time as dt_time
from typing import Tuple
import re
from config import DATE_FMT, IST_TZ, MANUAL_SERVER_DELTA_MINUTES, IST_TRADE_TIMES

def fmt_date(d: date) -> str:
    """Format date to string"""
    return d.strftime(DATE_FMT)

def now_ist() -> datetime:
    """Get current time in IST timezone"""
    return datetime.now(IST_TZ)

def parse_ist_hhmm(hhmm: str) -> Tuple[int,int]:
    """Parse HH:MM time string to hour and minute integers"""
    m = re.match(r'^(\d{1,2}):(\d{1,2})(?::\d{1,2})?$', str(hhmm).strip())
    if not m:
        raise ValueError(f"Bad time format: {hhmm}")
    h, mn = int(m.group(1)), int(m.group(2))
    if not (0 <= h < 24 and 0 <= mn < 60):
        raise ValueError(f"Out-of-range time: {hhmm}")
    return h, mn

def calculate_required_opening_times():
    """Calculate required opening times for signal generation"""
    required_times = []
    for trade_time in IST_TRADE_TIMES:
        hh, mm = parse_ist_hhmm(trade_time)
        opening_dt = datetime.combine(date.today(), dt_time(hh, mm)) - timedelta(minutes=5)
        opening_key = opening_dt.strftime("%H:%M")
        if opening_key not in required_times:
            required_times.append(opening_key)
    return required_times

def ist_to_server_delta_minutes_for_date(d: date) -> int:
    """Calculate IST to MT5 server time delta in minutes"""
    if MANUAL_SERVER_DELTA_MINUTES is not None:
        return MANUAL_SERVER_DELTA_MINUTES
    
    import MetaTrader5 as mt5
    ist_noon = datetime.combine(d, dt_time(12, 0)).replace(tzinfo=IST_TZ)
    try:
        rates = mt5.copy_rates_from_pos("XAUUSDm", mt5.TIMEFRAME_H1, 0, 2)
        if rates is not None and len(rates) > 0:
            server_dt = datetime.fromtimestamp(rates[-1]["time"])
            delta_sec = int((server_dt - ist_noon.replace(tzinfo=None)).total_seconds())
            return delta_sec // 60
    except:
        pass
    
    return -210

REQUIRED_OPENING_TIMES = calculate_required_opening_times()