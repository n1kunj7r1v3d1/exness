"""
Balance Manager Module  
Handles baseline management, balance monitoring, and withdrawal detection
"""
import MetaTrader5 as mt5
import csv
import json
import time as _time
from datetime import datetime, date, timezone, timedelta
from typing import List
from config import (
    BASELINE_STATE_FILE, DEFAULT_BASELINE, WITHDRAWAL_LOG, DATE_FMT,
    BALANCE_LOCK, LAST_KNOWN_BALANCE, BALANCE_QUERIED_TODAY,
    DAILY_OPENING_BALANCE, WITHDRAWAL_DETECTED_TODAY,
    BALANCE_MONITOR_INTERVAL_SECONDS, RUN_HEARTBEAT
)
from utils import fmt_date
from email_manager import send_email
from mt5_manager import _ist_from_epoch

def load_baseline() -> float:
    """Load baseline balance from file"""
    try:
        if BASELINE_STATE_FILE.exists():
            data = json.loads(BASELINE_STATE_FILE.read_text(encoding="utf-8"))
            return float(data.get("baseline", DEFAULT_BASELINE))
    except Exception:
        pass
    return DEFAULT_BASELINE

def save_baseline(value: float):
    """Save baseline balance to file"""
    try:
        BASELINE_STATE_FILE.write_text(json.dumps({"baseline": float(value)}), encoding="utf-8")
        print(f"[BASELINE] Saved: ${value:.2f}")
    except Exception as e:
        print(f"[BASELINE] Failed to save: {e}")

def query_and_set_opening_balance(ist_day: date):
    """Query actual MT5 balance at 05:45 and set as opening balance"""
    import config
    
    try:
        acc = mt5.account_info()
        if not acc:
            print(f"[BALANCE_QUERY] Failed to get account info")
            return
        
        current_balance = float(acc.balance)
        
        # Save as today's baseline
        save_baseline(current_balance)
        
        # Update tracked balance
        with BALANCE_LOCK:
            config.LAST_KNOWN_BALANCE = current_balance
            config.DAILY_OPENING_BALANCE = current_balance
        
        print(f"[BALANCE_QUERY] OK: Opening balance for {fmt_date(ist_day)}: ${current_balance:.2f}")
        config.BALANCE_QUERIED_TODAY = True
        
    except Exception as e:
        print(f"[BALANCE_QUERY] Error: {e}")

# ========= WITHDRAWAL DETECTION =========

def log_withdrawal(prev_bal: float, curr_bal: float, withdrawn: float, when: date):
    """Log withdrawal to CSV file"""
    try:
        if not WITHDRAWAL_LOG.exists():
            with open(WITHDRAWAL_LOG, "w", newline="", encoding="utf-8") as f:
                csv.writer(f).writerow(["Date", "Previous_Balance", "New_Balance", "Withdrawn_Amount"])
        with open(WITHDRAWAL_LOG, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([fmt_date(when), f"{prev_bal:.2f}", f"{curr_bal:.2f}", f"{withdrawn:.2f}"])
        print(f"[WITHDRAWAL] Logged: ${withdrawn:.2f} on {fmt_date(when)}")
    except Exception as e:
        print(f"[WITHDRAWAL] Failed to log: {e}")

def get_withdrawals_for_period(start: date, end: date) -> List[str]:
    """Get list of withdrawals in date range"""
    try:
        if not WITHDRAWAL_LOG.exists():
            return []
        with open(WITHDRAWAL_LOG, newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            results = []
            for row in reader:
                try:
                    d = datetime.strptime(row["Date"], DATE_FMT).date()
                    if start <= d <= end:
                        results.append(f"${row['Withdrawn_Amount']} on {row['Date']}")
                except Exception:
                    continue
            return results
    except Exception:
        return []

def balance_monitor_thread():
    """
    24/7 Balance monitor - detects withdrawals via MT5 history.
    Monitors MT5 history for balance operations (deal_type=2).
    Withdrawals appear as profit < 0, deposits as profit > 0.
    """
    import config
    
    last_checked_time = datetime.now(timezone.utc).astimezone().replace(tzinfo=None)
    
    while RUN_HEARTBEAT.is_set():
        try:
            now = datetime.now(timezone.utc).astimezone().replace(tzinfo=None)
            
            # Query deals from last check to now
            deals = mt5.history_deals_get(last_checked_time, now) or []
            
            for deal in deals:
                deal_type = int(getattr(deal, "type", -1))
                
                # DEAL_TYPE_BALANCE = 2 (balance operation from Exness)
                if deal_type == 2:
                    profit = float(getattr(deal, "profit", 0.0))
                    deal_time_epoch = int(getattr(deal, "time", 0))
                    deal_time_ist = _ist_from_epoch(deal_time_epoch)
                    
                    if profit < 0:
                        # WITHDRAWAL DETECTED
                        withdrawn = abs(profit)
                        
                        acc = mt5.account_info()
                        current_balance = float(acc.balance) if acc else 0.0
                        previous_balance = current_balance + withdrawn
                        
                        print(f"\n{'='*60}")
                        print(f"[WITHDRAWAL] ⚠️  WARNING: DETECTED at {deal_time_ist.strftime('%Y-%m-%d %H:%M:%S')} IST")
                        print(f"[WITHDRAWAL] Previous balance: ${previous_balance:.2f}")
                        print(f"[WITHDRAWAL] Current balance: ${current_balance:.2f}")
                        print(f"[WITHDRAWAL] Withdrawn: ${withdrawn:.2f}")
                        print(f"{'='*60}\n")
                        
                        # Log withdrawal
                        log_withdrawal(
                            previous_balance,
                            current_balance,
                            withdrawn,
                            deal_time_ist.date()
                        )
                        
                        # Update baseline immediately
                        save_baseline(current_balance)
                        
                        # Update tracked balance
                        with BALANCE_LOCK:
                            config.LAST_KNOWN_BALANCE = current_balance
                            config.WITHDRAWAL_DETECTED_TODAY = True
                        
                        # Send immediate alert
                        send_email(
                            f"⚠️  WARNING: Withdrawal Alert - ${withdrawn:.2f}",
                            f"Withdrawal detected at {deal_time_ist.strftime('%H:%M:%S')} IST\n\n"
                            f"Previous balance: ${previous_balance:.2f}\n"
                            f"Current balance: ${current_balance:.2f}\n"
                            f"Withdrawn: ${withdrawn:.2f}\n\n"
                            f"Lot sizing will adjust automatically for remaining trades today."
                        )
                    
                    elif profit > 0:
                        # DEPOSIT DETECTED
                        deposited = profit
                        
                        acc = mt5.account_info()
                        current_balance = float(acc.balance) if acc else 0.0
                        
                        print(f"\n[DEPOSIT] ✅ OK: DETECTED at {deal_time_ist.strftime('%Y-%m-%d %H:%M:%S')} IST")
                        print(f"[DEPOSIT] Amount: ${deposited:.2f}")
                        print(f"[DEPOSIT] New balance: ${current_balance:.2f}\n")
                        
                        # Update baseline
                        save_baseline(current_balance)
                        
                        # Update tracked balance
                        with BALANCE_LOCK:
                            config.LAST_KNOWN_BALANCE = current_balance
            
            # Update last checked time
            last_checked_time = now
            
            # Sleep for 2 minutes
            _time.sleep(BALANCE_MONITOR_INTERVAL_SECONDS)
            
        except Exception as e:
            print(f"[BALANCE_MONITOR] Error: {e}")
            _time.sleep(BALANCE_MONITOR_INTERVAL_SECONDS)
