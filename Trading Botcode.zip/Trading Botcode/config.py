"""
Configuration file for MT5 Trading Bot
Contains all constants, credentials, and settings
"""
from datetime import timezone, timedelta
from pathlib import Path
from threading import Event, Lock

# ========= MT5 CREDENTIALS =========
ACCOUNT = 274422550  # Your Exness demo account
PASSWORD = "N1kunjAa@123"
SERVER = "Exness-MT5Trial6"
SYMBOL = "XAUUSDm"

# ========= TRADING SCHEDULE =========
IST_TRADE_TIMES = [
    "05:50", "06:30", "08:05", "08:55", "09:25", "09:45", "10:05", "10:35",
    "18:30", "18:35", "19:00", "19:05", "19:30", "19:35", "19:45", "20:05", "20:30", "20:35"
]

# ========= STRATEGY PARAMETERS =========
SL_PIPS = 20
TP_PIPS = 60
PIP_SIZE = 0.10
DOLLAR_PER_PIP_PER_001LOT = 1.0
DEVIATION = 20
MAGIC = 20250901

# ========= PARTIAL CLOSE CONFIGURATION =========
PARTIAL_CLOSE_TRIGGER_PIPS = 50  # Trigger partial close at +50 pips
PARTIAL_CLOSE_PERCENTAGE_EVEN = 0.5  # 50% for even lots
PARTIAL_CLOSE_PERCENTAGE_ODD = 0.66  # 66% for odd lots

# ========= EMAIL CONFIGURATION =========
EMAIL_SENDER = "n1kunj7r1v3d1@gmail.com"
EMAIL_PASSWORD = "vzed scso otcq cctn"
EMAIL_RECEIVER = "n1kunj7r1v3d1@gmail.com"
SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 465

# ========= LOGGING CONFIGURATION =========
LOG_DIR = Path("trade_logs")
LOG_DIR.mkdir(exist_ok=True)

HEARTBEAT_LOG_DIR = LOG_DIR / "heartbeat_logs"
HEARTBEAT_LOG_DIR.mkdir(exist_ok=True)
HEARTBEAT_LOG_EMAIL_TIME = "00:05"  # Email previous day's log at 00:05 IST
HEARTBEAT_LOG_EMAILED_TODAY = False

LOG_HEADER = [
    "(Date)", "(Trade_Number)", "(Entry Time)", "(Entry price)", "(SL Price)", "(TP Price)",
    "(Partial Close Price)", "(Lot Size)", "(Trade Outcome)", "(Partial Close)", "(PnL)", "(Account balance)"
]
DATE_FMT = "%d-%m-%Y"

# ========= BASELINE MANAGEMENT =========
BASELINE_STATE_FILE = LOG_DIR / "baseline_state.json"
WITHDRAWAL_LOG = LOG_DIR / "withdrawals_history.csv"
DEFAULT_BASELINE = 500.0

# ========= LOT SIZING =========
MIN_LOT = 0.01
MAX_LOSS_PER_TRADE_USD = 100.0

# ========= TIMEZONE CONFIGURATION =========
IST_TZ = timezone(timedelta(hours=5, minutes=30))
MANUAL_SERVER_DELTA_MINUTES = -210  # GMT+2 to IST

# ========= TRIGGER WINDOWS =========
FIRE_WINDOW_SECONDS = 10  # Reduced from 60 to 10 for precision
EARLY_TRIGGER_WINDOW_SECONDS = 0  # Changed from 2 to 0 - no early firing!

# ========= WATCHER CONFIGURATION =========
MAX_POSITION_HOLD_HOURS = 2  # Trades close in 5-15 mins typically

# ========= REPORT GENERATION =========
REPORT_HISTORY_WAIT_MINUTES = 5  # Wait 5 mins after all trades close
REPORT_VERIFICATION_RETRIES = 5  # Retry up to 5 times if history incomplete

# ========= BALANCE MONITOR =========
BALANCE_MONITOR_INTERVAL_SECONDS = 120  # Check every 2 minutes

# ========= BALANCE QUERY TIMING =========
BALANCE_QUERY_TIME = "05:45"  # Query balance at 05:45 IST (5 mins before first trade)

# ========= TRADING DAYS =========
SKIP_THURSDAY = True  # Set to False to enable Thursday trading
TRADING_DAYS = [0, 1, 2, 4]  # Monday=0, Tuesday=1, Wednesday=2, Thursday=3, Friday=4

# ========= SKIP TRACKING =========
SKIPPED_SLOTS = {}  # Track skipped slots with reasons
SKIPPED_SLOTS_LOCK = Lock()
LAST_SLOT_TIME = "20:35"  # Last scheduled slot
REPORT_WAIT_AFTER_LAST_CLOSE = 120  # 2 minutes in seconds

# ========= TICK LEDGER CONFIGURATION =========
TICK_LEDGER_DIR = LOG_DIR / "tick_ledger"
TICK_LEDGER_DIR.mkdir(exist_ok=True)
TICK_LEDGER_RETENTION_DAYS = 7  # Keep tick ledgers for 7 days

# ========= SHARED STATE =========
OPEN_TRADES_GLOBAL = 0
EMAIL_SENT_TODAY = False
RUN_HEARTBEAT = Event()
RUN_HEARTBEAT.set()
TRADES_OPENED_TODAY = 0
TRADES_CLOSED_TODAY = 0
TRADES_LOCK = Lock()
ACTIVE_WATCHERS = {}
WATCHERS_LOCK = Lock()

# ========= BALANCE MONITORING =========
LAST_KNOWN_BALANCE = 0.0
BALANCE_LOCK = Lock()
WITHDRAWAL_DETECTED_TODAY = False
BALANCE_QUERIED_TODAY = False

# ========= OPENING PRICES STORAGE =========
CANDLE_OPENS = {}
CANDLE_OPENS_LOCK = Lock()

# ========= REPORT GENERATION STATE =========
REPORT_WAIT_TRIGGERED = False
REPORT_WAIT_START_TIME = None
REPORT_WAIT_LOCK = Lock()
LAST_SLOT_CLOSED = False
LAST_SLOT_CLOSE_TIME = None

# ========= INTERNAL LEDGER MANAGEMENT =========
LEDGER_DATA = {}
LEDGER_LOCK = Lock()
DAILY_OPENING_BALANCE = 0.0
DAILY_CLOSING_BALANCE = 0.0

# ========= HEARTBEAT LOGGING =========
HEARTBEAT_LOG_FILE = None
HEARTBEAT_LOG_LOCK = Lock()
