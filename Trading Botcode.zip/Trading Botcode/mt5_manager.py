"""
MT5 Manager Module
Handles MetaTrader5 initialization, connection, and scheduling
"""
import MetaTrader5 as mt5
from datetime import datetime, timedelta, date, time as dt_time, timezone
from typing import Tuple, Dict
from config import (
    ACCOUNT, PASSWORD, SERVER, SYMBOL, IST_TZ,
    IST_TRADE_TIMES, MANUAL_SERVER_DELTA_MINUTES
)
from utils import parse_ist_hhmm

def init_mt5():
    """Initialize MT5 and login to account"""
    if not mt5.initialize():
        raise RuntimeError(f"MT5 init error: {mt5.last_error()}")
    if not mt5.login(ACCOUNT, password=PASSWORD, server=SERVER):
        raise RuntimeError(f"MT5 login error: {mt5.last_error()}")
    info = mt5.symbol_info(SYMBOL)
    if info is None:
        raise RuntimeError(f"{SYMBOL} not found")
    if not info.visible:
        mt5.symbol_select(SYMBOL, True)

def shutdown_mt5():
    """Shutdown MT5 connection"""
    mt5.shutdown()

def _ist_from_epoch(sec: float) -> datetime:
    """Convert epoch seconds to IST datetime"""
    return datetime.fromtimestamp(sec, tz=timezone.utc).astimezone(IST_TZ)

def ist_to_server_delta_minutes_for_date(d: date) -> int:
    """Calculate server-IST time delta in minutes"""
    if MANUAL_SERVER_DELTA_MINUTES is not None:
        return MANUAL_SERVER_DELTA_MINUTES
    return -210

def build_server_schedule_for_day(ist_day: date) -> Tuple[Dict[str, datetime], int]:
    """Build server time schedule for a given IST day"""
    delta_min = ist_to_server_delta_minutes_for_date(ist_day)
    delta = timedelta(minutes=delta_min)
    sched = {}
    for tstr in IST_TRADE_TIMES:
        hh, mm = parse_ist_hhmm(tstr)
        ist_dt = datetime.combine(ist_day, dt_time(hh, mm, tzinfo=IST_TZ))
        server_dt = (ist_dt + delta).replace(tzinfo=None)
        sched[f"{hh:02d}:{mm:02d}"] = server_dt
    return sched, delta_min
