"""
Test WordPress Database Connection
Run this before integrating with your bot
"""
from wordpress_integration import wp_db

print("="*60)
print("WordPress Database Connection Test")
print("="*60)

# Test 1: Connection
print("\n[TEST 1] Testing database connection...")
if wp_db.connection and wp_db.connection.is_connected():
    print("✅ SUCCESS: Connected to WordPress database")
else:
    print("❌ FAILED: Could not connect to database")
    print("   Check your credentials in wordpress_integration.py")
    exit(1)

# Test 2: Table existence
print("\n[TEST 2] Checking if WordPress plugin tables exist...")
tables = [
    'tbd_config',
    'tbd_trades',
    'tbd_positions',
    'tbd_status',
    'tbd_logs',
    'tbd_stats'
]

query = f"SHOW TABLES LIKE '{wp_db.TABLE_PREFIX}tbd_%'"
result = wp_db.execute_fetch(query)

if result and len(result) >= 6:
    print(f"✅ SUCCESS: Found {len(result)} WordPress plugin tables")
    for table in result:
        print(f"   - {list(table.values())[0]}")
else:
    print("❌ FAILED: WordPress plugin tables not found")
    print("   Make sure you've installed and activated the WordPress plugin")
    exit(1)

# Test 3: Write test
print("\n[TEST 3] Testing database write...")
if wp_db.log_activity('info', 'Test message from Python bot'):
    print("✅ SUCCESS: Wrote test log to database")
else:
    print("❌ FAILED: Could not write to database")
    exit(1)

# Test 4: Read test
print("\n[TEST 4] Testing database read...")
config_value = wp_db.get_config('symbol')
if config_value:
    print(f"✅ SUCCESS: Read config from database")
    print(f"   Symbol: {config_value}")
else:
    print("⚠️  WARNING: Could not read config (this is OK if you haven't set config yet)")

# Test 5: Update status test
print("\n[TEST 5] Testing status update...")
if wp_db.update_bot_status('running', 500.0, 500.0, 0, 0.0, 0):
    print("✅ SUCCESS: Updated bot status")
else:
    print("❌ FAILED: Could not update status")
    exit(1)

# Test 6: Save trade test
print("\n[TEST 6] Testing trade save...")
test_ticket = 999999999
if wp_db.save_trade(
    ticket=test_ticket,
    trade_date='2025-01-01',
    trade_number=1,
    entry_time='10:00',
    entry_price=2650.00,
    sl_price=2648.00,
    tp_price=2656.00,
    lot_size=0.01,
    signal='BUY',
    outcome='TP',
    pnl=60.0,
    balance=560.0,
    tag='test'
):
    print("✅ SUCCESS: Saved test trade")
    
    # Clean up test trade
    query = f"DELETE FROM {wp_db.TABLE_PREFIX}tbd_trades WHERE ticket = %s"
    wp_db.execute(query, (test_ticket,))
    print("   (Test trade cleaned up)")
else:
    print("❌ FAILED: Could not save trade")
    exit(1)

print("\n" + "="*60)
print("🎉 ALL TESTS PASSED!")
print("="*60)
print("\nYour WordPress database connection is working perfectly!")
print("You can now integrate the bot with WordPress.\n")
print("Next steps:")
print("1. Replace position_watcher.py with position_watcher_wordpress.py")
print("2. Add status updates to main.py (see MAIN_PY_ADDITIONS.txt)")
print("3. Run your bot")
print("4. Access your dashboard at: https://your-site.com/dashboard")
print("="*60)
