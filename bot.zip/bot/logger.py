"""
Logger Module
Handles heartbeat logging and tick ledger management
"""
import json
from datetime import datetime, date, timedelta, timezone
from pathlib import Path
from typing import Dict, Optional
from config import (
    HEARTBEAT_LOG_DIR, HEARTBEAT_LOG_FILE, HEARTBEAT_LOG_LOCK,
    TICK_LEDGER_DIR, TICK_LEDGER_RETENTION_DAYS,
    IST_TZ, SKIP_THURSDAY
)
from utils import fmt_date
from email_manager import send_email

# ========= HEARTBEAT LOGGING =========

def get_heartbeat_log_filepath(ist_day: date) -> Path:
    """Get the heartbeat log file path for a specific date"""
    return HEARTBEAT_LOG_DIR / f"heartbeat_{fmt_date(ist_day)}.txt"

def init_heartbeat_log(ist_day: date):
    """Initialize heartbeat log file for the day"""
    import config
    
    log_path = get_heartbeat_log_filepath(ist_day)
    
    try:
        with HEARTBEAT_LOG_LOCK:
            config.HEARTBEAT_LOG_FILE = open(log_path, 'a', encoding='utf-8', buffering=1)  # Line buffered
            
            # Write header if new file
            if log_path.stat().st_size == 0:
                day_name = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'][ist_day.weekday()]
                config.HEARTBEAT_LOG_FILE.write(f"=== Heartbeat Log for {day_name}, {fmt_date(ist_day)} ===\n")
                config.HEARTBEAT_LOG_FILE.write(f"Started: {datetime.now(timezone.utc).astimezone(IST_TZ).strftime('%H:%M:%S')} IST\n")
                
                if SKIP_THURSDAY and ist_day.weekday() == 3:
                    config.HEARTBEAT_LOG_FILE.write(f"WARNING: THURSDAY - All trading disabled (SKIP_THURSDAY=True)\n")
                
                config.HEARTBEAT_LOG_FILE.write(f"\n")
        
        print(f"[HEARTBEAT_LOG] Initialized: {log_path.name}")
    except Exception as e:
        print(f"[HEARTBEAT_LOG] ERROR: Failed to initialize log file: {e}")

def close_heartbeat_log():
    """Close current heartbeat log file"""
    import config
    
    try:
        with HEARTBEAT_LOG_LOCK:
            if config.HEARTBEAT_LOG_FILE:
                config.HEARTBEAT_LOG_FILE.write(f"\n--- End of Day ---\n")
                config.HEARTBEAT_LOG_FILE.close()
                config.HEARTBEAT_LOG_FILE = None
    except Exception as e:
        print(f"[HEARTBEAT_LOG] ERROR: Failed to close log file: {e}")

def log_to_heartbeat(message: str):
    """Write a message to both console and heartbeat log file"""
    import config
    
    # Print to console
    print(message, flush=True)
    
    # Write to log file
    try:
        with HEARTBEAT_LOG_LOCK:
            if config.HEARTBEAT_LOG_FILE:
                config.HEARTBEAT_LOG_FILE.write(message + '\n')
    except Exception as e:
        # Don't let logging errors crash the bot
        pass

def email_heartbeat_log(ist_day: date):
    """Email the heartbeat log for a specific day"""
    log_path = get_heartbeat_log_filepath(ist_day)
    
    if not log_path.exists():
        print(f"[HEARTBEAT_EMAIL] No log file found for {fmt_date(ist_day)}")
        return
    
    try:
        day_name = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'][ist_day.weekday()]
        subject = f"Heartbeat Log - {day_name} {fmt_date(ist_day)}"
        
        # Read file size
        file_size_mb = log_path.stat().st_size / (1024 * 1024)
        
        body = (
            f"Attached is the complete heartbeat log for {day_name}, {fmt_date(ist_day)}.\n\n"
            f"Log file: {log_path.name}\n"
            f"File size: {file_size_mb:.2f} MB\n\n"
            f"This log contains every heartbeat message and system event from the entire trading day.\n"
            f"Use Ctrl+F to search for specific times, trades, or events."
        )
        
        send_email(subject, body, log_path)
        print(f"[HEARTBEAT_EMAIL] Sent log for {fmt_date(ist_day)}")
        
    except Exception as e:
        print(f"[HEARTBEAT_EMAIL] ERROR: Failed to email log: {e}")

# ========= TICK LEDGER =========

def get_tick_ledger_path(d: date) -> Path:
    """Get the tick ledger file path for a specific date"""
    return TICK_LEDGER_DIR / f"tick_ledger_{d.isoformat()}.json"

def load_tick_ledger(d: date) -> Dict:
    """Load tick ledger for a specific date"""
    ledger_path = get_tick_ledger_path(d)
    if ledger_path.exists():
        try:
            with open(ledger_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                print(f"[TICK_LEDGER] Loaded {len(data.get('ticks', {}))} recorded ticks for {d.isoformat()}")
                return data
        except Exception as e:
            print(f"[TICK_LEDGER] Error loading ledger: {e}")
            return {"date": d.isoformat(), "ticks": {}, "metadata": {}}
    return {"date": d.isoformat(), "ticks": {}, "metadata": {}}

def save_tick_to_ledger(d: date, time_key: str, price: float, source: str = "live"):
    """
    Save a tick price to the ledger immediately
    
    Args:
        d: Date of the tick
        time_key: Time in HH:MM format (opening time, not trade time)
        price: The captured price
        source: Source of the data ('live', 'backfill', etc.)
    """
    try:
        ledger_path = get_tick_ledger_path(d)
        
        # Load existing ledger
        if ledger_path.exists():
            with open(ledger_path, 'r', encoding='utf-8') as f:
                ledger = json.load(f)
        else:
            ledger = {"date": d.isoformat(), "ticks": {}, "metadata": {}}
        
        # Update or add the tick
        if time_key not in ledger["ticks"]:
            ledger["ticks"][time_key] = {
                "price": price,
                "source": source,
                "captured_at": datetime.now(IST_TZ).isoformat(),
                "updates": []
            }
            print(f"[TICK_LEDGER] Saved {time_key} IST: {source.upper()} = {price:.3f}")
        else:
            # Track updates if price changes
            old_price = ledger["ticks"][time_key]["price"]
            if abs(old_price - price) > 0.001:  # Only log significant changes
                ledger["ticks"][time_key]["updates"].append({
                    "old_price": old_price,
                    "new_price": price,
                    "timestamp": datetime.now(IST_TZ).isoformat()
                })
            ledger["ticks"][time_key]["price"] = price
            ledger["ticks"][time_key]["source"] = source
            print(f"[TICK_LEDGER] Updated {time_key} IST: {source.upper()} = {price:.3f}")
        
        # Update metadata
        ledger["metadata"]["last_updated"] = datetime.now(IST_TZ).isoformat()
        ledger["metadata"]["total_ticks"] = len(ledger["ticks"])
        
        # Save back to file
        with open(ledger_path, 'w', encoding='utf-8') as f:
            json.dump(ledger, f, indent=2, ensure_ascii=False)
        
    except Exception as e:
        print(f"[TICK_LEDGER] Error saving tick: {e}")

def get_tick_from_ledger(d: date, time_key: str) -> Optional[float]:
    """Get a specific tick price from the ledger"""
    try:
        ledger = load_tick_ledger(d)
        if time_key in ledger.get("ticks", {}):
            price = ledger["ticks"][time_key]["price"]
            source = ledger["ticks"][time_key]["source"]
            print(f"[TICK_LEDGER] Retrieved {time_key} IST from ledger: {price:.3f} ({source})")
            return price
    except Exception as e:
        print(f"[TICK_LEDGER] Error retrieving tick: {e}")
    return None

def cleanup_old_tick_ledgers():
    """Remove tick ledgers older than TICK_LEDGER_RETENTION_DAYS"""
    try:
        cutoff_date = date.today() - timedelta(days=TICK_LEDGER_RETENTION_DAYS)
        removed_count = 0
        
        for ledger_file in TICK_LEDGER_DIR.glob("tick_ledger_*.json"):
            try:
                # Extract date from filename: tick_ledger_YYYY-MM-DD.json
                date_str = ledger_file.stem.replace("tick_ledger_", "")
                file_date = date.fromisoformat(date_str)
                
                if file_date < cutoff_date:
                    ledger_file.unlink()
                    removed_count += 1
                    print(f"[TICK_LEDGER] Removed old ledger: {ledger_file.name}")
            except Exception as e:
                print(f"[TICK_LEDGER] Error processing {ledger_file.name}: {e}")
        
        if removed_count > 0:
            print(f"[TICK_LEDGER] Cleanup complete: {removed_count} old ledgers removed")
    except Exception as e:
        print(f"[TICK_LEDGER] Cleanup error: {e}")
