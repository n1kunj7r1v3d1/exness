"""Main entry point for MT5 Trading Bot"""
import time as _time
import threading
from datetime import datetime, timedelta, date
from config import (
    IST_TRADE_TIMES, FIRE_WINDOW_SECONDS, EARLY_TRIGGER_WINDOW_SECONDS,
    BALANCE_QUERY_TIME, SKIP_THURSDAY, RUN_HEARTBEAT, EMAIL_SENT_TODAY,
    BALANCE_QUERIED_TODAY, WITHDRAWAL_DETECTED_TODAY, HEARTBEAT_LOG_EMAILED_TODAY,
    REPORT_WAIT_TRIGGERED, REPORT_WAIT_START_TIME, LAST_SLOT_CLOSED,
    LAST_SLOT_CLOSE_TIME, TRADES_OPENED_TODAY, TRADES_CLOSED_TODAY,
    TRADES_LOCK, CANDLE_OPENS, CANDLE_OPENS_LOCK, SKIPPED_SLOTS,
    SKIPPED_SLOTS_LOCK, LAST_SLOT_TIME, OPEN_TRADES_GLOBAL, ACTIVE_WATCHERS,
    WATCHERS_LOCK, LEDGER_DATA, DAILY_OPENING_BALANCE
)
from utils import fmt_date, parse_ist_hhmm, now_ist
from mt5_connector import init_mt5, shutdown_mt5, place_trade, verify_position_exists, compute_sl_tp
from email_handler import send_email
from logging_handler import (
    init_csv, init_heartbeat_log, write_heartbeat,
    close_heartbeat_log, email_heartbeat_log_if_needed
)
from tick_ledger import capture_tick_price, backfill_todays_opens, cleanup_old_tick_ledgers
from ledger import load_ledger, save_ledger, create_ledger_entry, LEDGER_LOCK
from baseline import load_baseline, balance_monitor_thread, query_balance_at_scheduled_time
from trading_logic import (
    get_signal_from_live_opens, lot_size_simple_compound,
    build_server_schedule_for_day
)
from position_watcher import spawn_watcher
from report_generator import check_day_end_conditions, attempt_report_generation
from crash_recovery import rebuild_from_mt5
import MetaTrader5 as mt5

# WordPress Integration
try:
    from wordpress_integration import wp_update_bot_status, wp_log
    WORDPRESS_ENABLED = True
    print("[WP] WordPress integration enabled")
except ImportError:
    WORDPRESS_ENABLED = False
    print("[WP] WordPress integration disabled (wordpress_integration.py not found)")

def update_next_slot(server_now: datetime, schedule: dict, executed: set, ist_day: date, delta_min: int):
    """Update next slot info"""
    remaining = [(k, v) for k, v in schedule.items() if k not in executed]
    
    if remaining:
        remaining_sorted = sorted(remaining, key=lambda x: x[1])
        next_ist, next_server = remaining_sorted[0]
        time_to_next = (next_server - server_now).total_seconds()
        
        if time_to_next > 0:
            mins = int(time_to_next // 60)
            secs = int(time_to_next % 60)
            print(f"[NEXT] {next_ist} IST in {mins}m {secs}s")

def heartbeat_logger_thread():
    """Background thread for periodic heartbeat logging"""
    print("[HEARTBEAT] Thread started")
    
    while RUN_HEARTBEAT.is_set():
        try:
            write_heartbeat("[HEARTBEAT] Bot running normally")
            _time.sleep(300)  # Every 5 minutes
        except Exception as e:
            print(f"[HEARTBEAT] Error: {e}")
            _time.sleep(60)
    
    print("[HEARTBEAT] Thread stopped")

def update_wordpress_status():
    """Update WordPress with current bot status"""
    if not WORDPRESS_ENABLED:
        return
    
    try:
        account_info = mt5.account_info()
        if not account_info:
            return
        
        # Calculate today's P&L from ledger
        today_pnl = 0.0
        with LEDGER_LOCK:
            trades = LEDGER_DATA.get("trades", {})
            for trade in trades.values():
                if trade.get("pnl") is not None:
                    today_pnl += trade["pnl"]
        
        # Update WordPress
        wp_update_bot_status(
            status='running',
            balance=account_info.balance,
            equity=account_info.equity,
            open_positions=OPEN_TRADES_GLOBAL,
            today_pnl=today_pnl,
            today_trades=TRADES_OPENED_TODAY
        )
    except Exception as e:
        print(f"[WP] Status update failed: {e}")

def main():
    global EMAIL_SENT_TODAY, BALANCE_QUERIED_TODAY, WITHDRAWAL_DETECTED_TODAY
    global HEARTBEAT_LOG_EMAILED_TODAY, REPORT_WAIT_TRIGGERED, REPORT_WAIT_START_TIME
    global LAST_SLOT_CLOSED, LAST_SLOT_CLOSE_TIME, TRADES_OPENED_TODAY
    global TRADES_CLOSED_TODAY, LEDGER_DATA, DAILY_OPENING_BALANCE
    global OPEN_TRADES_GLOBAL
    
    print("="*60)
    print("MT5 Trading Bot Starting...")
    print("="*60)
    
    try:
        init_mt5()
        print("[MT5] Connected successfully")
    except Exception as e:
        print(f"[MT5] Connection failed: {e}")
        return
    
    # Start balance monitor
    balance_thread = threading.Thread(target=balance_monitor_thread, daemon=True)
    balance_thread.start()
    
    # Start heartbeat logger
    heartbeat_thread = threading.Thread(target=heartbeat_logger_thread, daemon=True)
    heartbeat_thread.start()
    
    # Initialize state
    ist_day = now_ist().date()
    init_csv(ist_day)
    init_heartbeat_log(ist_day)
    
    LEDGER_DATA = load_ledger(ist_day)
    DAILY_OPENING_BALANCE = load_baseline()
    LEDGER_DATA["opening_balance"] = DAILY_OPENING_BALANCE
    save_ledger(ist_day, LEDGER_DATA)
    
    print(f"[STARTUP] Date: {fmt_date(ist_day)}, Opening Balance: ${DAILY_OPENING_BALANCE:.2f}")
    write_heartbeat(f"[STARTUP] Bot started for {fmt_date(ist_day)}")
    
    # Log to WordPress
    if WORDPRESS_ENABLED:
        wp_log('info', f'Bot started for {fmt_date(ist_day)} - Opening balance: ${DAILY_OPENING_BALANCE:.2f}')
    
    # Crash recovery
    rebuild_from_mt5(ist_day)
    
    # Backfill opening prices
    backfill_todays_opens(ist_day)
    
    # Build schedule
    today_server_sched, delta_min = build_server_schedule_for_day(ist_day)
    executed_ist_today = set()
    current_ist_day = ist_day
    
    print(f"[SCHEDULE] {len(IST_TRADE_TIMES)} slots scheduled")
    if SKIP_THURSDAY and ist_day.weekday() == 3:
        print("[WARNING] Thursday - Trading disabled")
    
    # WordPress update counter
    wordpress_update_counter = 0
    
    try:
        while True:
            _time.sleep(1)
            
            now_ist_dt = now_ist()
            ist_day = now_ist_dt.date()
            ist_hhmm = now_ist_dt.strftime("%H:%M")
            
            # Update WordPress status every 10 seconds
            wordpress_update_counter += 1
            if wordpress_update_counter >= 10:
                update_wordpress_status()
                wordpress_update_counter = 0
            
            # Capture opening prices
            if ist_hhmm in [t[:5] for t in IST_TRADE_TIMES if t not in CANDLE_OPENS]:
                # Calculate 5 min before time
                for trade_time in IST_TRADE_TIMES:
                    hh, mm = parse_ist_hhmm(trade_time)
                    opening_dt = datetime.combine(date.today(), datetime.min.time().replace(hour=hh, minute=mm)) - timedelta(minutes=5)
                    opening_key = opening_dt.strftime("%H:%M")
                    
                    if ist_hhmm == opening_key:
                        capture_tick_price(opening_key, ist_day)
            
            # Balance query
            if ist_hhmm == BALANCE_QUERY_TIME and not BALANCE_QUERIED_TODAY:
                query_balance_at_scheduled_time(ist_day, ist_hhmm)
            
            # Heartbeat log email
            email_heartbeat_log_if_needed(ist_day)
            
            # Report generation check
            attempt_report_generation(ist_day)
            
            # Day rollover
            if ist_day != current_ist_day:
                with TRADES_LOCK:
                    if TRADES_OPENED_TODAY != TRADES_CLOSED_TODAY:
                        send_email(
                            "ALERT: Open trades at day rollover",
                            f"Opened: {TRADES_OPENED_TODAY}, Closed: {TRADES_CLOSED_TODAY}"
                        )
                
                close_heartbeat_log()
                
                executed_ist_today.clear()
                current_ist_day = ist_day
                today_server_sched, delta_min = build_server_schedule_for_day(ist_day)
                EMAIL_SENT_TODAY = False
                BALANCE_QUERIED_TODAY = False
                WITHDRAWAL_DETECTED_TODAY = False
                REPORT_WAIT_TRIGGERED = False
                REPORT_WAIT_START_TIME = None
                LAST_SLOT_CLOSED = False
                LAST_SLOT_CLOSE_TIME = None
                HEARTBEAT_LOG_EMAILED_TODAY = False
                
                with TRADES_LOCK:
                    TRADES_OPENED_TODAY = 0
                    TRADES_CLOSED_TODAY = 0
                
                with CANDLE_OPENS_LOCK:
                    CANDLE_OPENS.clear()
                
                with SKIPPED_SLOTS_LOCK:
                    SKIPPED_SLOTS.clear()
                
                LEDGER_DATA = load_ledger(ist_day)
                DAILY_OPENING_BALANCE = load_baseline()
                LEDGER_DATA["opening_balance"] = DAILY_OPENING_BALANCE
                save_ledger(ist_day, LEDGER_DATA)
                
                print(f"\n{'='*60}")
                print(f"[DAY] New day: {fmt_date(ist_day)}")
                print(f"[DAY] Opening balance: ${DAILY_OPENING_BALANCE:.2f}")
                if SKIP_THURSDAY and ist_day.weekday() == 3:
                    print("[DAY] Thursday - Trading disabled")
                print(f"{'='*60}\n")
                
                init_heartbeat_log(ist_day)
                cleanup_old_tick_ledgers()
                backfill_todays_opens(ist_day)
                
                # Log day rollover to WordPress
                if WORDPRESS_ENABLED:
                    wp_log('info', f'Day rollover: {fmt_date(ist_day)} - Opening balance: ${DAILY_OPENING_BALANCE:.2f}')
                
                update_next_slot(
                    (now_ist_dt + timedelta(minutes=delta_min)).replace(tzinfo=None),
                    today_server_sched, executed_ist_today, ist_day, delta_min
                )
            
            # Update open trades counter
            try:
                positions = mt5.positions_get(symbol="XAUUSDm")
                count = sum(1 for p in positions if getattr(p, "magic", 0) == 20250901) if positions else 0
                OPEN_TRADES_GLOBAL = count
            except:
                OPEN_TRADES_GLOBAL = 0
            
            # Trading logic
            from utils import ist_to_server_delta_minutes_for_date
            delta_min = ist_to_server_delta_minutes_for_date(ist_day)
            now_server = (now_ist_dt + timedelta(minutes=delta_min)).replace(tzinfo=None)
            
            is_thursday = ist_day.weekday() == 3
            
            for ist_hhmm_slot, fire_dt_server in list(today_server_sched.items()):
                if ist_hhmm_slot in executed_ist_today:
                    continue
                
                lag = (now_server - fire_dt_server).total_seconds()
                
                if -EARLY_TRIGGER_WINDOW_SECONDS <= lag <= FIRE_WINDOW_SECONDS:
                    current_second = now_server.second
                    
                    if current_second > 10:
                        continue
                    
                    if SKIP_THURSDAY and is_thursday:
                        skip_reason = "Thursday trading disabled"
                        with SKIPPED_SLOTS_LOCK:
                            SKIPPED_SLOTS[ist_hhmm_slot] = skip_reason
                        print(f"[SKIP] {ist_hhmm_slot}: {skip_reason}")
                        executed_ist_today.add(ist_hhmm_slot)
                        update_next_slot(now_server, today_server_sched, executed_ist_today, ist_day, delta_min)
                        continue
                    
                    signal, skip_reason = get_signal_from_live_opens(ist_hhmm_slot)
                    
                    if not signal:
                        if skip_reason:
                            with SKIPPED_SLOTS_LOCK:
                                SKIPPED_SLOTS[ist_hhmm_slot] = skip_reason
                            print(f"[SKIP] {ist_hhmm_slot}: {skip_reason}")
                        
                        executed_ist_today.add(ist_hhmm_slot)
                        update_next_slot(now_server, today_server_sched, executed_ist_today, ist_day, delta_min)
                        continue
                    
                    vol = lot_size_simple_compound()
                    tag = f"{ist_day.isoformat()}_{ist_hhmm_slot}"
                    
                    print(f"[SIGNAL] {ist_hhmm_slot} -> {signal}, vol={vol:.2f}")
                    
                    result = place_trade(signal, vol, tag)
                    executed_ist_today.add(ist_hhmm_slot)
                    update_next_slot(now_server, today_server_sched, executed_ist_today, ist_day, delta_min)
                    
                    if result and result.retcode == mt5.TRADE_RETCODE_DONE:
                        pos_ticket = verify_position_exists(result, f"60pip_bot|{tag}")
                        
                        if pos_ticket:
                            with TRADES_LOCK:
                                TRADES_OPENED_TODAY += 1
                                trade_number = TRADES_OPENED_TODAY
                            
                            tick = mt5.symbol_info_tick("XAUUSDm")
                            entry_price = tick.ask if signal == "BUY" else tick.bid
                            sl, tp = compute_sl_tp(entry_price, signal)
                            
                            create_ledger_entry(
                                pos_ticket, ist_day, trade_number,
                                ist_hhmm_slot, entry_price, sl, tp,
                                vol, signal, tag
                            )
                            
                            spawn_watcher(pos_ticket, signal, tag, ist_day)
                            print(f"[SUCCESS] Position {pos_ticket} opened")
                        else:
                            print(f"[ERROR] Position verification failed")
                            with SKIPPED_SLOTS_LOCK:
                                SKIPPED_SLOTS[ist_hhmm_slot] = "Verification failed"
                    else:
                        print(f"[TRADE] Failed: {getattr(result, 'retcode', None)}")
                        with SKIPPED_SLOTS_LOCK:
                            SKIPPED_SLOTS[ist_hhmm_slot] = f"Trade failed - {getattr(result, 'retcode', 'unknown')}"
                
                elif lag > FIRE_WINDOW_SECONDS:
                    with SKIPPED_SLOTS_LOCK:
                        if ist_hhmm_slot not in SKIPPED_SLOTS:
                            SKIPPED_SLOTS[ist_hhmm_slot] = f"Slot expired ({int(lag)}s)"
                    
                    executed_ist_today.add(ist_hhmm_slot)
                    update_next_slot(now_server, today_server_sched, executed_ist_today, ist_day, delta_min)
            
            check_day_end_conditions(ist_day, executed_ist_today, today_server_sched)
    
    except KeyboardInterrupt:
        print("\n[STOP] Bot interrupted")
    finally:
        RUN_HEARTBEAT.clear()
        _time.sleep(0.5)
        
        # Log shutdown to WordPress
        if WORDPRESS_ENABLED:
            try:
                wp_log('info', f'Bot stopped - Trades today: {TRADES_OPENED_TODAY}, Closed: {TRADES_CLOSED_TODAY}')
                account_info = mt5.account_info()
                if account_info:
                    wp_update_bot_status(
                        status='stopped',
                        balance=account_info.balance,
                        equity=account_info.equity,
                        open_positions=0,
                        today_pnl=0,
                        today_trades=TRADES_OPENED_TODAY
                    )
            except:
                pass
        
        with WATCHERS_LOCK:
            active = list(ACTIVE_WATCHERS.values())
        
        for thr in active:
            if thr.is_alive():
                thr.join(timeout=2.0)
        
        shutdown_mt5()
        print("[SHUTDOWN] Complete")

if __name__ == "__main__":
    main()