"""
Position Watcher Module
Monitors open positions and handles partial/full closes
"""
import MetaTrader5 as mt5
import threading
from datetime import datetime, timedelta, timezone
import time as _time
from config import (
    SYMBOL, MAGIC, MAX_POSITION_HOLD_HOURS, PIP_SIZE,
    PARTIAL_CLOSE_TRIGGER_PIPS, PARTIAL_CLOSE_PERCENTAGE_EVEN,
    PARTIAL_CLOSE_PERCENTAGE_ODD, ACTIVE_WATCHERS, WATCHERS_LOCK,
    TRADES_CLOSED_TODAY, TRADES_LOCK, IST_TZ,
    LAST_SLOT_CLOSED, LAST_SLOT_CLOSE_TIME, LAST_SLOT_TIME
)
from ledger_manager import update_ledger_entry
from logger import log_to_heartbeat

# WordPress Integration
from wordpress_integration import wp_update_position, wp_save_trade, POSITION_UPDATE_INTERVAL
import time as _time

        entry_price = float(open_deal.price)
        volume = float(open_deal.volume)
        side = "BUY" if getattr(open_deal, "type", 0) == mt5.DEAL_TYPE_BUY else "SELL"
        
        net_profit = sum(float(x.profit) for x in lst)
        outcome = "PROFIT" if net_profit > 0 else "LOSS"
        
        sl, tp = compute_sl_tp(entry_price, side)
        
        trades.append({
            "date": date_str,
            "time": time_str,
            "entry": entry_price,
            "sl": sl,
            "tp": tp,
            "vol": round(volume, 2),
            "outcome": outcome,
            "pnl": net_profit,
            "open_epoch": open_deal.time,
            "position_id": pid
        })
    
    if skipped_positions:
        print(f"[ERROR] {len(skipped_positions)} positions skipped - history incomplete!")
        print(f"[ERROR] Missing position IDs: {skipped_positions}")
    
    trades.sort(key=lambda x: x["open_epoch"])
    print(f"[HISTORY] Successfully collected {len(trades)} complete trades")
    return trades

def verify_ledger_against_mt5(ledger_trades: List[dict], mt5_trades: List[dict]) -> Dict:
    """
    Compare ledger trades against MT5 history.
    Returns verification report.
    """
    verification = {
        "status": "VERIFIED",
        "ledger_count": len(ledger_trades),
        "mt5_count": len(mt5_trades),
        "missing_in_mt5": [],
        "discrepancies": []
    }
    
    # Check if all ledger trades are in MT5
    ledger_pids = {t["position_id"] for t in ledger_trades}
    mt5_pids = {t["position_id"] for t in mt5_trades}
    
    missing_pids = ledger_pids - mt5_pids
    
    if missing_pids:
        verification["status"] = "PENDING_SYNC"
        for pid in missing_pids:
            ledger_trade = next((t for t in ledger_trades if t["position_id"] == pid), None)
            if ledger_trade:
                verification["missing_in_mt5"].append({
                    "position_id": pid,
                    "trade_number": ledger_trade["trade_number"],
                    "entry_time": ledger_trade["entry_time"]
                })
    
    # Check for discrepancies in PnL
    for lt in ledger_trades:
        mt5_trade = next((t for t in mt5_trades if t["position_id"] == lt["position_id"]), None)
        if mt5_trade:
            pnl_diff = abs(lt["pnl"] - mt5_trade["pnl"])
            if pnl_diff > 0.01:  # More than 1 cent difference
                verification["status"] = "DISCREPANCY"
                verification["discrepancies"].append({
                    "position_id": lt["position_id"],
                    "trade_number": lt["trade_number"],
                    "ledger_pnl": lt["pnl"],
                    "mt5_pnl": mt5_trade["pnl"],
                    "difference": lt["pnl"] - mt5_trade["pnl"]
                })
    
    return verification

def build_report(period: str, start_ist: datetime, end_ist: datetime, baseline: float, 
                 out_file: Path, skipped_slots_dict: Dict[str, str] = None):
    """
    Build report using INTERNAL LEDGER as primary source.
    MT5 history used only for verification.
    Now includes skipped/missed slots with detailed reasons.
    FIXED: All CSV writes use UTF-8 encoding to prevent charmap codec errors.
    """
    global LEDGER_DATA
    
    if skipped_slots_dict is None:
        skipped_slots_dict = {}
    
    # Get trades from ledger
    ledger_trades = []
    with LEDGER_LOCK:
        for tag, entry in sorted(LEDGER_DATA["trades"].items()):
            if entry["status"] == "CLOSED":
                ledger_trades.append({
                    "date": entry["date"],
                    "trade_number": entry["trade_number"],
                    "time": entry["entry_time"],
                    "entry": entry["entry_price"],
                    "sl": entry["sl_price"],
                    "tp": entry["tp_price"],
                    "partial_close_price": entry.get("partial_close_price"),
                    "vol": entry["lot_size"],
                    "outcome": entry["trade_outcome"],
                    "partial_close_net": entry.get("partial_close_net"),
                    "pnl": entry["pnl"],
                    "balance": entry["account_balance"],
                    "position_id": entry["position_id"],
                    "entry_time": entry["entry_time"]
                })
    
    # Sort by trade number
    ledger_trades.sort(key=lambda x: x["trade_number"])
    
    # Query MT5 for verification
    mt5_trades = collect_closed_trades(start_ist, end_ist)
    
    # Verify ledger against MT5
    verification = verify_ledger_against_mt5(ledger_trades, mt5_trades)
    
    # Build CSV rows from LEDGER (primary source)
    rows = []
    for tr in ledger_trades:
        partial_close_price_str = f"{tr['partial_close_price']:.3f}" if tr['partial_close_price'] else ""
        partial_close_net_str = f"${tr['partial_close_net']:.2f}" if tr['partial_close_net'] is not None else ""
        
        rows.append([
            tr["date"], str(tr["trade_number"]), tr["time"],
            f"{tr['entry']:.3f}", f"{tr['sl']:.3f}", f"{tr['tp']:.3f}",
            partial_close_price_str,
            f"{tr['vol']:.2f}", tr["outcome"],
            partial_close_net_str,
            f"${tr['pnl']:.2f}", f"${tr['balance']:.2f}"
        ])
    
    # Write to CSV with UTF-8 encoding
    out_file.parent.mkdir(parents=True, exist_ok=True)
    with open(out_file, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(LOG_HEADER)
        w.writerows(rows)
    
    # Add summary and verification status
    opening = float(baseline)
    closing = float(ledger_trades[-1]["balance"]) if ledger_trades else opening
    pnl = closing - opening
    
    withdrawals = get_withdrawals_for_period(start_ist.date(), end_ist.date())
    
    # Count executed vs total slots
    executed_times = {tr["entry_time"] for tr in ledger_trades}
    total_slots = len(IST_TRADE_TIMES)
    executed_count = len(executed_times)
    
    with open(out_file, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        blank = [""] * len(LOG_HEADER)
        w.writerow(blank)
        title_row = [""] * len(LOG_HEADER)
        title_row[8] = f"{period} Summary ({executed_count}/{total_slots} trades executed)"
        w.writerow(title_row)
        
        open_row = [""] * len(LOG_HEADER)
        open_row[8] = "Opening Balance"
        open_row[11] = f"${opening:.2f}"
        w.writerow(open_row)
        
        close_row = [""] * len(LOG_HEADER)
        close_row[8] = "Closing Balance"
        close_row[11] = f"${closing:.2f}"
        w.writerow(close_row)
        
        pnl_row = [""] * len(LOG_HEADER)
        pnl_row[8] = "PnL"
        pnl_row[11] = f"${pnl:.2f}" if pnl >= 0 else f"-${abs(pnl):.2f}"
        w.writerow(pnl_row)
        
        # NEW: Add skipped/missed slots section
        if skipped_slots_dict:
            w.writerow(blank)
            skip_header = [""] * len(LOG_HEADER)
            skip_header[8] = f"WARNING Skipped/Missed Slots ({len(skipped_slots_dict)}/{total_slots})"
            w.writerow(skip_header)
            
            for slot_time in sorted(skipped_slots_dict.keys()):
                reason = skipped_slots_dict[slot_time]
                skip_row = [""] * len(LOG_HEADER)
                skip_row[8] = f"{slot_time} IST: {reason}"
                w.writerow(skip_row)
        
        # Add verification status
        w.writerow(blank)
        status_row = [""] * len(LOG_HEADER)
        if verification["status"] == "VERIFIED":
            status_row[8] = f"Report Status: OK VERIFIED ({verification['mt5_count']}/{verification['ledger_count']} trades confirmed in MT5)"
        elif verification["status"] == "PENDING_SYNC":
            status_row[8] = f"Report Status: WARNING PENDING_SYNC ({verification['mt5_count']}/{verification['ledger_count']} trades in MT5)"
        else:
            status_row[8] = f"Report Status: WARNING DISCREPANCY (Manual review needed)"
        w.writerow(status_row)
        
        # Add missing trades warning
        if verification["missing_in_mt5"]:
            w.writerow(blank)
            missing_header = [""] * len(LOG_HEADER)
            missing_header[8] = "WARNING MT5 Sync Status"
            w.writerow(missing_header)
            
            for missing in verification["missing_in_mt5"]:
                missing_row = [""] * len(LOG_HEADER)
                missing_row[8] = f"Missing in MT5 History: Trade #{missing['trade_number']} ({missing['entry_time']} IST) - Position {missing['position_id']}"
                w.writerow(missing_row)
            
            note_row = [""] * len(LOG_HEADER)
            note_row[8] = "Note: These trades were executed and closed by bot. MT5 history sync pending."
            w.writerow(note_row)
        
        # Add PnL discrepancies
        if verification["discrepancies"]:
            w.writerow(blank)
            disc_header = [""] * len(LOG_HEADER)
            disc_header[8] = "WARNING PnL Discrepancies"
            w.writerow(disc_header)
            
            for disc in verification["discrepancies"]:
                disc_row = [""] * len(LOG_HEADER)
                disc_row[8] = f"Trade #{disc['trade_number']}: Ledger ${disc['ledger_pnl']:.2f}, MT5 ${disc['mt5_pnl']:.2f} (Diff: ${disc['difference']:.2f})"
                w.writerow(disc_row)
        
        if withdrawals:
            w.writerow(blank)
            w_row = [""] * len(LOG_HEADER)
            w_row[8] = f"Withdrawals this {period.lower()}: " + ", ".join(withdrawals)
            w.writerow(w_row)
    
    print(f"[REPORT] {period} -> {out_file.name} ({len(rows)} trades, {len(skipped_slots_dict)} skipped, Status: {verification['status']})")

# ===== Heartbeat =====
SCHED_LOCK = Lock()
NEXT_IST_HHMM = None
NEXT_SERVER_DT = None
CURRENT_DELTA_MIN = 0
SLOTS_FIRED = 0
SLOTS_TOTAL = 0

def update_next_slot(now_server, today_server_sched, executed_ist_today, ist_day, delta_min):
    global NEXT_IST_HHMM, NEXT_SERVER_DT, CURRENT_DELTA_MIN, SLOTS_FIRED, SLOTS_TOTAL
    next_ist = None
    for ist_hhmm, server_dt in today_server_sched.items():
        if ist_hhmm in executed_ist_today:
            continue
        if now_server <= server_dt:
            next_ist = ist_hhmm
            break
    
    with SCHED_LOCK:
        NEXT_IST_HHMM = next_ist
        NEXT_SERVER_DT = today_server_sched.get(next_ist) if next_ist else None
        CURRENT_DELTA_MIN = delta_min
        SLOTS_FIRED = len(executed_ist_today)
        SLOTS_TOTAL = len(today_server_sched)

def heartbeat_thread():
    global LAST_KNOWN_BALANCE
    
    while RUN_HEARTBEAT.is_set():
        try:
            now_utc = datetime.now(timezone.utc)
            now_ist = now_utc.astimezone(IST_TZ)
            
            # Get day of week
            day_names = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
            day_name = day_names[now_ist.weekday()]
            
            # Special format for Thursday if trading disabled
            if SKIP_THURSDAY and now_ist.weekday() == 3:
                day_display = "Thursday(Red Day / Loss Day)"
            else:
                day_display = day_name
            
            with SCHED_LOCK:
                next_ist = NEXT_IST_HHMM
                next_server = NEXT_SERVER_DT
                cfg_delta = CURRENT_DELTA_MIN
                fired = SLOTS_FIRED
                total = SLOTS_TOTAL
            
            now_server = (now_ist + timedelta(minutes=cfg_delta)).replace(tzinfo=None)
            
            with TRADES_LOCK:
                opened = TRADES_OPENED_TODAY
                closed = TRADES_CLOSED_TODAY
            
            with BALANCE_LOCK:
                current_bal = LAST_KNOWN_BALANCE
            
            # Fallback: If balance is 0 or not set, fetch live from MT5
            if current_bal == 0.0:
                try:
                    acc = mt5.account_info()
                    if acc:
                        current_bal = float(acc.balance)
                        # Update the global balance
                        with BALANCE_LOCK:
                            LAST_KNOWN_BALANCE = current_bal
                except Exception:
                    pass
            
            withdrawal_flag = "WARNING" if WITHDRAWAL_DETECTED_TODAY else "OK"
            email_status = 1 if EMAIL_SENT_TODAY else 0
            
            # Check if Thursday and no trading
            is_thursday_no_trading = SKIP_THURSDAY and now_ist.weekday() == 3
            
            if next_server is None or is_thursday_no_trading:
                # Show "no trading today" for Thursday or when no more slots
                if is_thursday_no_trading:
                    end_message = "no trading today"
                else:
                    end_message = "no more slots"
                    
                line = (
                    f"[HB] {day_display} | {now_ist.strftime('%H:%M:%S')} | "
                    f"slots {fired}/{total} | "
                    f"trades O:{opened}/18 C:{closed}/18 | "
                    f"balance ${current_bal:.2f} {withdrawal_flag} | "
                    f"email {email_status}/1 | {end_message}"
                )
            else:
                secs = max(0, int((next_server - now_server).total_seconds()))
                hh = secs // 3600
                mm = (secs % 3600) // 60
                ss = secs % 60
                line = (
                    f"[HB] {day_display} | {now_ist.strftime('%H:%M:%S')} | "
                    f"slots {fired}/{total} | "
                    f"trades O:{opened}/18 C:{closed}/18 | "
                    f"balance ${current_bal:.2f} {withdrawal_flag} | "
                    f"email {email_status}/1 | "
                    f"next: {next_ist} in {hh:02d}:{mm:02d}:{ss:02d}"
                )
            
            # Log to both console and file
            log_to_heartbeat(line)
            
        except Exception:
            pass
        _time.sleep(1)

# ===== New Report Building Functions =====
def build_daily_report_from_ledger(ist_day: date, baseline: float, out_file: Path, skipped_slots_dict: dict):
    """
    Build daily report using JSON LEDGER ONLY (no MT5 verification).
    This ensures ALL trades are present immediately, no sync delay.
    """
    global LEDGER_DATA
    
    # Get trades from ledger for current day
    ledger_trades = []
    with LEDGER_LOCK:
        for tag, entry in sorted(LEDGER_DATA["trades"].items()):
            if entry["status"] == "CLOSED":
                ledger_trades.append({
                    "date": entry["date"],
                    "trade_number": entry["trade_number"],
                    "time": entry["entry_time"],
                    "entry": entry["entry_price"],
                    "sl": entry["sl_price"],
                    "tp": entry["tp_price"],
                    "partial_close_price": entry.get("partial_close_price"),
                    "vol": entry["lot_size"],
                    "outcome": entry["trade_outcome"],
                    "partial_close_net": entry.get("partial_close_net"),
                    "pnl": entry["pnl"],
                    "balance": entry["account_balance"]
                })
    
    # Sort by trade number
    ledger_trades.sort(key=lambda x: x["trade_number"])
    
    # Build CSV rows from LEDGER
    rows = []
    for tr in ledger_trades:
        partial_close_price_str = f"{tr['partial_close_price']:.3f}" if tr['partial_close_price'] else ""
        partial_close_net_str = f"${tr['partial_close_net']:.2f}" if tr['partial_close_net'] is not None else ""
        
        rows.append([
            tr["date"], str(tr["trade_number"]), tr["time"],
            f"{tr['entry']:.3f}", f"{tr['sl']:.3f}", f"{tr['tp']:.3f}",
            partial_close_price_str,
            f"{tr['vol']:.2f}", tr["outcome"],
            partial_close_net_str,
            f"${tr['pnl']:.2f}", f"${tr['balance']:.2f}"
        ])
    
    # Write to CSV with UTF-8 encoding
    out_file.parent.mkdir(parents=True, exist_ok=True)
    with open(out_file, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(LOG_HEADER)
        w.writerows(rows)
    
    # Add summary
    opening = float(baseline)
    closing = float(ledger_trades[-1]["balance"]) if ledger_trades else opening
    pnl = closing - opening
    
    executed_count = len(ledger_trades)
    total_slots = len(IST_TRADE_TIMES)
    
    with open(out_file, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        blank = [""] * len(LOG_HEADER)
        w.writerow(blank)
        
        title_row = [""] * len(LOG_HEADER)
        title_row[8] = f"Daily Summary ({executed_count}/{total_slots} trades executed)"
        w.writerow(title_row)
        
        open_row = [""] * len(LOG_HEADER)
        open_row[8] = "Opening Balance"
        open_row[11] = f"${opening:.2f}"
        w.writerow(open_row)
        
        close_row = [""] * len(LOG_HEADER)
        close_row[8] = "Closing Balance"
        close_row[11] = f"${closing:.2f}"
        w.writerow(close_row)
        
        pnl_row = [""] * len(LOG_HEADER)
        pnl_row[8] = "PnL"
        pnl_row[11] = f"${pnl:.2f}" if pnl >= 0 else f"-${abs(pnl):.2f}"
        w.writerow(pnl_row)
        
        # Add skipped slots section
        if skipped_slots_dict:
            w.writerow(blank)
            skip_header = [""] * len(LOG_HEADER)
            skip_header[8] = f"Skipped/Missed Slots ({len(skipped_slots_dict)}/{total_slots})"
            w.writerow(skip_header)
            
            for slot_time in sorted(skipped_slots_dict.keys()):
                reason = skipped_slots_dict[slot_time]
                skip_row = [""] * len(LOG_HEADER)
                skip_row[8] = f"{slot_time} IST: {reason}"
                w.writerow(skip_row)
        
        # Add status
        w.writerow(blank)
        status_row = [""] * len(LOG_HEADER)
        status_row[8] = f"Report Status: SOURCE Internal Ledger (Real-time, {executed_count}/{executed_count} trades)"
        w.writerow(status_row)
    
    print(f"[REPORT] Daily (Ledger-only) -> {out_file.name} ({len(rows)} trades, {len(skipped_slots_dict)} skipped)")


def build_weekly_report_hybrid(week_start: date, week_end: date, baseline: float, out_file: Path):
    """
    Build weekly report using HYBRID approach:
    - Monday-Thursday: MT5 history (old trades, definitely synced)
    - Friday (current day): JSON ledger (real-time, no sync delay)
    """
    all_trades = []
    
    # Days 0-3: Use MT5 history (Monday-Thursday)
    for day_offset in range(4):
        current_date = week_start + timedelta(days=day_offset)
        day_start = datetime.combine(current_date, dt_time(0,0), tzinfo=IST_TZ)
        day_end = datetime.combine(current_date, dt_time(23,59,59), tzinfo=IST_TZ)
        
        # Get trades from MT5 for this day
        trades_from_mt5 = collect_closed_trades(day_start, day_end)
        
        for tr in trades_from_mt5:
            all_trades.append({
                "date": tr["date"],
                "trade_number": len(all_trades) + 1,
                "time": tr["time"],
                "entry": tr["entry"],
                "sl": tr["sl"],
                "tp": tr["tp"],
                "vol": tr["vol"],
                "outcome": tr["outcome"],
                "pnl": tr["pnl"],
                "balance": 0.0  # Will recalculate
            })
    
    # Day 4: Use JSON ledger (Friday - current day)
    friday_date = week_start + timedelta(days=4)
    friday_ledger = load_ledger(friday_date)
    
    for tag, entry in sorted(friday_ledger["trades"].items()):
        if entry["status"] == "CLOSED":
            all_trades.append({
                "date": entry["date"],
                "trade_number": len(all_trades) + 1,
                "time": entry["entry_time"],
                "entry": entry["entry_price"],
                "sl": entry["sl_price"],
                "tp": entry["tp_price"],
                "vol": entry["lot_size"],
                "outcome": entry["trade_outcome"],
                "pnl": entry["pnl"],
                "balance": entry["account_balance"]
            })
    
    # Recalculate balances
    running_balance = baseline
    for tr in all_trades:
        running_balance += tr["pnl"]
        tr["balance"] = running_balance
    
    # Build CSV
    rows = []
    for tr in all_trades:
        rows.append([
            tr["date"], str(tr["trade_number"]), tr["time"],
            f"{tr['entry']:.3f}", f"{tr['sl']:.3f}", f"{tr['tp']:.3f}",
            f"{tr['vol']:.2f}", tr["outcome"],
            f"${tr['pnl']:.2f}", f"${tr['balance']:.2f}"
        ])
    
    out_file.parent.mkdir(parents=True, exist_ok=True)
    with open(out_file, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(LOG_HEADER)
        w.writerows(rows)
    
    # Summary
    opening = float(baseline)
    closing = float(all_trades[-1]["balance"]) if all_trades else opening
    pnl = closing - opening
    
    with open(out_file, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        blank = [""] * len(LOG_HEADER)
        w.writerow(blank)
        
        title_row = [""] * len(LOG_HEADER)
        title_row[7] = f"Weekly Summary ({len(all_trades)} trades executed)"
        w.writerow(title_row)
        
        open_row = [""] * len(LOG_HEADER)
        open_row[7] = "Opening Balance (Monday)"
        open_row[9] = f"${opening:.2f}"
        w.writerow(open_row)
        
        close_row = [""] * len(LOG_HEADER)
        close_row[7] = "Closing Balance (Friday)"
        close_row[9] = f"${closing:.2f}"
        w.writerow(close_row)
        
        pnl_row = [""] * len(LOG_HEADER)
        pnl_row[7] = "Weekly PnL"
        pnl_row[9] = f"${pnl:.2f}" if pnl >= 0 else f"-${abs(pnl):.2f}"
        w.writerow(pnl_row)
        
        w.writerow(blank)
        status_row = [""] * len(LOG_HEADER)
        status_row[7] = "Report Status: HYBRID Mon-Thu (MT5 verified), Fri (Ledger real-time)"
        w.writerow(status_row)
    
    print(f"[REPORT] Weekly (Hybrid) -> {out_file.name} ({len(rows)} trades)")


def build_monthly_report_hybrid(month_start: date, month_end: date, baseline: float, out_file: Path):
    """
    Build monthly report using HYBRID approach:
    - All past days: MT5 history (old trades, definitely synced)
    - Current day: JSON ledger (real-time, no sync delay)
    """
    all_trades = []
    current_day_today = datetime.now(timezone.utc).astimezone(IST_TZ).date()
    
    # All past days: Use MT5 history
    current_date = month_start
    while current_date < current_day_today:
        day_start = datetime.combine(current_date, dt_time(0,0), tzinfo=IST_TZ)
        day_end = datetime.combine(current_date, dt_time(23,59,59), tzinfo=IST_TZ)
        
        # Get trades from MT5 for this day
        trades_from_mt5 = collect_closed_trades(day_start, day_end)
        
        for tr in trades_from_mt5:
            all_trades.append({
                "date": tr["date"],
                "trade_number": len(all_trades) + 1,
                "time": tr["time"],
                "entry": tr["entry"],
                "sl": tr["sl"],
                "tp": tr["tp"],
                "vol": tr["vol"],
                "outcome": tr["outcome"],
                "pnl": tr["pnl"],
                "balance": 0.0  # Will recalculate
            })
        
        current_date += timedelta(days=1)
    
    # Current day ONLY: Use JSON ledger
    if current_day_today <= month_end:
        today_ledger = load_ledger(current_day_today)
        
        for tag, entry in sorted(today_ledger["trades"].items()):
            if entry["status"] == "CLOSED":
                all_trades.append({
                    "date": entry["date"],
                    "trade_number": len(all_trades) + 1,
                    "time": entry["entry_time"],
                    "entry": entry["entry_price"],
                    "sl": entry["sl_price"],
                    "tp": entry["tp_price"],
                    "vol": entry["lot_size"],
                    "outcome": entry["trade_outcome"],
                    "pnl": entry["pnl"],
                    "balance": entry["account_balance"]
                })
    
    # Recalculate balances
    running_balance = baseline
    for tr in all_trades:
        running_balance += tr["pnl"]
        tr["balance"] = running_balance
    
    # Build CSV
    rows = []
    for tr in all_trades:
        rows.append([
            tr["date"], str(tr["trade_number"]), tr["time"],
            f"{tr['entry']:.3f}", f"{tr['sl']:.3f}", f"{tr['tp']:.3f}",
            f"{tr['vol']:.2f}", tr["outcome"],
            f"${tr['pnl']:.2f}", f"${tr['balance']:.2f}"
        ])
    
    out_file.parent.mkdir(parents=True, exist_ok=True)
    with open(out_file, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(LOG_HEADER)
        w.writerows(rows)
    
    # Summary
    opening = float(baseline)
    closing = float(all_trades[-1]["balance"]) if all_trades else opening
    pnl = closing - opening
    
    with open(out_file, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        blank = [""] * len(LOG_HEADER)
        w.writerow(blank)
        
        title_row = [""] * len(LOG_HEADER)
        title_row[7] = f"Monthly Summary ({len(all_trades)} trades executed)"
        w.writerow(title_row)
        
        open_row = [""] * len(LOG_HEADER)
        open_row[7] = "Opening Balance"
        open_row[9] = f"${opening:.2f}"
        w.writerow(open_row)
        
        close_row = [""] * len(LOG_HEADER)
        close_row[7] = "Closing Balance"
        close_row[9] = f"${closing:.2f}"
        w.writerow(close_row)
        
        pnl_row = [""] * len(LOG_HEADER)
        pnl_row[7] = "Monthly PnL"
        pnl_row[9] = f"${pnl:.2f}" if pnl >= 0 else f"-${abs(pnl):.2f}"
        w.writerow(pnl_row)
        
        w.writerow(blank)
        status_row = [""] * len(LOG_HEADER)
        past_days = (current_day_today - month_start).days
        status_row[7] = f"Report Status: HYBRID Past days (MT5 verified), Today (Ledger real-time)"
        w.writerow(status_row)
    
    print(f"[REPORT] Monthly (Hybrid) -> {out_file.name} ({len(rows)} trades)")


# ===== Smart Report Generation =====
def send_reports(ist_day: date, executed_slots: set, today_server_sched: dict):
    global EMAIL_SENT_TODAY
    
    day_start = datetime.combine(ist_day, dt_time(0,0), tzinfo=IST_TZ)
    day_end = datetime.combine(ist_day, dt_time(23,59,59), tzinfo=IST_TZ)
