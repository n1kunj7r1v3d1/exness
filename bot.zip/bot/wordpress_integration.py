"""
WordPress MySQL Integration for Trading Bot
Connects your MT5 bot directly to WordPress database
"""
import mysql.connector
from datetime import datetime
from typing import Optional

# WordPress Database Configuration
# UPDATE THESE WITH YOUR WORDPRESS DATABASE CREDENTIALS
WP_DB_CONFIG = {
    'host': '103.191.209.38',  # e.g., '45.123.456.789' or 'localhost'
    'database': 'cmkbyysn_wp423',  # Your WordPress database name
    'user': 'cmkbyysn_wp423',  # Your WordPress database username
    'password': '25-m1!rSLp',  # Your WordPress database password
    'port': 3306
}

# WordPress table prefix (default is 'wp_' but check your database)
TABLE_PREFIX = 'wp9y_'

class WordPressDB:
    def __init__(self):
        self.connection = None
        self.connect()
    
    def connect(self):
        """Establish connection to WordPress database"""
        try:
            self.connection = mysql.connector.connect(**WP_DB_CONFIG)
            print("[WP_DB] Connected to WordPress database")
        except Exception as e:
            print(f"[WP_DB] Connection failed: {e}")
            self.connection = None
    
    def execute(self, query: str, params: tuple = None):
        """Execute SQL query"""
        if not self.connection or not self.connection.is_connected():
            self.connect()
        
        try:
            cursor = self.connection.cursor()
            cursor.execute(query, params)
            self.connection.commit()
            cursor.close()
            return True
        except Exception as e:
            print(f"[WP_DB] Query failed: {e}")
            return False
    
    def execute_fetch(self, query: str, params: tuple = None):
        """Execute query and fetch results"""
        if not self.connection or not self.connection.is_connected():
            self.connect()
        
        try:
            cursor = self.connection.cursor(dictionary=True)
            cursor.execute(query, params)
            results = cursor.fetchall()
            cursor.close()
            return results
        except Exception as e:
            print(f"[WP_DB] Query failed: {e}")
            return None
    
    def save_trade(self, ticket: int, trade_date: str, trade_number: int, 
                   entry_time: str, entry_price: float, sl_price: float, 
                   tp_price: float, lot_size: float, signal: str, 
                   outcome: str = None, partial_close: str = 'NO',
                   partial_close_price: float = None, close_time: str = None,
                   pnl: float = 0.0, balance: float = 0.0, tag: str = ''):
        """Save or update trade in WordPress database"""
        
        query = f"""
        REPLACE INTO {TABLE_PREFIX}tbd_trades 
        (ticket, trade_date, trade_number, entry_time, entry_price, sl_price, tp_price,
         lot_size, `signal`, outcome, partial_close, partial_close_price, close_time,
         pnl, balance, tag, created_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
        """
        
        params = (ticket, trade_date, trade_number, entry_time, entry_price, sl_price,
                 tp_price, lot_size, signal, outcome, partial_close, partial_close_price,
                 close_time, pnl, balance, tag)
        
        success = self.execute(query, params)
        
        if success:
            print(f"[WP_DB] Trade {ticket} saved to WordPress")
            # Update daily stats
            self.update_daily_stats(trade_date)
        
        return success
    
    def update_position(self, ticket: int, signal: str, entry_price: float,
                       current_price: float, sl_price: float, tp_price: float,
                       lot_size: float, current_pnl: float, partial_closed: bool,
                       opened_at: str):
        """Update open position in WordPress database"""
        
        query = f"""
        REPLACE INTO {TABLE_PREFIX}tbd_positions
        (ticket, `signal`, entry_price, current_price, sl_price, tp_price,
         lot_size, current_pnl, partial_closed, opened_at, updated_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
        """
        
        params = (ticket, signal, entry_price, current_price, sl_price, tp_price,
                 lot_size, current_pnl, 1 if partial_closed else 0, opened_at)
        
        return self.execute(query, params)
    
    def remove_position(self, ticket: int):
        """Remove closed position from WordPress database"""
        
        query = f"DELETE FROM {TABLE_PREFIX}tbd_positions WHERE ticket = %s"
        
        return self.execute(query, (ticket,))
    
    def update_bot_status(self, status: str, balance: float, equity: float,
                         open_positions: int, today_pnl: float, today_trades: int):
        """Update bot status in WordPress database"""
        
        query = f"""
        UPDATE {TABLE_PREFIX}tbd_status
        SET status = %s, balance = %s, equity = %s, open_positions = %s,
            today_pnl = %s, today_trades = %s, last_update = NOW()
        WHERE id = 1
        """
        
        params = (status, balance, equity, open_positions, today_pnl, today_trades)
        
        return self.execute(query, params)
    
    def log_activity(self, level: str, message: str):
        """Log activity to WordPress database"""
        
        query = f"""
        INSERT INTO {TABLE_PREFIX}tbd_logs (log_level, log_message, created_at)
        VALUES (%s, %s, NOW())
        """
        
        return self.execute(query, (level, message))
    
    def update_daily_stats(self, trade_date: str):
        """Calculate and update daily statistics"""
        
        # Get all trades for the date
        query = f"""
        SELECT * FROM {TABLE_PREFIX}tbd_trades WHERE trade_date = %s
        """
        
        trades = self.execute_fetch(query, (trade_date,))
        
        if not trades:
            return
        
        # Calculate stats
        total_trades = len(trades)
        winning_trades = sum(1 for t in trades if t['pnl'] > 0)
        losing_trades = sum(1 for t in trades if t['pnl'] < 0)
        total_pnl = sum(t['pnl'] for t in trades)
        win_rate = (winning_trades / total_trades * 100) if total_trades > 0 else 0
        
        opening_balance = trades[0]['balance'] - trades[0]['pnl'] if trades else 0
        closing_balance = trades[-1]['balance'] if trades else 0
        
        # Update stats
        query = f"""
        REPLACE INTO {TABLE_PREFIX}tbd_stats
        (stat_date, opening_balance, closing_balance, total_trades, winning_trades,
         losing_trades, total_pnl, win_rate, created_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, NOW())
        """
        
        params = (trade_date, opening_balance, closing_balance, total_trades,
                 winning_trades, losing_trades, total_pnl, win_rate)
        
        return self.execute(query, params)
    
    def get_config(self, config_key: str) -> Optional[str]:
        """Get configuration value from WordPress"""
        
        query = f"""
        SELECT config_value FROM {TABLE_PREFIX}tbd_config WHERE config_key = %s
        """
        
        result = self.execute_fetch(query, (config_key,))
        
        return result[0]['config_value'] if result else None
    
    def close(self):
        """Close database connection"""
        if self.connection and self.connection.is_connected():
            self.connection.close()
            print("[WP_DB] Connection closed")

# Global instance
wp_db = WordPressDB()

# Convenience functions for easy integration
def wp_save_trade(**kwargs):
    """Save trade to WordPress - use this in your watcher"""
    return wp_db.save_trade(**kwargs)

def wp_update_position(**kwargs):
    """Update position in WordPress - use this in your watcher"""
    return wp_db.update_position(**kwargs)

def wp_remove_position(ticket: int):
    """Remove position from WordPress - use when trade closes"""
    return wp_db.remove_position(ticket)

def wp_update_bot_status(**kwargs):
    """Update bot status - call in main loop"""
    return wp_db.update_bot_status(**kwargs)

def wp_log(level: str, message: str):
    """Log activity to WordPress"""
    return wp_db.log_activity(level, message)

def wp_get_config(key: str):
    """Get config from WordPress"""
    return wp_db.get_config(key)